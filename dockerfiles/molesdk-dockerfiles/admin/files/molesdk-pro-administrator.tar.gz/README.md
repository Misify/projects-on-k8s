##############################################
# 开发者后台部署
##############################################
# 安装nodejs
$ curl -sL https://rpm.nodesource.com/setup_12.x | bash - 
$ yum install -y nodejs
# 测试安装是否成功
$ node -v
# 安装
$ npm install
# 项目配置
$ 配置.env
# 编译
$ npm run build
# nginx部署
cp nginx.conf /etc/nginx/conf.d/molesdk-pro-admin.conf