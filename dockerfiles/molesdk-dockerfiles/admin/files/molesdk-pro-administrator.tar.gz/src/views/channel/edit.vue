<template>
  <page-header-wrapper>
    <template v-slot:content> 编辑列表 </template>
    <a-card :bordered="false">
      <a-table :loading="loading" :pagination="false" :columns="columns" :data-source="json">
        <span slot="name" slot-scope="text, item">
          <a-icon type="apple" theme="filled" v-if="item.iOS" :style="{ color: '#1890ff' }" />
          <a-icon theme="filled" type="android" :style="{ color: '#1890ff' }" v-if="item.Android" /> {{ text }}({{ item.version }})
        </span>
        <span slot="desc" slot-scope="text, item">
          <div class="channel_desc" v-html="item.des"></div>
        </span>
        <!-- <span slot="action">
                  <a-button size="small">创建自定义渠道</a-button>
                </span> -->
      </a-table>

    </a-card>
  </page-header-wrapper>
</template>
<script>
import vueJsonEditor from 'vue-json-editor'
import { channelJson } from '@/api/channel'
const columns = [
  {
    title: '渠道code',
    imgBaseUrl: '',
    dataIndex: 'id',
    key: 'id'
  },
  {
    title: '渠道',
    dataIndex: 'name',
    key: 'name',
    scopedSlots: { customRender: 'name' }
  },
  {
    title: 'SDK版本号',
    dataIndex: 'version',
    key: 'version',
    ellipsis: true
  }
  // {
  //   title: '操作',
  //   dataIndex: 'action',
  //   width: '300px',
  //   scopedSlots: { customRender: 'action' }
  // }
]
export default {
  data () {
    return {
      columns,
      loading: false,
      json: []
    }
  },
  created () {
    this.getList()
  },
  components: {
      vueJsonEditor
  },
  methods: {
    getList () {
      this.loading = true
      channelJson(this.params).then(res => {
        this.json = res.data
      }).finally(() => {
        this.loading = false
      })
    },
    onJsonChange (e) {
      this.json = e
    },
    onJsonSave (e) {
      console.log(e)
    },
    onError () {

    }
  }
}
</script>
<style>
.jsoneditor-vue{
  height: 500px;
}
</style>
