<template>
  <page-header-wrapper>
    <template v-slot:content>
      角色列表
    </template>
    <a-card :bordered="false">
      <a-row>
        <a-col>
          <a-button type="primary" @click="roleAdd">添加角色</a-button>
        </a-col>
      </a-row>
      <a-table :loading="loading" :rowKey="(record) => record.id" :columns="columns" :data-source="data" class="margin30">
        <span slot="action" slot-scope="text, item">
          <a href="javascript:;" @click="edit(item)">编辑</a>
          <a-divider type="vertical" />
          <a href="javascript:;" @click="del(item)">删除</a>
        </span>
      </a-table>
    </a-card>
    <roleCreate
      :model="mdl"
      ref="createModal"
      @ok="handleOk"
      @cancle="handleCancle"
      :visible="visible"
      :confirmLoading="confirmLoading"
    ></roleCreate>
  </page-header-wrapper>
</template>
<script>
import { roles, rolesAdd, rolesEdit, rolesDel } from '@/api/permission'
import roleCreate from './modules/roleCreate'
const columns = [
  {
    title: '角色名称',
    dataIndex: 'name',
    key: 'name'
  },
  {
    title: '角色说明',
    dataIndex: 'title',
    key: 'title'
  },
  {
    title: '操作',
    key: 'action',
    width: 150,
    scopedSlots: { customRender: 'action' }
  }
]
export default {
  data () {
    return {
      data: [],
      columns,
      mdl: {},
      loading: false,
      visible: false,
      confirmLoading: false
    }
  },
  components: {
    roleCreate
  },
  created () {
    this.getList()
  },
  methods: {
    getList () {
      this.loading = true
      roles().then(res => {
        this.data = res
        this.loading = false
      })
    },
    roleAdd () {
      this.mdl = {}
      this.visible = true
    },
    edit (item) {
      this.visible = true
      this.mdl = { ...item }
    },
    del (item) {
      const that = this
      this.$confirm({
        title: '删除角色',
        content: '确定要删除角色？',
        onOk () {
          that.loading = true
          rolesDel(item.id).then(res => {
            that.$message.success({
              content: '删除成功！'
            })
            that.getList()
          })
        },
        onCancel () {}
      })
    },
    handleOk () {
      const models = this.$refs.createModal
      models.form.validateFields((errors, values) => {
        if (!errors) {
          values.permissions = models.targetKeys
          this.confirmLoading = false
          if (values.id) {
            rolesEdit(values).then(res => {
              this.visible = false
              this.confirmLoading = false
              this.getList()
            })
          } else {
            rolesAdd(values).then(res => {
              this.visible = false
              this.confirmLoading = false
              this.getList()
            })
          }
        }
      })
    },
    handleCancle () {
      this.visible = false
      this.confirmLoading = false
      const form = this.$refs.createModal.form
      form.resetFields() // 清理表单数据（可不做）
    }
  }
}
</script>
