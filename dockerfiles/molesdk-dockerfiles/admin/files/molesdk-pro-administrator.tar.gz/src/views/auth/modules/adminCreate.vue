<template>
  <div>
    <a-modal
      title="编辑账号"
      :visible="visible"
      :confirm-loading="confirmLoading"
      width="1000px"
      cancelText="取消"
      okText="确定"
      @ok="
        () => {
          this.$emit('ok')
        }
      "
      @cancel="
        () => {
          this.$emit('cancle')
        }
      "
    >
      <a-form :form="form" :label-col="{ span: 5 }" :wrapper-col="{ span: 12 }">
        <a-form-item v-show="false" label="主键ID">
          <a-input v-decorator="['id', { initialValue: 0 }]" disabled />
        </a-form-item>
        <a-form-item label="账户名称">
          <a-input
            placeholder="请填写账户名称"
            v-decorator="['name', { rules: [{ required: true, message: '账户名称必须填写' }] }]"
          />
        </a-form-item>
        <a-form-item label="邮箱地址">
          <a-input
            placeholder="请填写邮箱地址"
            v-decorator="['email', { rules: [{ required: true, message: '邮箱地址必须填写' }] }]"
          />
        </a-form-item>
        <a-form-item label="选择角色">
          <a-select
            v-decorator="['roles', { rules: [{ required: true, message: '必须选择一个角色' }] }]"
            show-search
            placeholder="请选择一个角色"
            option-filter-prop="children"
            :filter-option="filterOption"
            @focus="handleFocus"
            @blur="handleBlur"
            @change="handleChange"
          >
            <a-select-option v-for="item in roles" :key="item.id" :value="item.name">
              {{ item.title }}
            </a-select-option>
          </a-select>
        </a-form-item>
        <a-form-item label="登录密码" v-if="model && !model.id">
          <a-input-password
            placeholder="请输入密码"
            v-decorator="['password', {rules: [{ required: true, message: '密码不能为空'}], validateTrigger: ['change', 'blur']}]"
          ></a-input-password>
        </a-form-item>
        <a-form-item label="确认密码" v-if="model && !model.id">
          <a-input-password
            placeholder="确认密码"
            v-decorator="['password2', {rules: [{ required: true, message: '密码不能为空' }, { validator: this.handlePasswordCheck }], validateTrigger: ['change', 'blur']}]"
          ></a-input-password>
        </a-form-item>
      </a-form>
    </a-modal>
  </div>
</template>
<script>
import { roles } from '@/api/permission'
import pick from 'lodash.pick'
const fields = ['name', 'id', 'email', 'roles']
export default {
  data () {
    return {
      form: this.$form.createForm(this),
      roles: []
    }
  },
  props: {
    visible: {
      type: Boolean,
      default: false
    },
    confirmLoading: {
      type: Boolean,
      default: false
    },
    model: {
      type: Object,
      default: null
    }
  },
  created () {
    console.log('custom modal created')

    // 防止表单未注册
    fields.forEach(v => this.form.getFieldDecorator(v))
    // 当 model 发生改变时，为表单设置值
    this.$watch('model', () => {
      this.model && this.form.setFieldsValue(pick(this.model, fields))
    })
    roles().then(res => {
      this.roles = res
    })
  },
  methods: {
    handlePasswordCheck (rule, value, callback) {
      const password = this.form.getFieldValue('password')
      console.log('value', value)
      if (value === undefined) {
        callback(new Error('请输入密码'))
      }
      if (value && password && value.trim() !== password.trim()) {
        callback(new Error('两次密码不一致'))
      }
      callback()
    },
    handleChange (value) {
      console.log(`selected ${value}`)
    },
    handleBlur () {
      console.log('blur')
    },
    handleFocus () {
      console.log('focus')
    },
    filterOption (input, option) {
      return (
        option.componentOptions.children[0].text.toLowerCase().indexOf(input.toLowerCase()) >= 0
      )
    }
  }
}
</script>
