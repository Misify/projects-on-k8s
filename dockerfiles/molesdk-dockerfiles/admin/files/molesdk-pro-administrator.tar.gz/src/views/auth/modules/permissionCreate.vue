<template>
  <div>
    <a-modal
      title="编辑权限"
      :visible="visible"
      :confirm-loading="confirmLoading"
      width="1000px"
      cancelText="取消"
      okText="确定"
      @ok="
        () => {
          this.$emit('ok')
        }
      "
      @cancel="
        () => {
          this.$emit('cancle')
        }
      "
    >
      <a-form :form="form" :label-col="{ span: 5 }" :wrapper-col="{ span: 12 }">
        <a-form-item v-show="false" label="主键ID">
          <a-input v-decorator="['id', { initialValue: 0 }]" disabled />
        </a-form-item>
        <a-form-item v-show="false" label="hidden">
          <a-input v-decorator="['hidden', { initialValue: 0 }]" disabled />
        </a-form-item>
        <a-form-item label="权限名称">
          <a-input
            placeholder="请填写权限名称"
            v-decorator="['name', { rules: [{ required: true, message: '权限名称必须填写' }] }]"
          />
        </a-form-item>
        <a-form-item label="权限说明">
          <a-input
            placeholder="请填写权限说明"
            v-decorator="['title', { rules: [{ required: true, message: '权限说明必须填写' }] }]"
          />
        </a-form-item>
      </a-form>
    </a-modal>
  </div>
</template>
<script>
import pick from 'lodash.pick'
const fields = ['name', 'id', 'title', 'hidden']
export default {
  data () {
    return {
      form: this.$form.createForm(this)
    }
  },
  props: {
    visible: {
      type: Boolean,
      default: false
    },
    confirmLoading: {
      type: Boolean,
      default: false
    },
    model: {
      type: Object,
      default: null
    }
  },
  created () {
    console.log('custom modal created')

    // 防止表单未注册
    fields.forEach(v => this.form.getFieldDecorator(v))
    // 当 model 发生改变时，为表单设置值
    this.$watch('model', () => {
      this.model && this.form.setFieldsValue(pick(this.model, fields))
    })
  }
}
</script>
