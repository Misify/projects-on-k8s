<template>
  <page-header-wrapper>
    <template v-slot:content> 权限列表 </template>
    <a-card :bordered="false">
      <a-row>
        <a-col>
          <a-button type="primary" @click="addForm">添加权限</a-button>
        </a-col>
      </a-row>
      <a-table :loading="loading" :rowKey="(record) => record.id" :columns="columns" :data-source="data" class="margin30">
        <span slot="action" slot-scope="text, item">
          <a href="javascript:;" @click="edit(item)">编辑</a>
          <a-divider type="vertical" />
          <a href="javascript:;" @click="del(item)">删除</a>
        </span>
      </a-table>
    </a-card>
    <permissionCreate
      :model="mdl"
      ref="createModal"
      @ok="handleOk"
      @cancle="handleCancle"
      :visible="visible"
      :confirmLoading="confirmLoading"
    >
    </permissionCreate>
  </page-header-wrapper>
</template>
<script>
import permissionCreate from './modules/permissionCreate'
import { permissions, permissionsAdd, permissionsEdit, permissionsDel } from '@/api/permission'
const columns = [
  {
    title: '权限名称',
    dataIndex: 'name',
    key: 'name'
  },
  {
    title: '权限说明',
    dataIndex: 'title',
    key: 'title'
  },
  {
    title: '操作',
    key: 'action',
    width: '150px',
    scopedSlots: { customRender: 'action' }
  }
]
export default {
  data () {
    return {
      columns,
      data: [],
      loading: false,
      visible: false,
      mdl: {},
      confirmLoading: false
    }
  },
  components: {
    permissionCreate
  },
  created () {
    this.getList()
  },
  methods: {
    addForm () {
      this.visible = true
    },
    handleOk () {
      const form = this.$refs.createModal.form
      form.validateFields((errors, values) => {
        if (!errors) {
          this.confirmLoading = false
          if (values.id) {
            permissionsEdit(values).then(res => {
              this.visible = false
              this.confirmLoading = false
              this.getList()
            })
          } else {
            permissionsAdd(values).then(res => {
              this.visible = false
              this.confirmLoading = false
              this.getList()
            })
          }
        }
      })
    },
    handleCancle () {
      this.visible = false
      this.confirmLoading = false
      this.mdl = {}
      const form = this.$refs.createModal.form
      form.resetFields() // 清理表单数据（可不做）
    },
    getList () {
      this.loading = true
      permissions().then(res => {
        this.data = res
      }).finally(() => {
        this.loading = false
      })
    },
    edit (item) {
      this.visible = true
      this.mdl = { ...item }
    },
    del (item) {
      const that = this
      this.$confirm({
        title: '删除权限',
        content: '确定要删除权限？',
        onOk () {
          that.loading = true
          permissionsDel(item.id).then(res => {
            that.$message.success({
              content: '删除成功！'
            })
            that.getList()
          })
        },
        onCancel () {}
      })
    }
  }
}
</script>
