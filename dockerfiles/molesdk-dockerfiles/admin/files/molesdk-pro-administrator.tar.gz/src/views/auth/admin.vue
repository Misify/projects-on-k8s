<template>
  <page-header-wrapper>
    <template v-slot:content>
      账号列表
    </template>
    <a-card :bordered="false">
      <a-row>
        <a-col>
          <a-button type="primary" @click="addForm">添加账号</a-button>
        </a-col>
      </a-row>
      <a-table :rowKey="(record) => record.id" :loading="loading" :columns="columns" :data-source="data" class="margin30">
        <span slot="action" slot-scope="text, item">
          <a href="javascript:;" @click="edit(item)">编辑</a>
          <a-divider type="vertical" />
          <a href="javascript:;" @click="del(item)">删除</a>
        </span>
      </a-table>
    </a-card>
    <adminCreate
      :model="mdl"
      ref="createModal"
      @ok="handleOk"
      @cancle="handleCancle"
      :visible="visible"
      :confirmLoading="confirmLoading"
    ></adminCreate>
  </page-header-wrapper>

</template>
<script>
import adminCreate from './modules/adminCreate'
import { userList, userCreate, userDel, userUpdate } from '@/api/permission'
import { mapGetters } from 'vuex'
const columns = [
  {
    title: '账号名称',
    dataIndex: 'name',
    key: 'name'
  },
  {
    title: '邮箱地址',
    dataIndex: 'email',
    key: 'email'
  },
  {
    title: '操作',
    key: 'action',
    width: '150px',
    scopedSlots: { customRender: 'action' }
  }
]
export default {
  data () {
    return {
      columns,
      data: [],
      visible: false,
      loading: false,
      mdl: {},
      confirmLoading: false
    }
  },
  computed: {
    ...mapGetters(['userInfo'])
  },
  components: {
    adminCreate
  },
  created () {
    this.getList()
  },
  methods: {
    addForm () {
      this.visible = true
    },
    handleOk () {
      const form = this.$refs.createModal.form
      form.validateFields((errors, values) => {
        if (!errors) {
          this.confirmLoading = false
          if (values.id) {
            userUpdate(values).then(res => {
              this.visible = false
              this.confirmLoading = false
              this.getList()
            })
          } else {
            userCreate(values).then(res => {
              this.visible = false
              this.confirmLoading = false
              this.getList()
            })
          }
        }
      })
    },
    handleCancle () {
      this.visible = false
      this.confirmLoading = false
      this.mdl = {}
      const form = this.$refs.createModal.form
      form.resetFields() // 清理表单数据（可不做）
    },
    getList () {
      this.loading = true
      userList().then(res => {
        Object.values(res).forEach(item => {
          console.log(item)
          if (item.roles && item.roles.length > 0) {
            item.roles = item.roles[0].name
          }
        })
        this.data = res
      }).finally(() => {
        this.loading = false
      })
    },
    edit (item) {
      this.visible = true
      this.mdl = { ...item }
    },
    del (item) {
      const that = this
      if (item.id === this.userInfo.id) {
        this.$notification.error(
          {
            message: '操作失败',
            description: '不能删除当前登录账号！'
          }
        )
        return
      }
      this.$confirm({
        title: '删除账号',
        content: '确定要删除账号？',
        onOk () {
          that.loading = true
          userDel(item.id).then(res => {
            that.$message.success({
              content: '删除成功！'
            })
            that.getList()
          })
        },
        onCancel () {}
      })
    }
  }
}
</script>
