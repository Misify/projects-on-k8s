<template>
  <page-header-wrapper>
    <template v-slot:content> 订单列表 </template>
    <div class="margin30">
      <a-spin :spinning="tableLoading" size="large">
        <a-card style="width: 100%">
          <a-row>
            <a-col :span="22">
              <div class="order_search">
                <a-range-picker
                  :ranges="{ Today: [moment(), moment()], 'This Month': [moment(), moment().endOf('month')] }"
                  show-time
                  format="YYYY/MM/DD HH:mm:ss"
                  @change="onChange"
                />
                <a-select v-model="queryParams.state" style="width: 120px; margin-left: 10px" @change="handleState">
                  <a-select-option value=""> 全部订单 </a-select-option>
                  <a-select-option value="1"> 已支付 </a-select-option>
                  <a-select-option value="3"> 支付失败 </a-select-option>
                  <a-select-option value="2"> 订单完成 </a-select-option>
                </a-select>
                <a-select v-model="queryParams.channelId" style="width: 120px; margin: 0 10px" @change="handleChannel">
                  <a-select-option value=""> 全部渠道 </a-select-option>
                  <a-select-option v-for="items in channelList" :key="items.id" :value="items.id">
                    {{ items.name }}
                  </a-select-option>
                </a-select>
                <a-select
                  mode="multiple"
                  label-in-value
                  :value="gameValue"
                  placeholder="请输入游戏名称"
                  style="width: 220px; margin: 0 10px"
                  :filter-option="false"
                  :not-found-content="fetching ? undefined : null"
                  @search="fetchGame"
                  @change="handleGame"
                  @deselect="handleRemove"
                >
                  <a-spin v-if="fetching" slot="notFoundContent" size="small" />
                  <a-select-option v-for="d in gameData" :key="d.id">
                    {{ d.name }}
                  </a-select-option>
                </a-select>
                <p>
                  <a-input-group compact>
                    <a-select style="width: 100px" v-model="queryParams.type">
                      <a-select-option value="id"> 订单号 </a-select-option>
                      <a-select-option value="cp_order_id"> CP订单号 </a-select-option>
                      <a-select-option value="username"> 角色名称 </a-select-option>
                      <a-select-option value="uid"> 用户UID </a-select-option>
                    </a-select>
                    <a-input-search placeholder="请输入搜索内容" style="width: 200px" @search="onSearch" />
                  </a-input-group>
                </p>
              </div>
            </a-col>
          <!-- <a-col :span="2">
                  <div class="download_table"><a-icon type="download" /></div>
                </a-col> -->
          </a-row>
          <div class="margin30">
            <a-table :loading="loading" :pagination="false" :columns="columns" :data-source="data">
              <span slot="username" slot-scope="text,item">
                <span v-if="item.players">
                  {{ item.players.name }}
                </span>
              </span>
              <span slot="channel" slot-scope="text">
                {{ text.name }}
              </span>
              <span slot="game" slot-scope="text, item">
                <span v-if="item.games">
                  {{ item.games.name }}
                </span>
              </span>
              <span slot="state" slot-scope="text">
                <span v-if="text === 1">已支付</span>
                <span v-if="text === 2">已完成</span>
                <span v-if="text === 3">支付失败</span>
              </span>
              <span slot="action" slot-scope="text, item">
                <span v-if="text === 3">
                  <a-button
                    type="link"
                    size="small"
                    @click="Supplement(item)"
                  >
                    补单
                  </a-button>
                </span>
                <span v-if="text !== 3">无</span>
              </span>
            </a-table>
            <div class="pages">
              <a-pagination
                :total="total"
                @change="paginationChange"
                @showSizeChange="sizeChange"
                show-size-changer
                show-quick-jumper
              />
            </div>
          </div>
        </a-card>
      </a-spin>
    </div>
  </page-header-wrapper>
</template>
<script>
import moment from 'moment'
import { channel } from '@/api/channel'
import { order, searchGame, supplement } from '@/api/order'
import debounce from 'lodash/debounce'
const columns = [
  {
    title: '渠道',
    imgBaseUrl: '',
    dataIndex: 'channel',
    key: 'channel',
    scopedSlots: { customRender: 'channel' }
  },
  {
    title: '订 单 号',
    dataIndex: 'id',
    key: 'id',
    scopedSlots: { customRender: 'id' }
  },
  {
    title: '用户名',
    dataIndex: 'username',
    key: 'username',
    scopedSlots: { customRender: 'username' }
  },
  {
    title: '游戏',
    dataIndex: 'game',
    key: 'game',
    scopedSlots: { customRender: 'game' }
  },
  {
    title: '用户ID',
    dataIndex: 'player_id',
    key: 'player_id'
  },
  {
    title: '金额',
    dataIndex: 'amount',
    key: 'amount'
  },
  {
    title: '订单时间',
    dataIndex: 'created_at',
    key: 'created_at'
  },
  {
    title: '支付状态',
    dataIndex: 'state',
    key: 'state',
    scopedSlots: { customRender: 'state' }
  },
  {
    title: '操作',
    dataIndex: 'state',
    key: 'action',
    scopedSlots: { customRender: 'action' }
  }
]
export default {
  data () {
    this.fetchGame = debounce(this.fetchGame, 800)
    return {
      columns,
      gameId: 0,
      channelList: [],
      total: 0,
      gameList: [],
      data: [],
      gameValue: [],
      loading: false,
      gameData: [],
      fetching: false,
      queryParams: {
        time: '',
        state: '',
        channelId: '',
        gameId: '',
        type: 'id',
        val: '',
        pageSize: '10',
        current: 1
      },
      tableLoading: false
    }
  },
  created () {
    this.gameId = this.$store.getters.gameController
    channel().then(res => {
      console.log(res)
      this.channelList = res.items
    })
    this.getList()
  },
  methods: {
    moment,
    // 补单
    Supplement (order) {
      this.tableLoading = true
      const { id } = order
      supplement({ id }).then(res => {
        console.log(res)
        this.$message.success('补单成功！')
        this.tableLoading = false
      }).catch(() => {
        console.log('err')
        this.$message.success('补单失败！')
        this.tableLoading = false
      })
    },
    onChange (dates, dateStrings) {
      this.queryParams.time = dateStrings
      Object.values(dateStrings).forEach(item => {
        if (item === '') {
          this.queryParams.time = ''
        }
      })
      this.getList()
    },
    handleState (e) {
      this.queryParams.state = e
      this.getList()
    },
    handleChannel (e) {
      this.queryParams.channelId = e
      this.getList()
    },
    onSearch (e) {
      this.queryParams.val = e
      this.getList()
    },
    getList () {
      const obj = []
      if (this.gameValue.length > 0) {
        this.gameValue.forEach(item => {
          obj.push(item.key)
        })
        this.queryParams.gameId = obj.splice(',')
      }
      this.loading = true
        order(this.queryParams).then(res => {
                this.data = res.data.data
                this.total = res.data.total
              }).finally(() => {
                this.loading = false
              })
    },
    paginationChange (page, pageSize) {
      this.queryParams.current = page
      this.queryParams.pageSize = pageSize
      this.getList()
    },
    sizeChange (page, pageSize) {
      this.queryParams.current = page
      this.queryParams.pageSize = pageSize
      this.getList()
    },
    fetchGame (e) {
      this.fetching = true
      searchGame({ name: e }).then(res => {
        this.gameData = res.data
      }).finally(() => {
        this.fetching = false
      })
    },
    handleGame (e) {
      this.gameValue = e
      this.getList()
    },
    handleRemove (e) {
      this.gameValue = e
      this.getList()
    }
  }
}
</script>
<style scoped>
.order_search {
  display: flex;
}
.download_table {
  font-size: 20px;
  text-align: right;
  height: 50px;
  line-height: 50px;
  cursor: pointer;
}
.pages {
  margin-top: 20px;
  float: right;
}
</style>
