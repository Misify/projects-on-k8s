<template>
  <page-header-wrapper>
    <template v-slot:content> 游戏列表 </template>
    <a-card :bordered="false">
      <!-- <a-row>
        <a-col>
          <a-button type="primary" @click="addForm">添加账号</a-button>
        </a-col>
      </a-row> -->
      <a-row>
        <a-col :span="4">
          <a-input-search placeholder="请输入开发者名称或者邮箱" @search="onSearch" />
        </a-col>
      </a-row>
      <a-table
        @change="handleTableChange"
        :loading="loading"
        :pagination="params"
        :rowKey="(record) => record.id"
        :columns="columns"
        :data-source="data"
        class="margin30"
      >
        <span slot="secret" slot-scope="text, item">
          <a href="javascript:;" @click="showSecret(item)">查看密钥</a>
        </span>
        <span slot="icon" slot-scope="text">
          <img :src="imgUrl + text" width="50px" />
        </span>
        <span slot="action" slot-scope="text, item">
          <a href="javascript:;" @click="showChannel(item)">查看渠道</a>
        </span>
      </a-table>
    </a-card>
    <channelSetting
      ref="settingChannel"
      :model="mdl"
      :visible="visible"
      :confirmLoading="confirmLoading"
      @ok="settingChannelCancel"
      @cancel="settingChannelCancel"
    >
    </channelSetting>
    <channel
      ref="channel"
      :model="channelMdl"
      :game="game"
      :visible="visibleChannel"
      :confirmLoading="confirmLoadingChannel"
      @showParams="showParams"
      @ok="channelCancel"
      @cancel="channelCancel"
    >

    </channel>
    <a-modal
      title="查看密钥"
      :visible="passwordModel"
      :loading="secretloading"
      @ok="handleOk"
      @cancel="handleCancel"
    >
      <span v-if="secret">{{ secret }} <a-divider type="vertical" />
        <a
          href="javascript:;"
          v-clipboard:copy="secret"
          v-clipboard:success="onCopy"
          v-clipboard:error="onError"
        >复制</a></span>
      <a-input-password v-else @change="inputChange" :value="password" placeholder="请输入密码" />
    </a-modal>
  </page-header-wrapper>

</template>
<script>
import channelSetting from './modules/channelSetting'
import channel from './modules/channel'
import { gamesHasChannel, gamesChannel } from '@/api/channel'
import { getSecret, games } from '@/api/game'

const columns = [
   {
    title: 'ICON',
    dataIndex: 'icon',
    key: 'icon',
    scopedSlots: { customRender: 'icon' }
  },
  {
    title: '游戏名称',
    dataIndex: 'name',
    key: 'name'
  },
  {
    title: '类型',
    dataIndex: 'type',
    key: 'type'
  },
  {
    title: 'KEY',
    dataIndex: 'key',
    key: 'key',
    scopedSlots: { customRender: 'key' }
  },
  {
    title: '密钥',
    dataIndex: 'secret',
    key: 'secret',
    scopedSlots: { customRender: 'secret' }
  },

  {
    title: '支付回调',
    dataIndex: 'pay_callback',
    key: 'pay_callback',
    scopedSlots: { customRender: 'pay_callback' }
  },
  {
    title: '操作',
    key: 'action',
    width: '150px',
    scopedSlots: { customRender: 'action' }
  }
]
export default {
  data () {
    return {
      columns,
      data: [],
      channelMdl: [],
      visible: false,
      mdl: {},
      password: '',
      loading: false,
      gameInfo: {},
      game: {},
      secretloading: false,
      secret: '',
      passwordModel: false,
      visibleChannel: false,
      confirmLoadingChannel: false,
      imgUrl: '',
      params: {
          name: '',
          current: 1,
          pageSize: 10,
          total: 0,
          userId: 0,
          showSizeChanger: true
      },
      confirmLoading: false
    }
  },
  components: {
      channelSetting,
      channel
  },
  created () {
    if (this.$route.query.userId) {
      this.$set(this.params, 'userId', this.$route.query.userId)
    }
    this.getList()
    this.imgUrl = process.env.VUE_APP_API_BASE_URL
  },
  methods: {
    addForm () {
      this.visible = true
    },
    onCopy () {
      this.$message.info('复制成功')
    },
    onError () {
      this.$message.error('复制失败！')
    },
    handleOk () {
      this.secretloading = true
      getSecret({ password: this.password, id: this.gameInfo.id }).then(res => {
        this.secret = res.data
        this.secretloading = false
      }).catch(() => {
        this.secret = ''
        this.$message.error('密码错误')
        this.password = ''
        this.secretloading = false
      })
    },
    handleCancel () {
      this.passwordModel = false
      this.password = ''
      this.secret = ''
      this.secretloading = false
    },
    getList () {
      this.loading = true
      games(this.params).then(res => {
        this.data = res.data
        this.$set(this.params, 'total', res.total)
      }).finally(() => {
        this.loading = false
      })
    },
    // 遍历数据
    settingData (item) {
      this.visible = true
      this.confirmLoading = true
      gamesHasChannel(item.gameId, item.id).then(res => {
        // console.log(res)
        this.mdl = res
        this.confirmLoading = false
      })
    },
    edit (item) {
      this.visible = true
      this.mdl = { ...item }
    },
    inputChange (e) {
      this.password = e.target.value
    },
    onSearch (e) {
      this.$set(this.params, 'name', e)
      this.getList()
    },
    handleTableChange (e) {
      this.$set(this.params, 'current', e.current)
      this.$set(this.params, 'pageSize', e.pageSize)
      this.getList()
    },
    showParams (item) {
      this.settingData(item)
    },
    showChannel (item) {
      this.game = { ...item }
      this.visibleChannel = true
      this.confirmLoadingChannel = true
      gamesChannel(item.id).then(res => {
        this.channelMdl = res.data
        this.confirmLoadingChannel = false
      })
    },
    settingChannelCancel () {
      this.visible = false
      this.confirmLoading = false
    },
    channelCancel () {
      this.visibleChannel = false
      this.confirmLoadingChannel = false
    },
    showSecret (item) {
      this.gameInfo = item
      this.passwordModel = true
    }
  }
}
</script>
