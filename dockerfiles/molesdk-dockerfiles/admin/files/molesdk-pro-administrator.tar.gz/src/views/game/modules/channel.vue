<template>
  <a-modal
    :title="'查看绑定渠道'"
    width="1200px"
    :visible="visible"
    @ok="
      () => {
        $emit('ok')
      }
    "
    @cancel="
      () => {
        $emit('cancel')
      }
    "
  >
    <a-table
      :rowKey="(record) => record.id"
      :columns="columns"
      :loading="confirmLoading"
      :data-source="model"
    >
      <span slot="name" slot-scope="text, item">
        <a-icon type="apple" theme="filled" v-if="item.iOS" :style="{ color: '#1890ff' }" />
        <a-icon theme="filled" type="android" :style="{ color: '#1890ff' }" v-if="item.Android" /> {{ text }}
      </span>
      <span slot="plug" slot-scope="text, item" class="xs">
        <div v-if="item.plugs">
          <a-badge :count="item.plugs.length">
            <a-icon theme="filled" :style="{ fontSize: '22px', color: '#1890ff' }" type="plus-circle" />
          </a-badge>
        </div>
        <div v-else>
          <a-icon theme="filled" :style="{ fontSize: '22px', color: '#1890ff' }" type="plus-circle" />
        </div>
      </span>
      <span class="xs" slot="is_goods" slot-scope="text, item">
        <a-icon
          type="stop"
          v-if="text === 0"
          :style="{ fontSize: '22px', color: '#d9d9d9' }"
        />
        <a-icon
          theme="filled"
          v-else-if="item.goods"
          :style="{ fontSize: '22px', color: '#52c41a' }"
          type="check-circle"
        />
        <a-icon
          theme="filled"
          v-else
          :style="{ fontSize: '22px', color: '#ffc53d' }"
          type="exclamation-circle"
        />
      </span>
      <span class="xs" slot="icon" slot-scope="text">
        <a-icon
          theme="filled"
          type="exclamation-circle"
          v-if="!text"
          :style="{ fontSize: '22px', color: '#ffc53d' }"
        />
        <a-icon theme="filled" v-else :style="{ fontSize: '22px', color: '#52c41a' }" type="check-circle" />
      </span>
      <span class="xs" slot="state" slot-scope="text">
        <a-icon
          theme="filled"
          type="check-circle"
          v-if="text"
          :style="{ fontSize: '22px', color: '#52c41a' }"
        />
        <a-icon
          theme="filled"
          v-else
          :style="{ fontSize: '22px', color: '#ffc53d' }"
          type="exclamation-circle"
        />
      </span>
      <span slot="action" slot-scope="text, item">
        <a href="javascript:;" @click="showParams(item)">查看参数</a>
      </span>
    </a-table>
  </a-modal>
</template>
<script>
const columns = [
  {
    title: '渠道Code',
    imgBaseUrl: '',
    dataIndex: 'id',
    key: 'id'
  },
  {
    title: '渠道名称',
    dataIndex: 'name',
    key: 'name',
    scopedSlots: { customRender: 'name' }
  },
  {
    title: 'SDK版本',
    dataIndex: 'version',
    key: 'version'
  },
  {
    title: '包名/bundleID',
    dataIndex: 'bundle_id',
    key: 'bundle_id',
    scopedSlots: { customRender: 'bundleID' }
  },
  {
    title: '组件',
    dataIndex: 'plug',
    key: 'plug',
    scopedSlots: { customRender: 'plug' }
  },
  {
    title: '商品',
    dataIndex: 'is_goods',
    key: 'is_goods',
    scopedSlots: { customRender: 'is_goods' }
  },
  {
    title: 'ICON',
    dataIndex: 'icon',
    key: 'icon',
    scopedSlots: { customRender: 'icon' }
  },
  {
    title: '配置状态',
    dataIndex: 'state',
    key: 'state',
    scopedSlots: { customRender: 'state' }
  },
  {
    title: '操作',
    dataIndex: 'action',
    width: '150px',
    scopedSlots: { customRender: 'action' }
  }
]
export default {
  data () {
    return {
      columns
    }
  },
  props: {
    visible: {
      type: Boolean,
      default: () => false
    },
    confirmLoading: {
      type: Boolean,
      default: () => false
    },
    game: {
      type: Object,
      default: null
    },
    model: {
      type: Array,
      default: () => []
    }
  },
  created () {

  },
  methods: {
    showParams (item) {
      // console.log(this.game)
      item.gameId = this.game.id
      this.$emit('showParams', item)
    }
  }
}
</script>
