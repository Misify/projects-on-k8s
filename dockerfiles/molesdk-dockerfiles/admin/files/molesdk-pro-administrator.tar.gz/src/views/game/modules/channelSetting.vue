<template>
  <div>
    <a-modal
      :title="'配置渠道参数-' + model.cname"
      width="1200px"
      :visible="visible"
      :bodyStyle="{ padding: 0, height: '70vh' }"
      @ok="
        () => {
          $emit('ok')
        }
      "
      @cancel="
        () => {
          $emit('cancel')
        }
      "
    >
      <a-spin :spinning="confirmLoading">
        <a-tabs :activeKey="keys" :tab-position="mode" @change="handleChange">
          <a-tab-pane key="1" stype="width: 99px" tab="基础配置">
            <div class="setting_jb">
              <div class="setting_jb_title">
                <h3>查看参数</h3>
              </div>
              <div class="setting_jb_des" v-html="model.abstract"></div>
              <div class="setting_jb_form">
                <a-form :form="form" :label-col="{ span: 5 }" :wrapper-col="{ span: 12 }">
                  <div class="setting_form_title">客户端参数 <span>(修改客户端参数需重新打包,不会影响线上)</span></div>
                  <span v-if="model.params">
                    <a-form-item
                      v-for="(client, index1) in model.params.client"
                      :help="client.desc"
                      :key="index1"
                      :label="client.key"
                    >
                      <a-input v-model="client.value" disabled />
                    </a-form-item>
                  </span>

                  <div class="setting_form_title">
                    服务端参数 <span>(修改服务器参数会即时影响线上游戏,请谨慎操作)</span>
                  </div>
                  <span v-if="model.params">
                    <a-form-item
                      v-for="(server, index2) in model.params.server"
                      :key="index2"
                      :help="server.desc"
                      :label="server.key"
                    >
                      <a-input v-model="server.value" disabled />
                    </a-form-item>
                  </span>
                  <div v-if="model.params && model.params.other.length > 0" class="setting_form_title">
                    其他参数 <span>(修改其他参数需重新打包)</span>
                  </div>
                  <span v-if="model.params && model.params.other">
                    <a-form-item
                      v-for="(other, index3) in model.params.other"
                      :help="other.desc"
                      :key="index3"
                      :label="other.key"
                    >
                      <a-input v-model="other.value" disabled />
                    </a-form-item>
                  </span>
                  <div
                    v-if="model.params && model.params.meta && model.params.meta.length > 0"
                    class="setting_form_title"
                  >
                    产品自定义参数
                  </div>
                  <span v-if="model.params && model.params.meta">
                    <a-form-item v-for="(meta, index4) in model.params.meta" :key="index4" :label="meta.key">
                      <a-input v-model="meta.value" disabled />
                    </a-form-item>
                  </span>
                </a-form>
              </div>
            </div>
          </a-tab-pane>
          <a-tab-pane key="2" stype="width: 99px" tab="ICON">
            <div class="setting_upload_des">
              <p><span>*</span> 原始图片来源于游戏设置中上传的游戏ICON，如需替换请更改游戏ICON图标</p>
              <p><span>*</span> 最终生成的游戏渠道角标可在渠道列表中ICON预览</p>
            </div>
            <div class="setting_upload_title">上传ICON</div>
            <div class="setting_upload">
              <img v-if="formData.icon" width="160" :src="formData.icon" alt="avatar" />

              <div class="setting_upload_icon_des">
                <div>
                  <p><span>*</span> 如渠道有特定角标的要求，请上传带有渠道角标的图标，否则使用游戏包的默认图标;</p>
                  <p>
                    <span>*</span> 必须上传PNG格式的图片;建议图片大小：<span>Android：512*51，iOS：1024*1024。</span>
                  </p>
                  <p><span>*</span> iOS游戏建议不要包含透明度。</p>
                </div>
              </div>
            </div>
          </a-tab-pane>
          <a-tab-pane key="3" stype="width: 99px" tab="闪屏">
            <div class="margin30 SpUpload">
              <a-upload
                :action="SpAction"
                list-type="picture-card"
                :fileList="fileLists"
                :headers="header"
                @preview="handlePreview"
                @change="handleSpChange"
                disabled
              >
                <a-icon :type="SpLoading ? 'loading' : 'cloud-upload'" />
                <div class="ant-upload-text">上传闪屏</div>
              </a-upload>
            </div>
          </a-tab-pane>
          <a-tab-pane key="4" stype="width: 99px" tab="渠道商品ID">
            <div class="setting_goods_table" v-if="formData.is_goods">
              <table>
                <tbody>
                  <tr>
                    <td>商品ID</td>
                    <td>渠道商品ID</td>
                  </tr>
                  <tr v-for="(item, index) in formData.goods" :key="index">
                    <td>{{ index }}</td>
                    <td>{{ item }}</td>
                  </tr>
                </tbody>
              </table>
              <div class="setting_goods_des">
                <p>商品ID说明：</p>
                <p>1.游戏商品ID即游戏制定的商品ID，渠道商品ID即在渠道后台配置的商品ID</p>
                <p>2.游戏配置商品ID后，客户端下单时可以直接传入游戏商品ID，Quick会转换成设置的渠道商品ID</p>
                <p>3.游戏若不在此配置商品ID，则游戏客户端下单时设置orderInfo.goodsID时需自行指定渠道商品ID</p>
                <p>4.修改后需要重新打包</p>
              </div>
            </div>
            <div class="setting_goods_else" v-else>该渠道无需配置商品信息</div>
          </a-tab-pane>
          <a-tab-pane key="5" stype="width: 99px" tab="插件参数">
            <div class="margin30 setting_plug" v-if="model.plugs && model.plugs.length > 0">
              <div v-for="plu in model.plugs" :key="plu.id">
                <div class="setting_form_title">{{ plu.name }}参数配置</div>
                <span v-if="plu.params">
                  <a-form-item
                    :label-col="{ span: 5 }"
                    :wrapper-col="{ span: 17 }"
                    :help="params.des"
                    v-for="(params, index4) in plu.params"
                    :key="index4"
                    :label="params.key"
                  >
                    <a-card v-if="params.key === 'manufacturer'">
                      <span v-if="!params.value" style="color: #b7b7b7;">无推送厂商</span>
                      <div v-else>
                        <a-descriptions v-for="item in Object.keys(params.value || {})" :key="item" :column="2">
                          <template #title>
                            <a-row type="flex" justify="space-between">
                              <a-col>{{ item }}</a-col>
                            </a-row>
                          </template>
                          <a-descriptions-item v-for="ite in Object.keys(params.value[item])" :key="ite" :label="ite">
                            <a-input v-model="params.value[item][ite]" disabled></a-input>
                          </a-descriptions-item>
                        </a-descriptions>
                      </div>
                    </a-card>
                    <a-input v-else-if="!params.options" v-model="params.value" disabled />
                    <a-select style="width: 220px" v-else v-model="params.value" disabled>
                      <a-select-option v-for="(opt, optIndex) in params.options" :key="optIndex" :value="opt.value">
                        {{ opt.title }}
                      </a-select-option>
                    </a-select>
                  </a-form-item>
                </span>
              </div>
            </div>
            <div class="setting_goods_else" v-else>该渠道暂无插件配置</div>
          </a-tab-pane>
        </a-tabs>
      </a-spin>
    </a-modal>
  </div>
</template>
<script>
import { ACCESS_TOKEN } from '@/store/mutation-types'
import storage from 'store'
export default {
  data () {
    return {
      form: this.$form.createForm(this),
      loading: false,
      mode: 'left',
      formData: [],
      SpLoading: false,
      goodId: '',
      fileLists: [],
      channelId: '',
      keys: '1',
      imgBaseUrl: process.env.VUE_APP_API_BASE_URL,
      action: process.env.VUE_APP_API_BASE_URL + '/api/developer/channels/icon',
      SpAction: process.env.VUE_APP_API_BASE_URL + '/api/developer/upload/splashes',
      header: {
        'Authorization': 'Bearer ' + storage.get(ACCESS_TOKEN)
      }
    }
  },
  props: {
    visible: {
      type: Boolean,
      default: () => false
    },
    confirmLoading: {
      type: Boolean,
      default: () => false
    },
    model: {
      type: Object,
      default: null
    }
  },
  created () {
    console.log('custom modal created')

    // 当 model 发生改变时，为表单设置值
    this.$watch('model', () => {
      this.fileLists = []
      if (this.model.splashes) {
        Object.values(this.model.splashes).forEach((item, key) => {
          this.fileLists.push({
            uid: key,
            name: item,
            status: 'done',
            url: this.imgBaseUrl + item
          })
        })
      }
      this.formData = this.model
    })
    this.$watch('tabKey', () => {
      this.keys = this.tabKey
    })
  },
  methods: {
    handleChange (e) {
      this.keys = e.toString()
    },
    handleSpChange (e) {
      if (e.file.response) {
        const formData = Object.assign({}, this.formData)
        if (!formData.splashes || formData.splashes === undefined) {
          this.$set(formData, 'splashes', [])
        }
        formData.splashes.push(e.file.response.url)
        this.formData = formData
      }
      this.fileLists = e.fileList
    },
    beforeUpload (file) {
      const isJpgOrPng = file.type === 'image/png'
      if (!isJpgOrPng) {
        this.$message.error('只能上传png格式的图片!')
      }
      const isLt2M = file.size / 1024 / 1024 < 2
      if (!isLt2M) {
        this.$message.error('图片大小不得超过2M')
      }
      return isJpgOrPng && isLt2M
    },
    handlePreview (e) {
      console.log(e)
    },
    handleUploadChange (response) {
      if (response.file.response) {
        // this.formData.icon = response.file.response.url
        this.$set(this.formData, 'icon', response.file.response.url)
      }
    },
    addGoods () {
      if (this.goodId === '') {
        this.$message.warning('请填写商品ID')
        return false
      }
      if (this.channelId === '') {
        this.$message.warning('请填写渠道ID')
        return false
      }
      const arr = {}
      this.$set(arr, this.goodId, this.channelId)
      if (!this.formData.goods) {
        this.formData.goods = arr
      } else {
        this.$set(this.formData.goods, this.goodId, this.channelId)
      }
      this.goodId = ''
      this.channelId = ''
    },
    delGoods (index) {
      let goods = this.formData.goods
      this.$delete(goods, index)
      if (JSON.stringify(goods) === '{}') {
        goods = null
      }
      this.$set(this.formData, 'goods', goods)
    }
  }
}
</script>
<style scoped>
/deep/ .ant-tabs .ant-tabs-left-bar .ant-tabs-tab {
  width: 110px;
}
/deep/ .ant-tabs-nav {
  height: 70vh;
}
.setting_jb {
  height: 70vh;
  overflow-y: scroll;
}
.setting_jb_title {
  line-height: 58px;
  font-weight: bold;
  font-size: 18px;
  margin: 0px;
  color: #46566c;
  background: none;
}
.setting_jb_des {
  float: left;
  width: 80%;
  color: #1c2b36;
  line-height: 32px;
  font-size: 12px;
  overflow: hidden;
  white-space: nowrap;
  text-overflow: ellipsis;
  margin-bottom: 20px;
}
.setting_jb_form {
  overflow: hidden;
  width: 100%;
}
.setting_form_title {
  color: #3f4a52;
  font-size: 14px;
  line-height: 46px;
  margin: 0 0 22px 0;
  background-color: #f9f9f9;
  padding-left: 20px;
}
.setting_form_title span {
  font-size: 12px;
  margin-left: 5px;
  color: #ff3300;
}
.setting_upload_des {
  font-family: '微软雅黑';
  padding: 0;
  color: #9fa9b9;
  font-size: 12px;
  margin-top: 30px;
}
.setting_upload_des span {
  color: red;
}
.setting_upload_title {
  height: 30px;
  line-height: 28px;
  font-size: 18px;
  margin-top: 30px;
  font-weight: 500;
  margin-bottom: 30px;
}
/deep/ .ant-upload.ant-upload-select-picture-card {
  border: 2px dashed #d9dde3;
  width: 180px;
  height: 180px;
  color: #92aab0;
  text-align: center;
  vertical-align: middle;
  margin-bottom: 10px;
  font-size: 200%;
  cursor: default;
  float: left;
}
.setting_upload_icon_des {
  margin-left: 0px;
  line-height: 24px;
  margin-top: 10px;
  color: #9fa9b9;
  font-size: 12px;
}
.setting_upload_icon_des span {
  color: red;
}
.setting_goods_else {
  color: #777;
  font-weight: 400;
  text-align: center;
  font-size: 22px;
  margin-top: 30px;
}
.setting_goods_des {
  padding: 0;
  color: #9fa9b9;
  font-size: 12px;
  margin-top: 30px;
}
.setting_goods_table {
  margin-top: 30px;
  padding: 0 30px;
}
.setting_goods_table table {
  border: 1px solid #ccc;
  width: 100%;
  text-align: center;
}
.setting_goods_table table td {
  border: 1px solid #ccc;
  padding: 10px 0;
}
.setting_goods_table table td input {
  border: none;
  text-align: center;
  outline: none;
}
.setting_plug{
  overflow-y: scroll;
  height: 65vh;
}
</style>
<style>
.SpUpload .ant-upload.ant-upload-select-picture-card {
  width: 176px;
  height: 116px;
}
.SpUpload .ant-upload-list-picture-card-container {
  width: 176px;
  height: 116px;
}
.SpUpload .ant-upload-list-picture-card .ant-upload-list-item {
  width: 176px;
  height: 116px;
  padding: 0;
}
.SpUpload .ant-upload-list-picture-card .ant-upload-list-item-thumbnail,
.ant-upload-list-picture-card .ant-upload-list-item-thumbnail img {
  width: 176px;
  height: 116px;
}
</style>
