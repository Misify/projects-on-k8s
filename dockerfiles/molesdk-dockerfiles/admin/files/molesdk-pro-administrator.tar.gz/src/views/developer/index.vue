<template>
  <page-header-wrapper>
    <template v-slot:content>
      开发者账号列表
    </template>
    <a-card :bordered="false">
      <!-- <a-row>
        <a-col>
          <a-button type="primary" @click="addForm">添加账号</a-button>
        </a-col>
      </a-row> -->
      <a-row>
        <a-col :span="4">
          <a-input-search placeholder="请输入开发者名称或者邮箱" @search="onSearch" />
        </a-col>
      </a-row>
      <a-table
        :loading="loading"
        @change="handleTableChange"
        :pagination="params"
        :rowKey="(record) => record.id"
        :columns="columns"
        :data-source="data"
        class="margin30">
        <span slot="avatar" slot-scope="text">
          <img v-if="text" :src="imgUrl+text" width="30px" />
          <span v-else>-</span>
        </span>
        <span slot="status" slot-scope="text, item">
          <div v-if="item.email_verified_at && text === 1">
            <a-tag color="green">
              审核通过
            </a-tag>
          </div>
          <div v-if="item.email_verified_at && text === 0">
            <a-tag color="orange">
              未审核
            </a-tag>
          </div>
          <div v-if="!item.email_verified_at">
            <a-tag color="pink">
              未验证
            </a-tag>

          </div>
        </span>
        <span slot="action" slot-scope="text, item">
          <a v-if="item.email_verified_at && item.status === 0" href="javascript:;" @click="verify(item)">审核账号<a-divider type="vertical" /></a>
          <a v-else></a>
          <a href="javascript:;" @click="href_game(item)">查看游戏</a>
        </span>
      </a-table>
    </a-card>
  </page-header-wrapper>

</template>
<script>
import { list, verify } from '@/api/developer'
const columns = [
  {
    title: '开发者名称',
    dataIndex: 'name',
    key: 'name'
  },
  {
    title: '邮箱地址',
    dataIndex: 'email',
    key: 'email'
  },
  {
    title: '头像',
    dataIndex: 'avatar',
    key: 'avatar',
    scopedSlots: { customRender: 'avatar' }
  },
  {
    title: '状态',
    dataIndex: 'status',
    key: 'status',
    scopedSlots: { customRender: 'status' }
  },
  {
    title: '操作',
    key: 'action',
    width: '150px',
    scopedSlots: { customRender: 'action' }
  }
]
export default {
  data () {
    return {
      columns,
      data: [],
      visible: false,
      loading: false,
      mdl: {},
      imgUrl: '',
      params: {
          name: '',
          current: 1,
          pageSize: 10,
          total: 0,
          showSizeChanger: true
      },
      confirmLoading: false
    }
  },
  created () {
    this.getList()
    this.imgUrl = process.env.VUE_APP_API_BASE_URL
  },
  methods: {
    addForm () {
      this.visible = true
    },
    getList () {
      this.loading = true
      list(this.params).then(res => {
        this.data = res.data
        this.$set(this.params, 'total', res.count)
      }).finally(() => {
        this.loading = false
      })
    },
    edit (item) {
      this.visible = true
      this.mdl = { ...item }
    },
    onSearch (e) {
      this.$set(this.params, 'name', e)
      this.getList()
    },
    handleTableChange (e) {
      this.$set(this.params, 'current', e.current)
      this.$set(this.params, 'pageSize', e.pageSize)
      this.getList()
    },
    // 查看游戏
    href_game (item) {
      this.$router.push({
        name: 'games_list',
        query: {
          userId: item.id
        }
      })
    },
    verify (item) {
      const that = this
      this.$confirm({
        title: '账号通过审核?',
        content: '此操作将审核账号通过，是否继续？',
        okText: '确定',
        okType: 'info',
        cancelText: '取消',
        onOk () {
          console.log('OK')
          verify({ id: item.id }).then(res => {
            console.log(res)
            that.getList()
          })
        },
        onCancel () {
          console.log('Cancel')
        }
      })
    }
  }
}
</script>
