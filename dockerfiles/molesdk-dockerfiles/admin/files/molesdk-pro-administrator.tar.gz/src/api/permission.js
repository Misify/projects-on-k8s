import request from '@/utils/request'

// 权限操作
export function permissions () {
  return request({
    url: '/api/administrator/permission',
    method: 'get'
  })
}

export function permissionsAdd (data) {
  return request({
    url: '/api/administrator/permission',
    method: 'post',
    data
  })
}

export function permissionsEdit (data) {
  return request({
    url: '/api/administrator/permission/' + data.id,
    method: 'put',
    data
  })
}

export function permissionsDel (id) {
  return request({
    url: '/api/administrator/permission/' + id,
    method: 'delete'
  })
}

// 角色操作
export function roles () {
  return request({
    url: '/api/administrator/roles',
    method: 'get'
  })
}

export function rolesAdd (data) {
  return request({
    url: '/api/administrator/roles',
    method: 'post',
    data
  })
}

export function rolesEdit (data) {
  return request({
    url: '/api/administrator/roles/' + data.id,
    method: 'put',
    data
  })
}

export function rolesDel (id) {
  return request({
    url: '/api/administrator/roles/' + id,
    method: 'delete'
  })
}

// 账号操作
export function userList (token) {
  return request({
    url: '/api/administrator/users',
    method: 'get'
  })
}

export function userShow (id) {
  return request({
    url: '/api/administrator/users/' + id,
    method: 'get'
  })
}

export function userCreate (data) {
  return request({
    url: '/api/administrator/users',
    method: 'post',
    data
  })
}

export function userDel (id) {
  return request({
    url: '/api/administrator/users/' + id,
    method: 'delete'
  })
}

export function userUpdate (data) {
  return request({
    url: '/api/administrator/users/' + data.id,
    method: 'PATCH',
    data
  })
}
