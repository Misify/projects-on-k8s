import request from '@/utils/request'

export function channelJson () {
  return request({
    url: '/api/administrator/channel_json',
    method: 'post'
  })
}

export function channel () {
  return request({
    url: 'api/channels',
    method: 'get'
  })
}

// 获取渠道配置详情

export function gamesHasChannel (id, channelId) {
  return request({
    url: 'api/administrator/games/' + id + '/channels/' + channelId,
    method: 'get'
  })
}

// 获取游戏绑定的渠道
export function gamesChannel (id) {
  return request({
    url: 'api/administrator/games/' + id + '/channels',
    method: 'get'
  })
}
