import request from '@/utils/request'

export function list (params) {
  return request({
    url: '/api/administrator/developers',
    method: 'get',
    params: params
  })
}

// 账号审核
export function verify (data) {
  return request({
    url: 'api/administrator/verifys',
    method: 'post',
    data
  })
}
