import request from '@/utils/request'

export function order (data) {
  return request({
    url: '/api/administrator/order',
    method: 'post',
    data
  })
}

/**
 * 通过名称搜索game
 */

export function searchGame (data) {
  return request({
    url: '/api/administrator/search/game',
    method: 'get',
    params: data
  })
}

/**
 * 补单
 */
 export function supplement (data) {
  return request({
    url: '/api/administrator/supplement',
    method: 'post',
    data
  })
}
