import request from '@/utils/request'

export function games (data) {
  return request({
    url: '/api/administrator/games',
    method: 'get',
    params: data
  })
}

export function getSecret (data) {
  return request({
    url: '/api/administrator/secret',
    method: 'post',
    data
  })
}
