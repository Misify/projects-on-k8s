// eslint-disable-next-line
import { UserLayout, BasicLayout, BlankLayout } from '@/layouts'

const RouteView = {
  name: 'RouteView',
  render: (h) => h('router-view')
}

export const asyncRouterMap = [

  {
    path: '/',
    name: 'index',
    component: BasicLayout,
    meta: { title: 'menu.home', noAuth: true },
    redirect: '/dashboard/analysis',
    children: [
      // dashboard
      {
        path: '/dashboard',
        name: 'dashboard',
        redirect: '/dashboard/analysis',
        component: RouteView,
        hideChildrenInMenu: true,
        meta: { title: '控制台', keepAlive: true, icon: 'appstore', permission: ['dashboard'], noAuth: true },
        children: [
          {
            path: '/dashboard/analysis',
            name: 'Analysis',
            component: () => import('@/views/dashboard/Analysis'),
            meta: { title: '控制台', keepAlive: false, permission: ['dashboard'], noAuth: true }
          }
          // {
          //   path: '/dashboard/workplace',
          //   name: 'Workplace',
          //   component: () => import('@/views/dashboard/Workplace'),
          //   meta: { title: 'menu.dashboard.workplace', keepAlive: true, permission: [ 'dashboard' ] }
          // }
        ]
      },
      {
        path: '/auth',
        name: 'auth',
        redirect: '/auth/admin',
        component: RouteView,
        meta: { title: '账号管理', keepAlive: true, icon: 'user', permission: ['auth_admin', 'auth_role', 'auth_permission', 'auth_assign-permission'] },
        children: [
          {
            path: '/auth/admin',
            name: 'auth_admin',
            component: () => import('@/views/auth/admin'),
            meta: { title: '账户列表', keepAlive: false, permission: ['auth_admin'] }
          },
          {
            path: '/auth/role',
            name: 'auth_role',
            component: () => import('@/views/auth/role'),
            meta: { title: '角色列表', keepAlive: false, permission: ['auth_role'] }
          },
          {
            path: '/auth/permission',
            name: 'auth_permission',
            component: () => import('@/views/auth/permission'),
            meta: { title: '权限列表', keepAlive: false, permission: ['auth_permission'] }
          }
          // {
          //   path: '/auth/assign-permission',
          //   name: 'auth_assign-permission',
          //   component: () => import('@/views/auth/assign-permission'),
          //   meta: { title: '分配权限', keepAlive: false, permission: [ 'auth_assign-permission' ] }
          // }
          // {
          //   path: '/dashboard/workplace',
          //   name: 'Workplace',
          //   component: () => import('@/views/dashboard/Workplace'),
          //   meta: { title: 'menu.dashboard.workplace', keepAlive: true, permission: [ 'dashboard' ] }
          // }
        ]
      },
      {
        path: '/developer',
        name: 'developer',
        redirect: '/developer/list',
        component: RouteView,
        hideChildrenInMenu: true,
        meta: { title: '开发者账号', keepAlive: true, icon: 'code', permission: ['auth_admin', 'auth_role', 'auth_permission'] },
        children: [
          {
            path: '/developer/list',
            name: 'developer_list',
            component: () => import('@/views/developer/index'),
            meta: { title: '开发者账号', keepAlive: false, permission: ['auth_admin'] }
          }
          // {
          //   path: '/dashboard/workplace',
          //   name: 'Workplace',
          //   component: () => import('@/views/dashboard/Workplace'),
          //   meta: { title: 'menu.dashboard.workplace', keepAlive: true, permission: [ 'dashboard' ] }
          // }
        ]
      },
      {
        path: '/games',
        name: 'games',
        redirect: '/games/list',
        component: RouteView,
        hideChildrenInMenu: true,
        meta: { title: '游戏列表', keepAlive: true, icon: 'project', permission: ['auth_admin', 'auth_role', 'auth_permission'] },
        children: [
          {
            path: '/games/list',
            name: 'games_list',
            component: () => import('@/views/game/list'),
            meta: { title: '游戏列表', keepAlive: false, permission: ['auth_admin'] }
          }
          // {
          //   path: '/dashboard/workplace',
          //   name: 'Workplace',
          //   component: () => import('@/views/dashboard/Workplace'),
          //   meta: { title: 'menu.dashboard.workplace', keepAlive: true, permission: [ 'dashboard' ] }
          // }
        ]
      },
      {
        path: '/order',
        name: 'order',
        redirect: '/order/list',
        component: RouteView,
        hideChildrenInMenu: true,
        meta: { title: '订单列表', keepAlive: true, icon: 'dollar', permission: ['auth_admin', 'auth_role', 'auth_permission'] },
        children: [
          {
            path: '/order/list',
            name: 'order_list',
            component: () => import('@/views/order/index'),
            meta: { title: '订单列表', keepAlive: false, permission: ['auth_admin'] }
          }
          // {
          //   path: '/dashboard/workplace',
          //   name: 'Workplace',
          //   component: () => import('@/views/dashboard/Workplace'),
          //   meta: { title: 'menu.dashboard.workplace', keepAlive: true, permission: [ 'dashboard' ] }
          // }
        ]
      },
      {
        path: '/channels',
        name: 'channels',
        redirect: '/channels/list',
        component: RouteView,
        hideChildrenInMenu: true,
        meta: { title: '渠道管理', keepAlive: true, icon: 'block', permission: ['auth_admin', 'auth_role', 'auth_permission'] },
        children: [
          {
            path: '/channels/list',
            name: 'channels_list',
            component: () => import('@/views/channel/edit'),
            meta: { title: '渠道管理', keepAlive: false, permission: ['auth_admin'] }
          }
          // {
          //   path: '/dashboard/workplace',
          //   name: 'Workplace',
          //   component: () => import('@/views/dashboard/Workplace'),
          //   meta: { title: 'menu.dashboard.workplace', keepAlive: true, permission: [ 'dashboard' ] }
          // }
        ]
      },
      // account
      {
        path: '/account',
        component: RouteView,
        redirect: '/account/center',
        name: 'account',
        hidden: true,
        meta: { title: '个人页', icon: 'user', keepAlive: true, permission: ['user', 'user'] },
        children: [
          {
            path: '/account/center',
            name: 'center',
            hidden: true,
            component: () => import('@/views/account/center'),
            meta: { title: '个人中心', keepAlive: true, permission: ['user'] }
          },
          {
            path: '/account/settings',
            name: 'settings',
            component: () => import('@/views/account/settings/Index'),
            meta: { title: '个人设置', hideHeader: true, permission: ['user'] },
            redirect: '/account/settings/base',
            hideChildrenInMenu: true,
            children: [
              {
                path: '/account/settings/base',
                name: 'BaseSettings',
                component: () => import('@/views/account/settings/BaseSetting'),
                meta: { title: '基本信息', hidden: true, permission: ['user'] }
              },
              {
                path: '/account/settings/security',
                name: 'SecuritySettings',
                component: () => import('@/views/account/settings/Security'),
                meta: { title: '安全设置', hidden: true, keepAlive: true, permission: ['user'] }
              },
              {
                path: '/account/settings/save_assword',
                name: 'SavePassword',
                component: () => import('@/views/account/settings/SavePassword'),
                meta: { title: '修改密码', hidden: true, keepAlive: true, permission: ['user'] }
              }
              // {
              //   path: '/account/settings/custom',
              //   name: 'CustomSettings',
              //   component: () => import('@/views/account/settings/Custom'),
              //   meta: { title: '个性化设置', hidden: true, keepAlive: true, permission: ['user'] }
              // },
              // {
              //   path: '/account/settings/binding',
              //   name: 'BindingSettings',
              //   component: () => import('@/views/account/settings/Binding'),
              //   meta: { title: '账户绑定', hidden: true, keepAlive: true, permission: ['user'] }
              // },
              // {
              //   path: '/account/settings/notification',
              //   name: 'NotificationSettings',
              //   component: () => import('@/views/account/settings/Notification'),
              //   meta: { title: '新消息通知', hidden: true, keepAlive: true, permission: ['user'] }
              // }
            ]
          }
        ]
      }
    ]
  },
  {
    path: '*', redirect: '/404', hidden: true
  }
]

/**
 * 基础路由
 * @type { *[] }
 */
export const constantRouterMap = [
  {
    path: '/user',
    component: UserLayout,
    redirect: '/user/login',
    hidden: true,
    children: [
      {
        path: 'login',
        name: 'login',
        component: () => import(/* webpackChunkName: "user" */ '@/views/user/Login')
      },
      {
        path: 'register',
        name: 'register',
        component: () => import(/* webpackChunkName: "user" */ '@/views/user/Register')
      },
      {
        path: 'register-result',
        name: 'registerResult',
        component: () => import(/* webpackChunkName: "user" */ '@/views/user/RegisterResult')
      },
      {
        path: '/administrator/password/reset/:token',
        name: 'recover',
        component: () => import(/* webpackChunkName: "user" */ '@/views/user/Recover')
      },
      {
        path: 'forget/password',
        name: 'forget',
        component: () => import(/* webpackChunkName: "user" */ '@/views/user/ForgetPassword')
      }
    ]
  },

  {
    path: '/404',
    component: () => import(/* webpackChunkName: "fail" */ '@/views/exception/404')
  }

]
