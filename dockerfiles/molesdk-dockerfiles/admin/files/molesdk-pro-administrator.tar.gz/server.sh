rm -f molesdk-administrator.tar.gz
npm install
npm run build