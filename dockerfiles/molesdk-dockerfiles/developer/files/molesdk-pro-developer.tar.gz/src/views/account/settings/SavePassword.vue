<template>
  <leftMenu :one="'账户设置'" :route="authData">
    <template slot="leftContent">

      <div class="account-settings-info-view margin30">
        <a-card title="基本信息" style="width: 100%">
          <a-row :gutter="16">
            <a-col :md="24" :lg="16">
              <div class="account-settings-info-view">
                <a-row :gutter="16">
                  <a-col :md="24" :lg="16">

                    <a-form :form="form" layout="vertical">
                      <a-form-item
                        label="账户密码"
                      >
                        <a-input-password
                          @click="handlePasswordInputClick"
                          placeholder="至少6位密码，区分大小写"
                          v-decorator="['oldPassword', {rules: [{ required: true, message: '至少6位密码，区分大小写'}, { validator: this.handlePasswordLevel }], validateTrigger: ['change', 'blur']}]"
                        ></a-input-password>
                      </a-form-item>
                      <a-form-item
                        label="新密码"
                      >
                        <a-input-password
                          @click="handlePasswordInputClick"
                          placeholder="至少6位密码，区分大小写"
                          v-decorator="['password', {rules: [{ required: true, message: '至少6位密码，区分大小写'}, { validator: this.handlePasswordLevel }], validateTrigger: ['change', 'blur']}]"
                        ></a-input-password>
                      </a-form-item>
                      <a-form-item label="确认密码">
                        <a-input-password
                          placeholder="确认密码"
                          v-decorator="['password_confirmation', {rules: [{ required: true, message: '至少6位密码，区分大小写' }, { validator: this.handlePasswordCheck }], validateTrigger: ['change', 'blur']}]"
                        ></a-input-password>
                      </a-form-item>

                      <a-form-item>
                        <a-button type="primary" @click="handleSubmit">保存</a-button>
                        <!-- <a-button style="margin-left: 8px">保存</a-button> -->
                      </a-form-item>
                    </a-form>

                  </a-col>

                </a-row>

              </div>
            </a-col>
          </a-row>
        </a-card>
      </div>
    </template>
  </leftMenu>
</template>

<script>
import { resetPassword } from '@/api/login'
import leftMenu from '@/components/LeftMenu/LeftMenu'
import { authData } from '@/api/data'
export default {
  data () {
    return {
      // cropper
      preview: {},
      authData,
      form: this.$form.createForm(this),
      info: {},
      state: {
        time: 60,
        smsSendBtn: false,
        passwordLevel: 0,
        passwordLevelChecked: false,
        percent: 10,
        progressColor: '#FF0000'
      }
    }
  },
  components: {
    leftMenu
  },
  created () {
    this.info = this.$store.getters.userInfo
  },
  methods: {
    setavatar (url) {
      this.option.img = url
    },
    handlePasswordLevel (rule, value, callback) {
      let level = 0

      // 判断这个字符串中有没有数字
      if (/[0-9]/.test(value)) {
        level++
      }
      // 判断字符串中有没有字母
      if (/[a-zA-Z]/.test(value)) {
        level++
      }
      // 判断字符串中有没有特殊符号
      if (/[^0-9a-zA-Z_]/.test(value)) {
        level++
      }
      this.state.passwordLevel = level
      this.state.percent = level * 30
      if (level >= 2) {
        if (level >= 3) {
          this.state.percent = 100
        }
        callback()
      } else {
        if (level === 0) {
          this.state.percent = 10
        }
        callback(new Error('密码强度不够'))
      }
    },
    handlePasswordInputClick () {
      if (!this.isMobile) {
        this.state.passwordLevelChecked = true
        return
      }
      this.state.passwordLevelChecked = false
    },
    handlePasswordCheck (rule, value, callback) {
      const password = this.form.getFieldValue('password')
      if (value === undefined) {
        callback(new Error('请输入密码'))
      }
      if (value && password && value.trim() !== password.trim()) {
        callback(new Error('两次密码不一致'))
      }
      callback()
    },
    handleSubmit (e) {
      console.log(this.form)
      this.form.validateFields((errors, values) => {
        if (!errors) {
          resetPassword({ ...values, token: this.$store.getters.token, email: this.$store.getters.userInfo.email }).then(res => {
            this.$message.success('修改成功！')
            return this.$store.dispatch('Logout').then(() => {
              this.$router.push({ name: 'login' })
            })
          }).catch(err => {
            console.log(err)
            this.$message.success('修改失败！')
          })
        }
      })
    }
  }
}
</script>

<style lang="less" scoped>

  .avatar-upload-wrapper {
    height: 200px;
    width: 100%;
  }

  .ant-upload-preview {
    position: relative;
    margin: 0 auto;
    width: 100%;
    max-width: 180px;
    border-radius: 50%;
    box-shadow: 0 0 4px #ccc;

    .upload-icon {
      position: absolute;
      top: 0;
      right: 10px;
      font-size: 1.4rem;
      padding: 0.5rem;
      background: rgba(222, 221, 221, 0.7);
      border-radius: 50%;
      border: 1px solid rgba(0, 0, 0, 0.2);
    }
    .mask {
      opacity: 0;
      position: absolute;
      background: rgba(0,0,0,0.4);
      cursor: pointer;
      transition: opacity 0.4s;

      &:hover {
        opacity: 1;
      }

      i {
        font-size: 2rem;
        position: absolute;
        top: 50%;
        left: 50%;
        margin-left: -1rem;
        margin-top: -1rem;
        color: #d6d6d6;
      }
    }

    img, .mask {
      width: 100%;
      max-width: 180px;
      height: 100%;
      border-radius: 50%;
      overflow: hidden;
    }
  }
</style>
