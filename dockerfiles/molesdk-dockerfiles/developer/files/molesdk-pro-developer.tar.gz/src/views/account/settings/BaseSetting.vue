<template>
  <leftMenu :one="'账户设置'" :route="authData">
    <template slot="leftContent">
      <div class="account-settings-info-view margin30">
        <a-card title="基本信息" style="width: 100%">
          <a-row :gutter="16">
            <a-col :md="24" :lg="16">
              <a-form :form="form" layout="vertical">
                <a-form-item label="昵称">
                  <a-input
                    v-decorator="['name', { rules: [{ required: true, message: '必须填写昵称' }] }]"
                    placeholder="给自己起个名字"
                  />
                </a-form-item>
                <a-form-item label="邮箱">
                  <a-input
                    disabled
                    v-decorator="['email', { rules: [{ required: true, message: '邮箱必须填写' }] }]"
                    placeholder="exp@admin.com"
                  />
                </a-form-item>

                <a-form-item>
                  <a-button type="primary" @click="saveInfo">保存</a-button>
                  <!-- <a-button style="margin-left: 8px">保存</a-button> -->
                </a-form-item>
              </a-form>
            </a-col>
            <a-col :md="24" :lg="8" :style="{ minHeight: '180px' }">
              <div class="ant-upload-preview" @click="$refs.modal.edit(1)">
                <a-icon type="cloud-upload-o" class="upload-icon" />
                <div class="mask">
                  <a-icon type="plus" />
                </div>
                <img :src="imgBaseUrl + option.img" />
              </div>
            </a-col>
          </a-row>

          <avatar-modal ref="modal" @ok="setavatar" />
        </a-card>
      </div>
    </template>
  </leftMenu>
</template>

<script>
import leftMenu from '@/components/LeftMenu/LeftMenu'
import { authData } from '@/api/data'
import AvatarModal from './AvatarModal'
import pick from 'lodash.pick'
import { saveInfo } from '@/api/login'
const fields = ['name', 'email']
export default {
  components: {
    AvatarModal,
    leftMenu
  },
  data () {
    return {
      // cropper
      preview: {},
      imgBaseUrl: process.env.VUE_APP_API_BASE_URL,
      form: this.$form.createForm(this),
      info: {},
      authData,
      state: {
        time: 60,
        smsSendBtn: false,
        passwordLevel: 0,
        passwordLevelChecked: false,
        percent: 10,
        progressColor: '#FF0000'
      },
      option: {
        img: '/avatar2.jpg',
        info: true,
        size: 1,
        outputType: 'jpeg',
        canScale: false,
        autoCrop: true,
        // 只有自动截图开启 宽度高度才生效
        autoCropWidth: 180,
        autoCropHeight: 180,
        fixedBox: true,
        // 开启宽度和高度比例
        fixed: true,
        fixedNumber: [1, 1]
      }
    }
  },
  created () {
    this.info = this.$store.getters.userInfo
    fields.forEach(v => this.form.getFieldDecorator(v))
    this.form.setFieldsValue(pick(this.info, fields))
    this.option.img = this.$store.getters.avatar
  },
  methods: {
    setavatar (url) {
      this.option.img = url
    },
    handlePasswordLevel (rule, value, callback) {
      let level = 0

      // 判断这个字符串中有没有数字
      if (/[0-9]/.test(value)) {
        level++
      }
      // 判断字符串中有没有字母
      if (/[a-zA-Z]/.test(value)) {
        level++
      }
      // 判断字符串中有没有特殊符号
      if (/[^0-9a-zA-Z_]/.test(value)) {
        level++
      }
      this.state.passwordLevel = level
      this.state.percent = level * 30
      if (level >= 2) {
        if (level >= 3) {
          this.state.percent = 100
        }
        callback()
      } else {
        if (level === 0) {
          this.state.percent = 10
        }
        callback(new Error('密码强度不够'))
      }
    },
    handlePasswordInputClick () {
      if (!this.isMobile) {
        this.state.passwordLevelChecked = true
        return
      }
      this.state.passwordLevelChecked = false
    },
    handlePasswordCheck (rule, value, callback) {
      const password = this.form.getFieldValue('password')
      if (value === undefined) {
        callback(new Error('请输入密码'))
      }
      if (value && password && value.trim() !== password.trim()) {
        callback(new Error('两次密码不一致'))
      }
      callback()
    },
    saveInfo () {
      this.form.validateFields((errors, values) => {
        if (!errors) {
          saveInfo(values).then(res => {
            this.$notification.success({
              message: '成功',
              description: '修改信息成功',
              duration: 2
            })
            setTimeout(() => {
              this.$router.go(0)
            }, 2000)
          }).catch((err) => {
            this.$notification.success({
              message: '成功',
              description: '修改信息失败：' + err
            })
          })
        }
      })
    }
  }
}
</script>

<style lang="less" scoped>
.avatar-upload-wrapper {
  height: 200px;
  width: 100%;
}

.ant-upload-preview {
  position: relative;
  margin: 0 auto;
  width: 100%;
  max-width: 180px;
  border-radius: 50%;
  box-shadow: 0 0 4px #ccc;

  .upload-icon {
    position: absolute;
    top: 0;
    right: 10px;
    font-size: 1.4rem;
    padding: 0.5rem;
    background: rgba(222, 221, 221, 0.7);
    border-radius: 50%;
    border: 1px solid rgba(0, 0, 0, 0.2);
  }
  .mask {
    opacity: 0;
    position: absolute;
    background: rgba(0, 0, 0, 0.4);
    cursor: pointer;
    transition: opacity 0.4s;

    &:hover {
      opacity: 1;
    }

    i {
      font-size: 2rem;
      position: absolute;
      top: 50%;
      left: 50%;
      margin-left: -1rem;
      margin-top: -1rem;
      color: #d6d6d6;
    }
  }

  img,
  .mask {
    width: 100%;
    max-width: 180px;
    height: 100%;
    border-radius: 50%;
    overflow: hidden;
  }
}
</style>
<style lang="less" scoped>
.account-settings-info-main {
  width: 100%;
  display: flex;
  height: 100%;
  overflow: auto;

  &.mobile {
    display: block;

    .account-settings-info-left {
      border-right: unset;
      border-bottom: 1px solid #e8e8e8;
      width: 100%;
      height: 50px;
      overflow-x: auto;
      overflow-y: scroll;
    }
    .account-settings-info-right {
      padding: 20px 40px;
    }
  }

  .account-settings-info-left {
    border-right: 1px solid #e8e8e8;
    width: 224px;
  }

  .account-settings-info-right {
    flex: 1 1;
    padding: 8px 40px;

    .account-settings-info-title {
      color: rgba(0, 0, 0, 0.85);
      font-size: 20px;
      font-weight: 500;
      line-height: 28px;
      margin-bottom: 12px;
    }
    .account-settings-info-view {
      padding-top: 12px;
    }
  }
}
</style>
