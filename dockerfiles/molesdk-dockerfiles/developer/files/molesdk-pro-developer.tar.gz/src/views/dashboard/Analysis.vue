<template>
  <div class="nav">
    <a-row :gutter="24">
      <a-col :sm="24" :md="24" :xl="16" :style="{ marginBottom: '24px' }">
        <a-card :bodyStyle="{ padding: 0 }" :hoverable="true" :loading="loading">
          <div class="analysis_bg_div">
            <div class="analysis_div_title">
              鼹鼠聚合SDK
            </div>
            <div class="analysis_div_des">
              一键聚合广告平台、多样化的广告形式帮助游戏快速实现流量变现，实时提供收入数据，掌握收益
            </div>
          </div>
        </a-card>
      </a-col>
      <a-col :sm="24" :md="24" :xl="8" :style="{ marginBottom: '24px' }">
        <a-card :loading="loading">
          <div>
            <div class="analysis_help_title">帮助中心</div>
            <ul class="analysis_help_ul">
              <li>
                <a href=""> <a-icon type="book" /> MOLESDK使用手册</a>
              </li>
              <li>
                <a href=""><a-icon type="book" /> 玩家维护系统使用手册</a>
              </li>
              <li>
                <a href=""><a-icon type="book" /> Android打包工具</a>
              </li>
              <li>
                <a href=""> <a-icon type="book" /> IOS打包工具</a>
              </li>
              <li>
                <a href=""><a-icon type="book" /> 服务器接入文档</a>
              </li>
            </ul>
          </div>
        </a-card>
      </a-col>
    </a-row>
    <a-row :gutter="24">
      <a-col :sm="24" :md="24" :xl="24" :style="{ marginBottom: '24px' }">
        <a-card :loading="loading">
          <a-row :gutter="24">
            <a-col :sm="24" :md="12" :xl="6">
              <div class="analysis_hz_div">
                <div class="analysis_hz_div_img">
                  <img src="../../assets/dash_concat_buz.png" alt="">
                </div>
                <div>
                  <p class="analysis_hz_div_p_title">商务合作</p>
                  <p>联系人：施先生</p>
                  <p>电话/微信：138********</p>
                  <p>邮箱：shiyuebin@longame.cn</p>
                </div>
              </div>
            </a-col>
            <a-col :sm="24" :md="12" :xl="6">
              <div class="analysis_hz_div">
                <div class="analysis_hz_div_img">
                  <img src="../../assets/dash_concat_markBuz.png" alt="">
                </div>
                <div>
                  <p class="analysis_hz_div_p_title">市场合作</p>
                  <p>联系人：施先生</p>
                  <p>电话/微信：138********</p>
                  <p>邮箱：shiyuebin@longame.cn</p>
                </div>
              </div>
            </a-col>
            <a-col :sm="24" :md="12" :xl="6">
              <div class="analysis_hz_div">
                <div class="analysis_hz_div_img">
                  <img src="../../assets/dash_concat_tecSurrport.png" alt="">
                </div>
                <div>
                  <p class="analysis_hz_div_p_title">技术支持</p>
                  <p>联系人：黄先生</p>
                  <p>电话/微信：138********</p>
                  <p>邮箱：huangxiaohui@longame.cn</p>
                </div>
              </div>
            </a-col>
            <a-col :sm="24" :md="12" :xl="6">
              <div class="analysis_hz_div">
                <div class="analysis_hz_div_img">
                  <img src="../../assets/dash_concat_qqgroup.png" alt="">
                </div>
                <div>
                  <p class="analysis_hz_div_p_title">官方技术交流群</p>
                  <p>QQ群1:204****</p>
                  <p>QQ群2:204****</p>
                  <p>QQ群3:204****</p>
                </div>
              </div>
            </a-col>
          </a-row>
        </a-card>
      </a-col>
    </a-row>
  </div>
</template>

<script>

export default {
  name: 'Analysis',
  data () {
    return {
      loading: true,
      pieStyle: {
        stroke: '#fff',
        lineWidth: 1
      }
    }
  },
  created () {
    setTimeout(() => {
      this.loading = !this.loading
    }, 1000)
  }
}
</script>

<style>
.analysis_bg_div {
  padding: 24px;
  background: url('../../assets/dash_glink_bg.png') no-repeat right bottom;
}
.analysis_div_title{
    font-weight: 400;
    margin-top: 10px;
    font-size: 22px;
}
.analysis_div_des{
  margin-top: 20px;
  line-height: 200%;
  color: #595959;
  width: 39%;
  font-size: 16px;
  word-break: break-all;
  font-size: 14px;
  margin-bottom: 130px;
}
.analysis_help_title{
  font-size: 16px;
  font-weight: bold;
  margin-bottom: 30px;
}
.analysis_help_ul{
  width: 100%;
  padding: 0 0 5px 0;
}
.analysis_help_ul li{
  height: 35px;
  line-height: 35px;
}
.analysis_help_ul li a{
  color: #595959;
}
.analysis_hz_div{
  display: flex;
}
.analysis_hz_div_img{
  margin: 0 25px 0 15px;
}
.analysis_hz_div_p_title{
  font-weight: bold;
  font-size: 18px
}
</style>
