<template>
  <div>
    Monitor
  </div>
</template>

<script>
export default {
  name: 'Monitor'
}
</script>

<style scoped>

</style>
