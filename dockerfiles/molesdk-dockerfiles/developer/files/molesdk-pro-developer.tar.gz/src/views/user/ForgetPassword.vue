<template>
  <div class="recover">
    <a-form :form="form" :label-col="{ span: 5 }" :wrapper-col="{ span: 18 }">
      <a-form-item label="邮箱地址：">
        <a-input
          size="large"
          type="text"
          placeholder="邮箱"
          v-decorator="[
            'email',
            {
              rules: [{ required: true, type: 'email', message: '请输入邮箱地址' }],
              validateTrigger: ['change', 'blur'],
            },
          ]"
        ></a-input>
      </a-form-item>

      <a-form-item :wrapper-col="{ span: 12, offset: 5 }">
        <a-button type="primary" @click="sub" :loading="loading">提交</a-button>
      </a-form-item>
    </a-form>
  </div>
</template>

<script>
import { forgot } from '@/api/login'
import { deviceMixin } from '@/store/device-mixin'

export default {
  name: 'Register',
  components: {
  },
  mixins: [deviceMixin],
  data () {
    return {
      form: this.$form.createForm(this),
      loading: false
    }
  },
  methods: {
    sub () {
      if (this.form.getFieldValue('email') && this.form.getFieldValue('email') !== undefined) {
        this.loading = true
        forgot({ email: this.form.getFieldValue('email') }).then(res => {
          // this.current++
          this.$message.success('邮件发送成功！请在一小时内完成重置密码操作！')
          this.loading = false
        }).catch(error => {
          this.loading = false
          this.$message.error(error.response.data.message)
        })
      }
    }
  }
}
</script>
<style lang="less">
.user-register {
  &.error {
    color: #ff0000;
  }

  &.warning {
    color: #ff7e05;
  }

  &.success {
    color: #52c41a;
  }
}

.user-layout-register {
  .ant-input-group-addon:first-child {
    background-color: #fff;
  }
}
</style>
<style lang="less" scoped>
.recover {
  overflow: hidden;
  width: 600px;
  margin: 30px auto;
}
</style>
