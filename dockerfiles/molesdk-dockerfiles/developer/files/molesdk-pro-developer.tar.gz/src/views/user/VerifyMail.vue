<template>
  <a-spin :spinning="spinning">
    <a-result :title="title">
      <template #icon>
        <a-icon v-if="state === 0" type="frown" theme="twoTone" two-tone-color="#eb2f96" />
        <a-icon v-else type="smile" theme="twoTone" />
      </template>
      <template #extra>
        <a-button type="primary" @click="href"> 返回主页 </a-button>
      </template>
    </a-result>
  </a-spin>
</template>

<script>
import { verifyMail } from '@/api/login'
export default {
  data () {
    return {
      spinning: true,
      state: 0,
      title: ''
    }
  },
  created () {
    console.log('重新打包')
    const query = this.$route.query
    const params = this.$route.params
    verifyMail(
      params.id, {
        expires: query.expires,
        signature: query.signature
      }).then(res => {
      this.title = '邮箱激活成功！'
      this.state = res.state
      this.spinning = false
      this.$message.success('邮箱激活成功，即将跳转页面...')
      setTimeout(() => {
        this.$router.push({
          path: '/games/list'
              })
      }, 1500)
    }).catch(error => {
      this.title = error.response.data.message
      this.spinning = false
    })
  },
  methods: {
    href () {
      this.$router.push({ path: '/user/login' })
    }
  }
}
</script>
