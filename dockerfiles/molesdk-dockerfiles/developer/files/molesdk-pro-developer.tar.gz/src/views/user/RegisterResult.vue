<template>
  <a-result :isSuccess="true" :content="false" :title="email" :sub-title="description">
    <template #extra>
      <a-button size="large" :loading="loading" @click="sendMail" type="primary">重新发送邮件</a-button>
      <!-- <a-button size="large" style="margin-left: 10px" @click="goHomeHandle">返回上一页</a-button> -->
    </template>
  </a-result>
</template>

<script>
import { sendMail } from '@/api/login'
export default {
  name: 'RegisterResult',
  data () {
    return {
      description: '激活邮件已发送到你的邮箱中，邮件有效期为一个小时。请及时登录邮箱，点击邮件中的链接激活帐户。',
      form: {},
      loading: false
    }
  },
  computed: {
    email () {
      const v = this.form && this.form.email || 'xxx'
      return `你的账户：${v} 还未激活`
    }
  },
  created () {
    this.form = this.$store.getters.userInfo
    if (this.form.email_verified_at) {
      this.$message.success('账户已激活，页面即将跳转...')
      this.loading = true
      setInterval(() => {
        this.$router.push({
                name: 'index'
              })
              this.loading = false
      }, 1500)
    }
    // this.form = this.$route.params
  },
  methods: {
    // goHomeHandle () {
    //   this.$router.push({
    //     path: '/user/login'
    //    })
    // },
    sendMail () {
      this.loading = true
      sendMail({
        email: this.form.email
      }).then(res => {
        this.loading = false
        this.$message.success('发送成功，请在一小时内完成激活！')
      }).catch(err => {
        this.loading = false
        this.$message.error(err.message ?? 'error')
      })
    }
  }
}
</script>

<style scoped>
</style>
