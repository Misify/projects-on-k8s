<template>
  <div>
    <leftMenu :one="'数据运营平台'" :route="baseData">
      <template slot="leftContent">
        <div class="game_content margin30">
          <a-card title="基础数据" style="width: 100%">
            <div class="jc_data">
              <a-row>
                <a-col :span="4">
                  <div class="jc_data_div">
                    <div>
                      <a-icon class="jc_icon" type="plus-circle" theme="twoTone" two-tone-color="#ffc53d" />
                    </div>
                    <div class="jc_title">新增账号</div>
                    <div>
                      <span>
                        <a-button size="small">今日</a-button> 0
                      </span>
                    </div>
                    <div>
                      <span>
                        <a-button size="small">昨日</a-button> 0
                      </span>
                    </div>
                  </div>
                </a-col>
                <a-col :span="4">
                  <div class="jc_data_div">
                    <div>
                      <a-icon class="jc_icon" type="copyright" theme="twoTone" two-tone-color="#08979c" />
                    </div>
                    <div class="jc_title">新增设备</div>
                    <div>
                      <span>
                        <a-button size="small">今日</a-button> 0
                      </span>
                    </div>
                    <div>
                      <span>
                        <a-button size="small">昨日</a-button> 0
                      </span>
                    </div>
                  </div>
                </a-col>
                <a-col :span="4">
                  <div class="jc_data_div">
                    <div>
                      <a-icon class="jc_icon" type="smile" theme="twoTone" two-tone-color="#fa541c" />
                    </div>
                    <div class="jc_title">活跃用户</div>
                    <div>
                      <span>
                        <a-button size="small">今日</a-button> 0
                      </span>
                    </div>
                    <div>
                      <span>
                        <a-button size="small">昨日</a-button> 0
                      </span>
                    </div>
                  </div>
                </a-col>
                <a-col :span="4">
                  <div class="jc_data_div">
                    <div>
                      <a-icon class="jc_icon jc_order" type="transaction" />
                    </div>
                    <div class="jc_title">付费额</div>
                    <div>
                      <span>
                        <a-button size="small">今日</a-button> 0
                      </span>
                    </div>
                    <div>
                      <span>
                        <a-button size="small">昨日</a-button> 0
                      </span>
                    </div>
                  </div>
                </a-col>
                <a-col :span="4">
                  <div class="jc_data_div">
                    <div>
                      <a-icon class="jc_icon trademark" type="trademark" />
                    </div>
                    <div class="jc_title">ARPPU</div>
                    <div>
                      <span>
                        <a-button size="small">今日</a-button> 0
                      </span>
                    </div>
                    <div>
                      <span>
                        <a-button size="small">昨日</a-button> 0
                      </span>
                    </div>
                  </div>
                </a-col>
                <a-col :span="4">
                  <div class="jc_data_div">
                    <div>
                      <a-icon class="jc_icon" type="euro" theme="twoTone" two-tone-color="#389e0d" />
                    </div>
                    <div class="jc_title">ARPU</div>
                    <div>
                      <span>
                        <a-button size="small">今日</a-button> 0
                      </span>
                    </div>
                    <div>
                      <span>
                        <a-button size="small">昨日</a-button> 0
                      </span>
                    </div>
                  </div>
                </a-col>
              </a-row>
            </div>
          </a-card>
          <div class="margin30">

          </div>
          <a-card title="最近15日数据趋势图" style="width: 100%">
            <bar :data="barData" title="销售额排行" style="margin-top: 20px" />
          </a-card>
        </div>
      </template>
    </leftMenu>
  </div>
</template>
<script>
import { baseData } from '@/api/data'
import leftMenu from '@/components/LeftMenu/LeftMenu'
import {
  Bar
} from '@/components'
const barData = []
const barData2 = []
for (let i = 0; i < 12; i += 1) {
  barData.push({
    x: `${i + 1}月`,
    y: Math.floor(Math.random() * 1000) + 200
  })
  barData2.push({
    x: `${i + 1}月`,
    y: Math.floor(Math.random() * 1000) + 200
  })
}
export default {
  data () {
    return {
      baseData,
      barData,
      barData2
    }
  },
  components: {
    leftMenu,
    Bar
  }
}
</script>
<style scoped>
* /deep/ .ant-card-body{
  padding: 0;
}
.jc_data_div{
  height: 300px;
  padding-top: 50px;
  border: 1px dashed #e4e9ed;
}
.jc_data_div div{
  width: 100%;
  height: 50px;
  text-align: center;
}
.jc_data_div .jc_icon{
  font-size: 50px;
}

.jc_title{
  margin-top: 20px;
  color: #1c2b36;
  font-size: 16px;
}
.jc_order{
  color: #1890ff;
}
.trademark{
  color: #95de64;
}
</style>
