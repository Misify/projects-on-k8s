<template>
  <div>
    <leftMenu :one="'数据运营平台'" :route="baseData">
      <template slot="leftContent">
        <div class="margin30">
          <a-card title="订单明细" style="width: 100%">
            <div class="list-tips" style="margin-bottom: 0; overflow: hidden">
              <label>重要提示</label>
              <span
                style="display: block; float: left; width: 90%"
              >1.订单列表数据更新间隔为5分钟，母包支付需使用 母包测试帐号 方可支付成功。<br />
                2.确定实际支付后，若订单支付状态显示为[等待]则需检查渠道后台的发货地址或Quick后台渠道参数，参见
                不到账排查方法，支付状态为“等待”的订单不会向callbackUrl发送通知<br />
                3.若支付状态为[成功],通知游戏状态为[失败]则需游戏技术确定发货接口(callbackUrl)是否按文档返回，可点击"详情"切换顶部"通知游戏记录"查看错误返回</span
              >
            </div>
            <div class="margin30">
              <a-row>
                <a-col :span="22">
                  <div class="order_search">
                    <a-range-picker
                      :ranges="{ Today: [moment(), moment()], 'This Month': [moment(), moment().endOf('month')] }"
                      show-time
                      format="YYYY/MM/DD HH:mm:ss"
                      @change="onChange"
                    />
                    <a-select v-model="queryParams.state" style="width: 120px; margin-left: 10px" @change="handleState">
                      <a-select-option value=""> 全部订单 </a-select-option>
                      <a-select-option value="1"> 已支付 </a-select-option>
                      <a-select-option value="3"> 支付失败 </a-select-option>
                      <a-select-option value="2"> 订单完成 </a-select-option>
                    </a-select>
                    <a-select
                      v-model="queryParams.channelId"
                      style="width: 120px; margin: 0 10px"
                      @change="handleChannel"
                    >
                      <a-select-option value=""> 全部渠道 </a-select-option>
                      <a-select-option v-for="items in channelList" :key="items.id" :value="items.id">
                        {{ items.name }}
                      </a-select-option>
                    </a-select>
                    <p>
                      <a-input-group compact>
                        <a-select style="width: 100px" v-model="queryParams.type">
                          <a-select-option value="id"> 订单号 </a-select-option>
                          <a-select-option value="cp_order_id"> CP订单号 </a-select-option>
                          <!-- <a-select-option value="username"> 角色名称 </a-select-option> -->
                          <a-select-option value="player_id"> 用户UID </a-select-option>
                        </a-select>
                        <a-input-search placeholder="请输入搜索内容" style="width: 200px" @search="onSearch" />
                      </a-input-group>
                    </p>
                  </div>
                </a-col>
                <!-- <a-col :span="2">
                  <div class="download_table"><a-icon type="download" /></div>
                </a-col> -->
              </a-row>
            </div>
            <div class="margin30">
              <a-table :pagination="false" :columns="columns" :data-source="data">
                <span slot="channel" slot-scope="text">
                  {{ text.name }}
                </span>
                <span slot="players" slot-scope="text">
                  {{ text !== null ? text.name : '' }}
                </span>
                <span slot="state" slot-scope="text">
                  <div v-if="text === 1">已支付</div>
                  <div v-if="text === 2">已完成</div>
                  <div v-if="text === 3">失败</div>
                </span>
              </a-table>
              <div class="table_page">
                <a-pagination
                  show-size-changer
                  :default-current="queryParams.current"
                  :total="total"
                  @change="pageChange"
                  @showSizeChange="onShowSizeChange"
                />
              </div>
            </div>
          </a-card>
        </div>
      </template>
    </leftMenu>
  </div>
</template>
<script>
import moment from 'moment'
import { baseData } from '@/api/data'
import { gamesChannel } from '@/api/games'
import { order } from '@/api/order'
import leftMenu from '@/components/LeftMenu/LeftMenu'
const columns = [
  {
    title: '渠道',
    dataIndex: 'channel',
    key: 'channel',
    scopedSlots: { customRender: 'channel' }
  },
  {
    title: '订 单 号',
    dataIndex: 'id',
    key: 'id'
  },
  {
    title: '用户名',
    dataIndex: 'players',
    key: 'players',
    scopedSlots: { customRender: 'players' }
  },
  {
    title: '用户ID',
    dataIndex: 'player_id',
    key: 'player_id'
  },
  {
    title: '产品名称',
    dataIndex: 'product_name',
    key: 'product_name'
  },
  {
    title: '金额',
    dataIndex: 'amount',
    key: 'amount'
  },
  {
    title: 'cp订单号',
    dataIndex: 'cp_order_id',
    key: 'cp_order_id'
  },
  {
    title: '订单时间',
    dataIndex: 'created_at',
    key: 'created_at'
  },
  {
    title: '支付状态',
    dataIndex: 'state',
    key: 'state',
    scopedSlots: { customRender: 'state' }
  }
  // {
  //   title: '操作',
  //   dataIndex: 'action',
  //   width: '200px',
  //   scopedSlots: { customRender: 'action' }
  // }
]
export default {
  data () {
    return {
      baseData,
      columns,
      gameId: 0,
      channelList: [],
      data: [],
      total: 0,
      queryParams: {
        time: '',
        state: '',
        channelId: '',
        type: 'id',
        val: '',
        current: 1,
        game_id: '',
        pageSize: 10
      }
    }
  },
  created () {
    this.gameId = this.$store.getters.gameController
    gamesChannel(this.gameId).then(res => {
      this.channelList = res.data
    })
    this.queryParams.game_id = this.gameId
    this.getList()
  },
  components: {
    leftMenu
  },
  methods: {
    moment,
    onChange (dates, dateStrings) {
      this.queryParams.time = dateStrings
      Object.values(dateStrings).forEach(item => {
        if (item === '') {
          this.queryParams.time = ''
        }
      })
      this.getList()
    },
    handleState (e) {
      this.queryParams.state = e
      this.getList()
    },
    handleChannel (e) {
      this.queryParams.chennelId = e
      this.getList()
    },
    onSearch (e) {
      this.queryParams.val = e
      this.getList()
    },
    getList () {
      order(this.queryParams).then(res => {
        this.data = res.data.data
        this.total = res.data.total
      })
    },
    onShowSizeChange (current, pageSize) {
      this.queryParams.current = current
      this.queryParams.pageSize = pageSize
      this.getList()
    },
    pageChange (current, pageSize) {
      this.queryParams.current = current
      this.queryParams.pageSize = pageSize
      this.getList()
    }
  }
}
</script>
<style scoped>
.order_search {
  display: flex;
}
.download_table {
  font-size: 20px;
  text-align: right;
  height: 50px;
  line-height: 50px;
  cursor: pointer;
}
.table_page {
  margin-top: 15px;
  float: right;
}
</style>
