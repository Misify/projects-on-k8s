<template>
  <div>
    <leftMenu :one="'游戏中心'" :route="gameRoute">
      <template slot="leftContent">
        <div class="game_content">
          <div class="game_title">
            全部游戏 <span>符合条件的记录共{{ total }}条</span>
          </div>
          <div class="game_search">
            <a-row>
              <a-col :span="2"><a-button @click="createGame" type="primary" icon="plus-circle">创建</a-button></a-col>
              <a-col :span="6">
                <a-select
                  :value="queryParams.type"
                  placeholder="请选择游戏类别"
                  style="width: 90%"
                  @change="handleType"
                >
                  <a-select-option value=""> 全部类别 </a-select-option>
                  <a-select-option :value="col.value" v-for="col in gameType" :key="col.label">
                    {{ col.value }}
                  </a-select-option>
                </a-select>
              </a-col>
              <a-col :span="10">
                <a-input-group compact>
                  <a-select :value="queryParams.fild_type" style="width: 120px" @change="handleSearchType">
                    <a-select-option value="name"> 游戏名称 </a-select-option>
                    <a-select-option value="id"> APPID </a-select-option>
                  </a-select>
                  <a-input-search style="width: 50%" ref="nameInput" @change="inputChange" @search="onSearch" />
                </a-input-group>
              </a-col>
              <a-col :span="3" :offset="3">
                <div class="game_content_foot">
                  <a-button @click="href_restore">回收站</a-button>
                </div>
              </a-col>
            </a-row>
          </div>
          <div>
            <a-table :pagination="false" :columns="columns" :data-source="data">
              <a class="icon_name" slot="name" @click="handleController(item)" slot-scope="text, item">
                <img width="32px" :src="imgBaseUrl + item.icon" />{{ text }}
              </a>
              <span slot="action" slot-scope="text, record">
                <template>
                  <a-button size="small" ghost type="primary" @click="handleController(record)">游戏信息</a-button>
                  <a-divider type="vertical" />
                  <a-button size="small" type="primary" @click="handleEdit(record)">编辑</a-button>
                  <a-divider type="vertical" />
                  <a-button size="small" type="danger" @click="handleDel(record)">删除</a-button>
                </template>
              </span>
            </a-table>
          </div>
        </div>
      </template>
    </leftMenu>
    <create
      ref="createModal"
      @cancel="createCancle"
      @ok="createOk"
      :model="mdl"
      :gameType="gameType"
      :visible="createVisible"
      :confirmLoading="createConfirmg"
    ></create>
  </div>
</template>
<script>
import leftMenu from '@/components/LeftMenu/LeftMenu'
import create from './modules/create'
import { games, gameAdd, gameUpdate, gameDelete } from '@/api/games'
import { gameType, gameRoute } from '@/api/data'
const columns = [
  {
    title: '游戏名称',
    imgBaseUrl: '',
    dataIndex: 'name',
    key: 'name',
    scopedSlots: { customRender: 'name' }
  },
  // {
  //   title: 'Age',
  //   dataIndex: 'age',
  //   key: 'age',
  //   width: 80
  // },
  {
    title: '游戏类型',
    dataIndex: 'type',
    key: 'type',
    scopedSlots: { customRender: 'type' }
  },
  {
    title: 'APPID',
    dataIndex: 'id',
    key: 'id',
    ellipsis: true
  },
  {
    title: '操作',
    dataIndex: 'action',
    width: '300px',
    scopedSlots: { customRender: 'action' }
  }
]
export default {
  data () {
    return {
      data: [],
      columns,
      gameRoute,
      gameType,
      total: 0,
      queryParams: {
        fild_type: 'name',
        name: '',
        type: ''
      },
      mdl: {},
      createConfirmg: false,
      createVisible: false
    }
  },
  components: {
    leftMenu,
    create
  },
  mounted () {
    this.getList()
    this.imgBaseUrl = process.env.VUE_APP_API_BASE_URL
  },
  methods: {
    href_restore () {
      this.$router.push({ path: '/games/restore' })
    },
    onSearch (e) {
      this.queryParams.name = e
      this.getList()
    },
    createGame () {
      console.log(this.$store)
      console.log(this.$store.dispatch('GetInfo'))
      this.createVisible = true
    },
    // 删除游戏
    handleDel (record) {
      const that = this
      this.$confirm({
        title: '删除游戏',
        content: '确定要删除游戏？',
        onOk () {
          that.loading = true
          gameDelete(record.id).then((res) => {
            that.$message.success({
              content: '删除成功！'
            })
            that.getList()
          })
        },
        onCancel () {}
      })
    },
    handleType (e) {
      this.queryParams.type = e
      this.getList()
    },
    // 处理搜索类别
    handleSearchType (e) {
      this.queryParams.fild_type = e
    },
    // 监听input变化
    inputChange (e) {
      this.queryParams.name = e.target.value
    },
    createCancle () {
      this.createVisible = false
      this.createConfirmg = false
      const form = this.$refs.createModal.form
      this.$refs.createModal.imageUrl = ''
      form.resetFields() // 清理表单数据（可不做）
    },
    // 跳转到控制台
    handleController (record) {
      this.$store.dispatch('setGameController', record.id).then((res) => {
        this.$router.push({
          path: '/dashboard/analysis'
        })
      })
    },
    // 编辑游戏
    handleEdit (record) {
      this.createVisible = true
      this.mdl = { ...record }
    },
    createOk () {
      const form = this.$refs.createModal.form
      this.confirmLoading = true
      form.validateFields((errors, values) => {
        if (!errors) {
          values.icon = this.$refs.createModal.imageUrl
          if (values.id > 0) {
            // 修改 e.g.
            gameUpdate(values, values.id).then((res) => {
              this.createVisible = false
              this.createConfirmg = false
              // 重置表单数据
              form.resetFields()
              this.$refs.createModal.imageUrl = ''
              // 刷新表格
              this.getList()
              this.setGame()

              this.$message.info('修改成功')
            })
          } else {
            // 新增
            gameAdd(values).then((res) => {
              this.createVisible = false
              this.createConfirmg = false
              // 重置表单数据
              form.resetFields()
              this.$refs.createModal.imageUrl = ''
              // 刷新表格
              this.getList()
              this.setGame()

              this.$message.info('新增成功')
            })
          }
        }
      })
    },
    getList () {
      games(this.queryParams).then((res) => {
        this.data = res.data
        this.total = res.total
      })
    },
    // 设置vuex games
    setGame () {
      this.$store.dispatch('setGame')
    }
  }
}
</script>
<style>
.ant-pro-basicLayout-content {
  margin: 0;
}
.game_content {
  margin: 20px 0;
  background-color: #fff;
  box-shadow: 0 1px 1px rgba(0, 0, 0, 0.05);
}
.game_title {
  border-bottom: 1px solid #e9ebef;
  padding: 10px 15px;
  color: #535351;
  font-size: 16px;
  line-height: 30px;
}
.game_title span {
  font-size: 14px;
}
.game_search {
  padding: 21px 15px;
}
.game_content_foot {
  display: flex;
  justify-content: flex-end;
}
.icon_name {
  display: flex;
  align-items: center;
}
.icon_name img {
  margin-right: 10px;
  border-radius: 50%;
}
</style>
