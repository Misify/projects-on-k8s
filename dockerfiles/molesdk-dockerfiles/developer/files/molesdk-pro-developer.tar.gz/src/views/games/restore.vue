<template>
  <div>
    <leftMenu :one="'游戏中心'" :route="route">
      <template slot="leftContent">
        <div class="game_content">
          <div class="game_title">游戏回收站 <span>符合条件的记录共{{ total }}条</span></div>
          <div>
            <a-table :pagination="false" :columns="columns" :data-source="data">
              <a
                href="javascript:;"
                class="icon_name"
                slot="name"
                slot-scope="text, item"
              ><img width="32px" :src="imgBaseUrl + item.icon" />{{ text }}</a
              >
              <span slot="action" slot-scope="text, record">
                <template>
                  <a-button size="small" @click="handle(record)">恢复</a-button>
                </template>
              </span>
            </a-table>
          </div>
        </div>
      </template>
    </leftMenu>
  </div>
</template>
<script>
import { gameTrashed, gameRestore } from '@/api/games'
import leftMenu from '@/components/LeftMenu/LeftMenu'
const columns = [
  {
    title: '游戏名称',
    imgBaseUrl: '',
    dataIndex: 'name',
    key: 'name',
    scopedSlots: { customRender: 'name' }
  },
  // {
  //   title: 'Age',
  //   dataIndex: 'age',
  //   key: 'age',
  //   width: 80
  // },
  {
    title: '游戏类型',
    dataIndex: 'type',
    key: 'type',
    scopedSlots: { customRender: 'type' }
  },
  {
    title: 'appID',
    dataIndex: 'id',
    key: 'id',
    ellipsis: true
  },
  {
    title: '操作',
    dataIndex: 'action',
    width: '100px',
    scopedSlots: { customRender: 'action' }
  }
]
const route = [
    {
      name: '全部游戏',
      path: '/games/list',
      active: true
    },
    {
      name: '游戏总览',
      path: '/games/list',
      active: false
    }, {
      name: '渠道总览',
      path: '/games/list',
      active: false
    }, {
      name: '全局报表',
      path: '/games/list',
      active: false
    }, {
      name: '全局查询',
      path: '/games/list',
      active: false
    }
]
export default {
  data () {
    return {
      data: [],
      columns,
      total: 0,
      route
    }
  },
  mounted () {
    this.imgBaseUrl = process.env.VUE_APP_API_BASE_URL
    this.getList()
  },
  components: {
    leftMenu
  },
  methods: {
    handle (record) {
      const that = this
      this.$confirm({
        title: '恢复产品',
        content: '确定要恢复？',
        onOk () {
          that.loading = true
          gameRestore(record.id).then(res => {
            that.$message.success({
              content: '恢复成功！'
            })
            that.getList()
          })
        },
        onCancel () {}
      })
    },
    getList () {
      gameTrashed().then(res => {
        console.log(res)
        this.data = res.data
        this.total = res.total
      })
    }
  }
}
</script>
<style>
.ant-pro-basicLayout-content {
  margin: 0;
}
.game_content {
  margin: 20px 0;
  background-color: #fff;
  box-shadow: 0 1px 1px rgba(0, 0, 0, 0.05);
}
.game_title {
  border-bottom: 1px solid #e9ebef;
  padding: 10px 15px;
  color: #535351;
  font-size: 16px;
  line-height: 30px;
}
.game_title span {
  font-size: 14px;
}
.icon_name {
  display: flex;
  align-items: center;
}
.icon_name img {
  margin-right: 10px;
  border-radius: 50%;
}
</style>
