<template>
  <leftMenu :one="'游戏中心'" :route="gameRoute">
    <template slot="leftContent">
      <div class="game_content">
        <div class="game_title">
          全部游戏概况
        </div>
        <div>
          <a-table :pagination="false" :columns="columns" :data-source="data">
          </a-table>
        </div>
      </div>
    </template>
  </leftMenu>
</template>
<script>
import leftMenu from '@/components/LeftMenu/LeftMenu'
import { gameRoute } from '@/api/data'
import { projectGames } from '@/api/project'
const columns = [
  {
    title: '游戏名称',
    imgBaseUrl: '',
    dataIndex: 'name',
    key: 'name',
    scopedSlots: { customRender: 'name' }
  },
  {
    title: '渠道数量',
    dataIndex: 'channels',
    key: 'channels',
    scopedSlots: { customRender: 'type' }
  },
  {
    title: '累计用户（人）',
    dataIndex: 'players',
    key: 'players',
    ellipsis: true
  },
  {
    title: '累计充值（元）',
    dataIndex: 'orders',
    key: 'orders',
    ellipsis: true
  }
]
export default {
  components: {
    leftMenu
  },
  data () {
    return {
      gameRoute,
      columns,
      data: []
    }
  },
  created () {
    projectGames().then(res => {
      console.log(res)
      this.data = res
    })
  }
}
</script>
<style>
.ant-pro-basicLayout-content {
  margin: 0;
}
.game_content {
  margin: 20px 0;
  background-color: #fff;
  box-shadow: 0 1px 1px rgba(0, 0, 0, 0.05);
}
.game_title {
  border-bottom: 1px solid #e9ebef;
  padding: 10px 15px;
  color: #535351;
  font-size: 16px;
  line-height: 30px;
}
.game_title span {
  font-size: 14px;
}
.game_search {
  padding: 21px 15px;
}
.game_content_foot {
  display: flex;
  justify-content: flex-end;
}
.icon_name {
  display: flex;
  align-items: center;
}
.icon_name img {
  margin-right: 10px;
  border-radius: 50%;
}
</style>
