<template>
  <div>
    <a-modal
      title="自定义Meta参数"
      width="800px"
      :visible="visible"
      :confirm-loading="confirmLoading"
      :bodyStyle="{ padding: '0 0 40px 0' }"
      @ok="
        () => {
          $emit('ok')
        }
      "
      @cancel="
        () => {
          $emit('cancel')
        }
      "
    >
      <div class="setting_goods_table">
        <div class="setting_goods_des">
          <p>
            设置自定义参数，能够在打渠道包时配置针对各个渠道不同的参数值，对应客户端SDK提供的自定义参数获取接口，如特定渠道的商品ID配置等。如不需要，可直接忽略。
          </p>
          <p>更多详情参见文档 如何使用自定义参数</p>
        </div>
        <table>
          <tbody>
            <tr>
              <td>自定义参数名称</td>
              <td>操作</td>
            </tr>
            <tr v-for="(item, index) in formData" :key="index">
              <td>{{ item }}</td>
              <td><a @click="delMeta(index)" href="javascript:;">删除</a></td>
            </tr>
            <tr>
              <td><input v-model="metaVal" placeholder="请输入自定义参数" /></td>
              <td><a @click="addMeta" href="javascript:;">添加</a></td>
            </tr>
          </tbody>
        </table>
      </div>
    </a-modal>
  </div>
</template>
<script>
export default {
  data () {
    return {
      formData: [],
      id: 0,
      metaVal: '',
      gameId: 0
    }
  },
  props: {
    visible: {
      type: Boolean,
      default: false
    },
    confirmLoading: {
      type: Boolean,
      default: false
    },
    model: {
      type: Object,
      default: () => ''
    }
  },
  created () {
    this.$watch('model', () => {
      if (this.model && this.model.params) {
        this.formData = this.model.params
        this.id = this.model.id
      } else {
        this.formData = []
        this.id = 0
      }
    })
  },
  methods: {
    addMeta () {
      if (this.metaVal) {
        if (this.formData.indexOf(this.metaVal) > -1) {
          this.$message.error('参数名称不能重复！')
        } else {
          this.formData.push(this.metaVal)
        }
      }
      this.metaVal = ''
    },
    delMeta (index) {
      this.formData.splice(index, 1)
    }
  }
}
</script>
<style scoped>
.setting_goods_des {
  padding: 0;
  color: #9fa9b9;
  font-size: 12px;
  margin-top: 30px;
}
.setting_goods_table {
  margin-top: 30px;
  padding: 0 30px;
}
.setting_goods_table table {
  border: 1px solid #ccc;
  width: 100%;
  text-align: center;
}
.setting_goods_table table td {
  border: 1px solid #ccc;
  padding: 10px 0;
  width: 60%;
}
.setting_goods_table table td input {
  border: none;
  text-align: center;
  outline: none;
}
</style>
