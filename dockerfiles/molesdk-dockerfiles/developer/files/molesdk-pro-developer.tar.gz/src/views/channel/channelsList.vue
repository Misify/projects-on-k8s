<template>
  <div>
    <leftMenu :one="'渠道聚合SDK'" :route="route">
      <template slot="leftContent">
        <div class="margin30">
          <a-card title="可用渠道管理" style="width: 100%">
            <div class="list-tips" style="margin-bottom: 0; overflow: hidden">
              <label>重要提示</label>
              <span style="display: block; float: left; width: 90%">
                1.此页面显示当前帐号可以使用的渠道,可用渠道包含2部分,一为公共渠道,一为自定义渠道<br />
                2.何为自定义渠道,此即是以MOLESDK支持的某渠道为基础,创建一个自定义渠道.用以同一个产品上架多个相同渠道的场景
              </span>
            </div>
            <div class="margin30">
              <a-table :pagination="false" :columns="columns" :data-source="data">
                <span slot="name" slot-scope="text, item">
                  <a-icon type="apple" theme="filled" v-if="item.iOS" :style="{ color: '#1890ff' }" />
                  <a-icon theme="filled" type="android" :style="{ color: '#1890ff' }" v-if="item.Android" />
                  {{ text }}({{ item.version }})
                </span>
                <span slot="desc" slot-scope="text, item">
                  <div class="channel_desc" v-html="item.des"></div>
                </span>
                <!-- <span slot="action">
                  <a-button size="small">创建自定义渠道</a-button>
                </span> -->
              </a-table>
            </div>
          </a-card>
        </div>
      </template>
    </leftMenu>
  </div>
</template>
<script>
import leftMenu from '@/components/LeftMenu/LeftMenu'
import { route } from '@/api/data'
import { channel } from '@/api/games'
const columns = [
  {
    title: '渠道code',
    imgBaseUrl: '',
    dataIndex: 'id',
    key: 'id'
  },
  {
    title: '渠道',
    dataIndex: 'name',
    key: 'name',
    scopedSlots: { customRender: 'name' }
  },
  {
    title: 'SDK版本号',
    dataIndex: 'version',
    key: 'version',
    ellipsis: true
  }
  // {
  //   title: '操作',
  //   dataIndex: 'action',
  //   width: '300px',
  //   scopedSlots: { customRender: 'action' }
  // }
]
export default {
  components: {
    leftMenu
  },
  data () {
    return {
      route,
      data: [],
      columns
    }
  },
  created () {
    channel().then((res) => {
      res.items.forEach((item) => {
        if (item.type.indexOf('iOS') > -1) {
          item.iOS = true
        }
        if (item.type.indexOf('Android') > -1) {
          item.Android = true
        }
        item.des = item.desc
        item.des = item.des.replace(/<br \/>/g, ' ')
      })
      console.log(res)
      this.data = res.items
      this.datas = this.data
    })
  }
}
</script>
