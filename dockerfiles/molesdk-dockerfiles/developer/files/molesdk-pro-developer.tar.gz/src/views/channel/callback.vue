<template>
  <div>
    <leftMenu :one="'渠道聚合SDK'" :route="route">
      <template slot="leftContent">
        <div class="margin30">
          <a-card title="渠道回调地址" style="width: 100%">
            <div class="list-tips" style="margin-bottom: 0; overflow: hidden">
              <label>重要提示</label>
              <span style="display: block; float: left; width: 90%">
                1.运营需要将此列表中提供的回调地址配置到各对应的渠道后台，若不配置则支付 无法到账 。<br />
                2.若列表中标注为“此渠道无需配置回调”，则无需到渠道后台配置，MOLESDK已默认设置。<br />
                3.在渠道后台配置回调地址时需注意回调地址前后是否有空格或回车，渠道后台的填写要求是否URL前包含"http://"，同时注意http后的冒号需为英文符号":"<br />
                4.有些渠道不提供后台的则需将此地址告知给渠道运营人员进行配置。
              </span>
            </div>

            <!-- 表格 -->
            <div class="channel_table">
              <a-table :pagination="false" rowKey="id" :columns="columns" :data-source="data">
                <span slot="callback" slot-scope="text, item">
                  <a href="javascript:;" class="call_a">{{
                    baseUrl + '/api/pay_callback/' + item.id + '/' + gameId
                  }}</a>
                </span>
                <span slot="action" slot-scope="text, item">
                  <a-button
                    size="small"
                    v-clipboard:copy="baseUrl + '/api/pay_callback/' + item.id + '/' + gameId"
                    v-clipboard:success="onCopy"
                    v-clipboard:error="onError"
                  >复制回调地址</a-button
                  >
                </span>
              </a-table>
            </div>
          </a-card>
        </div>
      </template>
    </leftMenu>
  </div>
</template>
<script>
import { route } from '@/api/data'
import { gamesChannel } from '@/api/games'
import leftMenu from '@/components/LeftMenu/LeftMenu'
const columns = [
  {
    title: '渠道Code',
    imgBaseUrl: '',
    dataIndex: 'id',
    key: 'id'
  },
  {
    title: '渠道名称',
    dataIndex: 'name',
    key: 'name',
    scopedSlots: { customRender: 'name' }
  },
  {
    title: '渠道回调地址',
    dataIndex: 'callback',
    key: 'callback',
    scopedSlots: { customRender: 'callback' }
  },
  {
    title: '操作',
    dataIndex: 'action',
    width: '150px',
    scopedSlots: { customRender: 'action' }
  }
]
export default {
  components: {
    leftMenu
  },
  computed: {
    gameId () {
      return this.$store.getters.gameController
    }
  },
  mounted () {
    this.gameId !== 0 && gamesChannel(this.gameId).then((res) => {
      this.data = res.data
    })
  },
  watch: {
    gameId: {
      handler (newval) {
        newval !== 0 && gamesChannel(newval).then((res) => {
          this.data = res.data
        })
      }
    }
  },
  data () {
    return {
      route,
      data: [],
      columns,
      baseUrl: process.env.VUE_APP_API_BASE_URL
    }
  },
  methods: {
    onCopy (e) {
      this.$message.success('复制成功！')
    },
    onError (e) {
      this.$message.error('复制失败！')
    }
  }
}
</script>
<style scoped>
.call_a {
  color: #666;
  text-decoration: underline;
}
</style>
