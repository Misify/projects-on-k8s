<template>
  <div>
    <a-modal
      title="添加渠道"
      width="1100px"
      :visible="visible"
      :confirm-loading="confirmLoading"
      :bodyStyle="{ padding: 0 }"
      @ok="
        () => {
          $emit('ok')
        }
      "
      @cancel="
        () => {
          $emit('cancel')
        }
      "
    >
      <a-spin :spinning="loading">
        <a-tabs
          @change="handleChange"
          v-model="tabKey"
          :tab-position="mode"
          @prevClick="callback"
          @nextClick="callback"
        >
          <a-tab-pane stype="width: 99px" v-for="item in tabs" :key="item" :tab="item">
            <div>
              <div class="select_channel_title">
                <p class="select_channel_title_text">
                  添加渠道 <span>（已经选择{{ value.length }}家）</span>
                </p>
                <!-- <p>
                  <a-input-search placeholder="请输入渠道名称" enter-button @search="onSearch" />
                </p> -->
              </div>
              <a-divider></a-divider>
              <div class="select_channel_group">
                <a-checkbox-group v-model="value">
                  <a-checkbox v-for="(items, index) in channels[item]" :key="index" :value="items.id">
                    {{ items.name }}
                  </a-checkbox>
                </a-checkbox-group>
              </div>
            </div>
          </a-tab-pane>
        </a-tabs>
      </a-spin>
    </a-modal>
  </div>
</template>
<script>
import { channel, gamesChannel } from '@/api/games'
import { mapGetters } from 'vuex'
export default {
  data () {
    return {
      mode: 'left',
      channels: [],
      channelOld: [],
      tabKey: 'Android',
      value: [],
      loading: true,
      tabs: ['Android', 'iOS']
    }
  },
  computed: {
    ...mapGetters(['gameController'])
  },
  watch: {
    gameController: {
      handler (newval) {
        // console.log(newval)
        newval !== 0 && gamesChannel(newval).then((ref) => {
          channel().then((res) => {
            this.channelOld = res.data
            this.resetData(ref.data, res.items)
          })
        })
      },
      deep: true,
      immediate: true
    }
  },
  props: {
    visible: {
      type: Boolean,
      default: () => false
    },
    confirmLoading: {
      type: Boolean,
      default: () => false
    }
  },
  methods: {
    callback () {},
    resetData (items, data) {
      const channels = []
      const remove = []
      items.forEach((items) => {
        remove.push(items.id)
      })
      this.tabs.forEach((res) => {
        data.forEach((item) => {
          if (item.type.indexOf(res) > -1 && remove.indexOf(item.id) < 0) {
            if (!channels[res]) {
              channels[res] = []
            }
            channels[res].push(item)
          }
        })
      })
      this.loading = false
      this.channels = channels
    },
    onSearch (e) {
      let arr = []
      if (e !== '') {
        this.channelOld.forEach((res) => {
          if (res.name.indexOf(e) > -1) {
            arr.push(e)
          }
        })
      } else {
        arr = this.channelOld
      }
      this.channels[this.tabKey] = arr
      this.$set(this.channels, 'Android', arr)
    },
    handleChange (e) {
      this.tabKey = e
    }
  }
}
</script>
<style scoped>
* /deep/ .ant-tabs .ant-tabs-left-bar .ant-tabs-tab {
  width: 100px;
}
.select_channel_title {
  margin-top: 20px;
  padding-right: 30px;
  display: flex;
  height: 30px;
  justify-content: space-between;
  align-items: center;
}
.select_channel_title_text {
  font-size: 16px;
  font-weight: bold;
}
.select_channel_title_text span {
  font-size: 14px;
  font-weight: 400;
}
.select_channel_group {
  padding-bottom: 30px;
}
</style>
