<template>
  <div>
    <leftMenu :one="'渠道聚合SDK'" :route="route">
      <template slot="leftContent">
        <div class="margin30">
          <a-card title="母包测试帐号" style="width: 100%">
            <div class="list-tips" style="margin-bottom: 0; overflow: hidden">
              <label>重要提示</label>
              <span style="display: block; float: left; width: 90%">
                1.MOLESDK支付帐号用于游戏 母包验证支付流程 时使用，不能用于渠道包，渠道包验证支付需要真实进行支付。<br />
                2.母包支付过程中，客户端点击后弹出的[支付成功]和[支付失败]选项仅用于发出客户端通知，服务器发货通知则是以是否使用此处创建的测试帐号且帐号余额足够为判断依据<br />
                3.使用母包测试帐号进行支付的订单，通知游戏报文中的is_test字段值为1。游戏可根据情况在包体上线后，不再向is_test为1的测试订单发放道具。
              </span>
            </div>

            <div class="margin30">
              <a-button @click="add_testUser" type="primary"><a-icon type="plus-circle" />新增</a-button>
            </div>

            <!-- 母包测试账号tab -->
            <div class="margin30">
              <a-table :loading="loading" :pagination="false" rowKey="id" :columns="columns" :data-source="data">
                <span slot="action" slot-scope="text, item">
                  <a-button @click="remove(item)" size="small">删除</a-button>
                </span>
              </a-table>
            </div>
          </a-card>
        </div>
      </template>
    </leftMenu>
    <createtestUser
      ref="create"
      :visible="visible"
      :confirmLoading="confirmLoading"
      :model="model"
      @ok="handleOk"
      @cancel="handleCancel"
    >
    </createtestUser>
  </div>
</template>
<script>
import { route } from '@/api/data'
import leftMenu from '@/components/LeftMenu/LeftMenu'
import createtestUser from './modules/createTestUser'
import { gamesTesters, addGamesTester, delGamesTester } from '@/api/games'
const columns = [
  {
    title: '用户名称',
    imgBaseUrl: '',
    dataIndex: 'name',
    key: 'name'
  },
  {
    title: '创建时间',
    dataIndex: 'created_at',
    key: 'created_at'
  },
  {
    title: '操作',
    dataIndex: 'action',
    width: '150px',
    scopedSlots: { customRender: 'action' }
  }
]
export default {
  components: {
    leftMenu,
    createtestUser
  },
  data () {
    return {
      route,
      columns,
      data: [],
      visible: false,
      confirmLoading: false,
      model: {},
      loading: false
    }
  },
  computed: {
    gameId () {
      return this.$store.getters.gameController
    }
  },
  watch: {
    gameId: {
      handler (newval) {
        newval !== 0 && this.getList()
      },
      deep: true,
      immediate: true
    }
  },
  methods: {
    add_testUser () {
      this.visible = true
    },
    getList () {
      this.loading = true
      gamesTesters(this.gameId).then((res) => {
        this.data = res.data
        this.loading = false
      })
    },
    handleOk () {
      const form = this.$refs.create.form
      this.confirmLoading = true
      form.validateFields((errors, values) => {
        if (!errors) {
          // 新增
          addGamesTester(this.gameId, values)
            .then((res) => {
              this.visible = false
              this.confirmLoading = false
              // 重置表单数据
              form.resetFields()
              // 刷新表格
              this.getList()
              this.$message.info('新增成功')
            })
            .catch((error) => {
              this.confirmLoading = false
              this.$message.error(error.response.data.message)
            })
        }
      })
    },
    remove (record) {
      const that = this
      this.$confirm({
        title: '删除测试账号',
        content: '确定要删除账号？',
        onOk () {
          that.loading = true
          delGamesTester(that.gameId, record.name).then((res) => {
            that.$message.success({
              content: '删除成功！'
            })
            that.getList()
          })
        },
        onCancel () {}
      })
    },
    handleCancel () {
      this.visible = false
      this.confirmLoading = false
      this.$refs.create.form.resetFields()
    }
  }
}
</script>
