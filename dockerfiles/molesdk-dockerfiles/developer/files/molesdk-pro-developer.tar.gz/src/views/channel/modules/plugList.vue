<template>
  <div>
    <a-modal
      :title="'添加第三方插件'"
      width="1000px"
      :visible="visible"
      :bodyStyle="{ padding: 0 }"
      @ok="
        () => {
          $emit('ok')
        }
      "
      @cancel="
        () => {
          $emit('cancel')
        }
      "
    >
      <a-spin :spinning="loading">
        <a-tabs @change="handleChange" v-model="keys" :tab-position="mode" @prevClick="callback" @nextClick="callback">
          <a-tab-pane
            stype="width: 100px"
            v-for="(item, index) in tabs"
            :key="index"
            :tab="item.title + '(' + item.num + ')'"
          >
            <div class="setting_jb">
              <ul>
                <li v-for="items in data" :key="items.id">
                  <div class="plug_ul">
                    <div class="plug_li_img">
                      <img :src="imgBaseUrl + items.img" width="55" />
                    </div>
                    <div class="plug_li_text">
                      <div class="plug_li_text_title">
                        <span>{{ items.name }}</span
                        >版本：{{ items.version }}
                      </div>
                      <div class="plug_li_text_des">{{ items.des }}</div>
                    </div>
                    <div class="plug_li_switch">
                      <a-switch v-model="items.switch" @change="(e) => onChange(e, items)" />
                    </div>
                  </div>
                </li>
              </ul>
            </div>
          </a-tab-pane>
        </a-tabs>
      </a-spin>
    </a-modal>
  </div>
</template>
<script>
import { getPlugs, addChannelPlug, delChannelPlug } from '@/api/games'
export default {
  data () {
    return {
      mode: 'left',
      tabs: [],
      loading: false,
      ids: [],
      keys: 0,
      imgBaseUrl: process.env.VUE_APP_API_BASE_URL,
      data: [],
      datas: []
    }
  },
  created () {
    this.loading = true

    this.$watch('model', () => {
      const ids = []
      console.log(this.model)
      if (this.model.plugs) {
        this.model.plugs.forEach((params) => {
          ids.push(params.id)
        })
      }
      getPlugs().then((res) => {
        let tabs = []
        const indexOfTab = []
        Object.values(res.data).forEach((item) => {
          Object.values(item.type).forEach((ref) => {
            if (indexOfTab.indexOf(ref) < 0) {
              tabs.push({
                title: ref
              })
              indexOfTab.push(ref)
            }
          })
        })
        tabs = this.unique(tabs)
        tabs.forEach((item) => {
          let i = 0
          Object.values(res.data).forEach((ref) => {
            if (ref.type.indexOf(item.title) > -1) {
              i = i + 1
            }
          })
          item.num = i
        })
        tabs.unshift({
          title: '全部插件',
          num: res.data.length
        })
        this.tabs = tabs
        this.loading = false
        this.keys = this.tabKey
        Object.values(res.data).forEach((item) => {
          if (ids.indexOf(item.id) > -1) {
            item.switch = true
          } else {
            item.switch = false
          }
        })
        this.data = res.data
        this.datas = res.data
      })
    })
  },
  props: {
    visible: {
      type: Boolean,
      default: () => false
    },
    confirmLoading: {
      type: Boolean,
      default: () => false
    },
    tabKey: {
      type: Number,
      default: 0
    },
    model: {
      type: Object,
      default: null
    }
  },
  methods: {
    handleChange (e) {
      const arr = []
      if (e === 0) {
        this.data = this.datas
      } else {
        this.datas.forEach((res) => {
          if (res.type.indexOf(this.tabs[e].title) > -1) {
            arr.push(res)
          }
        })
        this.data = arr
      }
      this.keys = e
    },
    callback () {},
    onChange (e, item) {
      const gameId = this.$store.getters.gameController
      if (e) {
        addChannelPlug({ plugId: item.id, channelId: this.model.id, gameId: gameId }).then((res) => {
          this.$emit('updatePlug')
        })
      } else {
        delChannelPlug({ channelId: this.model.id, gameId: gameId }, item.id).then((res) => {
          this.$emit('updatePlug')
        })
      }
    },
    unique (arr) {
      return Array.from(new Set(arr))
    }
  }
}
</script>
<style scoped>
* /deep/ .ant-tabs-nav {
  height: 100%;
}
* /deep/ .ant-tabs .ant-tabs-left-bar .ant-tabs-tab {
  width: 110px;
}
.setting_jb {
  max-height: 60vh;
  overflow-y: scroll;
  padding: 20px 0;
}
.setting_jb ul {
  padding: 0;
}
.setting_jb li {
  width: 95%;
  padding: 8px 10px;
  border: 1px solid #d0d2db;
  margin-bottom: 20px;
  height: 75px;
  position: relative;
}
.plug_ul {
  display: flex;
  justify-content: space-between;
  align-items: center;
}
.plug_li_img {
  width: 55px;
  margin-right: 15px;
}
.plug_li_switch {
  width: 55px;
  margin-left: 15px;
}
.plug_li_text {
  flex: 1;
  color: #b2bbc9;
  font-size: 12px;
}
.plug_li_text span {
  color: #333;
  font-size: 16px;
  font-weight: 500;
  margin-right: 10px;
}
.plug_li_text_title {
  margin-bottom: 5px;
}
.plug_li_text_des {
  color: #333;
}
</style>
