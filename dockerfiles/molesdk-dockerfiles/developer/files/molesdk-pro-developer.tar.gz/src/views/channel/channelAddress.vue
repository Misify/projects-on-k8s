<template>
  <div>
    <leftMenu :one="'渠道聚合SDK'" :route="route">
      <template slot="leftContent">
        <div class="margin30">
          <a-card title="渠道通讯录" style="width: 100%">
            <div class="list-tips" style="margin-bottom: 0; overflow: hidden">
              <label>重要提示</label>
              <span style="display: block; float: left; width: 90%">
                1.为了游戏开发者更好的联系渠道方，整理了一套渠道通讯录以供参考。<br />
                2. 渠道通讯录内容均采集于渠道官网或后台，如有更新不及时，请及时联系我们进行更新。
              </span>
            </div>
            <div class="margin30">
              <a-input-group compact>
                <a-select default-value="name">
                  <a-select-option value="name"> 渠道名称 </a-select-option>
                </a-select>
                <a-input-search placeholder="请输入搜索内容" style="width: 200px" @search="onSearch" />
              </a-input-group>
            </div>
            <div class="channel_table">
              <a-table :pagination="false" rowKey="id" :columns="columns" :data-source="data">
                <span slot="name" slot-scope="text, item">
                  <a-icon type="apple" theme="filled" v-if="item.iOS" :style="{ color: '#1890ff' }" />
                  <a-icon theme="filled" type="android" :style="{ color: '#1890ff' }" v-if="item.Android" />
                  {{ text }}({{ item.version }})
                </span>
                <span slot="desc" slot-scope="text, item">
                  <div class="channel_desc" v-html="item.des"></div>
                </span>
                <span slot="action" slot-scope="text, item">
                  <a-button @click="show(item)" size="small">详细</a-button>
                </span>
              </a-table>
            </div>
          </a-card>
        </div>
      </template>
    </leftMenu>
    <a-modal title="详细" :visible="visible" @ok="handleOk" @cancel="handleCancel">
      <p v-html="ModalText"></p>
    </a-modal>
  </div>
</template>
<script>
import leftMenu from '@/components/LeftMenu/LeftMenu'
import { route } from '@/api/data'
import { channel } from '@/api/games'
const columns = [
  {
    title: '渠道Code',
    imgBaseUrl: '',
    dataIndex: 'id',
    key: 'id'
  },
  {
    title: '渠道名称',
    dataIndex: 'name',
    key: 'name',
    scopedSlots: { customRender: 'name' }
  },
  {
    title: '联系信息',
    dataIndex: 'desc',
    key: 'desc',
    scopedSlots: { customRender: 'desc' }
  },
  {
    title: '操作',
    dataIndex: 'action',
    width: '150px',
    scopedSlots: { customRender: 'action' }
  }
]
export default {
  components: {
    leftMenu
  },
  data () {
    return {
      route,
      columns,
      visible: false,
      ModalText: '',
      data: [],
      datas: [],
      queryParams: {
        type: 'name'
      }
    }
  },
  created () {
    channel().then((res) => {
      res.items.forEach((item) => {
        if (item.type.indexOf('iOS') > -1) {
          item.iOS = true
        }
        if (item.type.indexOf('Android') > -1) {
          item.Android = true
        }
        item.des = item.desc
        item.des = item.des.replace(/<br \/>/g, ' ')
      })
      this.data = res.items
      this.datas = this.data
    })
  },
  methods: {
    onSearch (e) {
      let arr = []
      if (e === '') {
        arr = this.datas
      } else {
        this.datas.forEach((item) => {
          if (item.name.indexOf(e) > -1) {
            arr.push(item)
          }
        })
      }
      this.data = arr
    },
    show (item) {
      this.ModalText = item.desc
      this.visible = true
    },
    handleOk () {
      this.visible = false
    },
    handleCancel () {
      this.visible = false
    }
  }
}
</script>
<style scoped>
.channel_desc {
  max-width: 360px;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
</style>
