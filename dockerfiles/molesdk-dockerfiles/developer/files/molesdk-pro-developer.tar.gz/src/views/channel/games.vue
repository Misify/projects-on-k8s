<template>
  <div>
    <leftMenu :one="'渠道聚合SDK'" :route="route">
      <template slot="leftContent">
        <div class="game_content">
          <a-card title="游戏参数配置" style="width: 100%">
            <a-form :form="form" :label-col="{ span: 5 }" :wrapper-col="{ span: 12 }">
              <a-form-item v-show="false" label="主键ID">
                <a-input v-decorator="['id', { initialValue: 0 }]" disabled />
              </a-form-item>
              <a-form-item label="APP_ID" required>
                <span class="ant-col-24 con_style" style="word-break: break-all">
                  {{ model.id }}
                  <span
                    v-clipboard:copy="model.id"
                    v-clipboard:success="copySuccess"
                    v-clipboard:error="copyError"
                  >复制</span
                  >
                </span>
              </a-form-item>
              <a-form-item label="APP_KEY" required>
                <span class="ant-col-24 con_style" style="word-break: break-all">
                  {{ model.key }}
                  <span
                    v-clipboard:copy="model.key"
                    v-clipboard:success="copySuccess"
                    v-clipboard:error="copyError"
                  >复制</span
                  >
                </span>
              </a-form-item>
              <a-form-item label="PUBLIC_KEY" required>
                <span class="ant-col-24 con_style" style="word-break: break-all">
                  {{ model.pub_key }}
                  <span
                    v-clipboard:copy="model.pub_key"
                    v-clipboard:success="copySuccess"
                    v-clipboard:error="copyError"
                  >复制</span
                  >
                </span>
              </a-form-item>
              <a-form-item label="APP_SECRET" required>
                <span class="ant-col-24 con_style" style="word-break: break-all">
                  {{ model.secret }}
                  <span
                    v-clipboard:success="copySuccess"
                    v-clipboard:error="copyError"
                    v-clipboard:copy="model.secret"
                  >复制</span
                  >
                </span>
              </a-form-item>
              <a-form-item label="游戏名称">
                <a-input
                  placeholder="请填写游戏名称"
                  v-decorator="['name', { rules: [{ required: true, message: '游戏名称必须填写' }] }]"
                />
              </a-form-item>
              <a-form-item label="游戏类别">
                <a-select
                  v-decorator="['type', { rules: [{ required: true, message: 'Please select your gender!' }] }]"
                  placeholder="请选择一个游戏类别"
                >
                  <a-select-option :value="item.value" v-for="item in gameType" :key="item.label">
                    {{ item.label }}
                  </a-select-option>
                </a-select>
              </a-form-item>
              <a-form-item
                label="CALLBACK_URL"
                help="游戏接收到账通知的URL，MoleSDK在渠道充值成功后会向URL发送同步请求"
              >
                <a-input
                  placeholder="pay_callback"
                  v-decorator="['pay_callback', { rules: [{ required: true, message: 'Callback_Url不能为空' }] }]"
                />
              </a-form-item>
              <a-form-item label="游戏ICON">
                <a-upload
                  v-decorator="['icon', { rules: [{ required: true, message: '必须上传ICON' }] }]"
                  name="icon"
                  list-type="picture-card"
                  class="avatar-uploader"
                  :show-upload-list="false"
                  :action="uploadIconsUrl"
                  :before-upload="beforeUpload"
                  :headers="header"
                  @change="handleChange"
                >
                  <img v-if="imageUrl" width="86px" :src="imgBaseUrl + imageUrl" alt="avatar" />
                  <div v-else>
                    <a-icon :type="loading ? 'loading' : 'upload'" />
                    <div class="ant-upload-text">选择ICON</div>
                  </div>
                </a-upload>
                <div class="upload_des">
                  <div><span>*</span>请上传您的游戏ICON，此ICON用于在线制作各渠道角标ICON</div>
                  <div><span>*</span>必须上传PNG格式的图片。大小：小于2M</div>
                </div>
              </a-form-item>
              <a-form-item :wrapper-col="{ span: 12, offset: 5 }">
                <a-button type="primary" @click="handleSubmit"> 保存 </a-button>
              </a-form-item>
            </a-form>
          </a-card>
        </div>
      </template>
    </leftMenu>
  </div>
</template>
<script>
import pick from 'lodash.pick'
import { route, gameType } from '@/api/data'
import { gameInfo, gameUpdate } from '@/api/games'
import leftMenu from '@/components/LeftMenu/LeftMenu'
import { ACCESS_TOKEN } from '@/store/mutation-types'
import storage from 'store'
import { mapGetters } from 'vuex'
const fields = ['name', 'id', 'icon', 'type', 'pub_key', 'secret', 'pay_callback']
export default {
  data () {
    return {
      route,
      gameType,
      model: {},
      form: this.$form.createForm(this),
      loading: false,
      imgBaseUrl: process.env.VUE_APP_API_BASE_URL,
      uploadIconsUrl: process.env.VUE_APP_API_BASE_URL + '/api/developer/game/icon',
      imageUrl: '',
      header: {
        'Authorization': 'Bearer ' + storage.get(ACCESS_TOKEN)
      }
    }
  },
  components: {
      leftMenu
  },
  computed: {
    ...mapGetters(['gameController'])
  },
  watch: {
    gameController: {
      handler (newval) {
        newval !== 0 && this.getGameInfo(newval)
      },
      deep: true,
      immediate: true
    }
  },
  methods: {
    getGameInfo (gameController) {
      gameInfo(this.$store.getters.gameController).then(res => {
        this.model = res.data
        this.imageUrl = this.model.icon
        fields.forEach(v => this.form.getFieldDecorator(v))
        this.form.setFieldsValue(pick(this.model, fields))
      })
    },
    beforeUpload (file) {
      const isJpgOrPng = file.type === 'image/png'
      if (!isJpgOrPng) {
        this.$message.error('只能上传png格式的图片!')
      }
      const isLt2M = file.size / 1024 / 1024 < 2
      if (!isLt2M) {
        this.$message.error('图片大小不得超过2M')
      }
      return isJpgOrPng && isLt2M
    },
    handleChange (response) {
      if (response.file.response) {
      this.imageUrl = response.file.response.url
      }
    },
    copySuccess () {
      this.$message.success(
        '复制成功'
      )
    },
    copyError () {
      this.$message.error('复制失败！暂不支持')
    },
    handleSubmit () {
      this.form.validateFields((errors, values) => {
        if (!errors) {
          values.icon = this.imageUrl
          gameUpdate(values, values.id).then(res => {
            this.gameInfoConfirmg = false
            this.gameInfoVisible = false
            this.$message.info('修改成功')
            // 设置vuex games
            this.$store.dispatch('setGame')
          })
        } else {
          this.gameInfoConfirmg = false
        }
      })
    }
  }
}
</script>
<style scoped>
.game_content {
  margin-top: 20px;
}
.upload_des {
  margin-top: -15px;
  line-height: 24px;
  color: #9fa9b9;
  font-size: 12px;
}
.upload_des div {
  height: 24px;
}
.upload_des div span {
  color: red;
}
.con_style {
  cursor: pointer;
}
.con_style span {
  text-decoration: underline;
  margin-left: 10px;
  cursor: pointer;
  color: #1890ff;
}
</style>
