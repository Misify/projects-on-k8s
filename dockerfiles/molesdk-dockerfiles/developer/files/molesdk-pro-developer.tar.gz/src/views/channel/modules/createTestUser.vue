<template>
  <div>
    <a-modal
      title="添加母包测试账号"
      width="1100px"
      :visible="visible"
      :confirm-loading="confirmLoading"
      @ok="
        () => {
          $emit('ok')
        }
      "
      @cancel="
        () => {
          $emit('cancel')
        }
      "
    >
      <a-spin :spinning="loading">
        <a-form :form="form" :label-col="{ span: 5 }" :wrapper-col="{ span: 12 }">
          <a-form-item v-show="model && model.id > 0" label="主键ID">
            <a-input v-decorator="['id', { initialValue: 0 }]" disabled />
          </a-form-item>
          <a-form-item label="账户名称">
            <a-input
              placeholder="请填写账户名称"
              v-decorator="['name', { rules: [{ required: true, message: '账户名称必须填写' }] }]"
            />
          </a-form-item>
          <a-form-item label="密码">
            <a-input-password
              v-decorator="['password', { rules: [{ required: true, message: '账户名称必须填写' }] }]"
              placeholder="请输入密码"
            />
          </a-form-item>
          <a-form-item label="确认密码">
            <a-input-password
              v-decorator="['conf_password', { rules: [{ required: true, message: '账户名称必须填写' }] }]"
              placeholder="请再次输入密码"
            />
          </a-form-item>
        </a-form>
      </a-spin>
    </a-modal>
  </div>
</template>
<script>
import pick from 'lodash.pick'
const fields = ['name', 'id', 'password']
export default {
  props: {
    visible: {
      type: Boolean,
      default: () => false
    },
    confirmLoading: {
      type: Boolean,
      default: () => false
    },
    model: {
      type: Object,
      default: null
    }
  },
  data () {
    return {
      form: this.$form.createForm(this),
      loading: false
    }
  },
  created () {
    // 防止表单未注册
    fields.forEach((v) => this.form.getFieldDecorator(v))
    // 当 model 发生改变时，为表单设置值
    this.$watch('model', () => {
      this.model && this.form.setFieldsValue(pick(this.model, fields))
    })
  }
}
</script>
