<template>
  <div>
    <leftMenu :one="'渠道聚合SDK'" :route="route">
      <template slot="leftContent">
        <div class="game_content">
          <a-card title="渠道参数配置" style="width: 100%">
            <a slot="extra" href="#"><a-icon type="question-circle" /> 如何使用MOLESDK？</a>
            <div class="list-tips" style="margin-bottom: 0; overflow: hidden">
              <label style="height: 90px">重要提示</label>
              <span style="display: block; float: left; width: 90%">
                1.正确填入每个渠道的每项参数后，方可打包测试此渠道流程，客户端参数有误可能引起游戏包无法 调起登录或支付
                等现象，服务器参数错误可能引起反复弹出登录、
                <a href="" target="_blank">无法到账</a>等。<br />
                2.
                自定义参数可以用来动态的向打出的渠道包写入参数，适用场景如推送，每个渠道包因为包名不同需要设置不同的推送ID，使用方法见
                <a href="" target="_blank">自定义参数说明</a>。<br />
                3.发货地址是一个Http协议的URL接口，由游戏开发者提供，MoleSDK会在玩家支付完成后向此API发送数据报文，游戏接受到数据后需要按报文中的金额向玩家发送道具，
                <a href="" target="_blank">发货接口文档 </a>。
                <br />
                4.有时因为渠道更新新加入参数，致原本出包状态成功的渠道可能在打包工具上无法出包，此时需重新检查此渠道参数填入新增的参数重新保存即可。
                <br />
                5.通常一个渠道仅需制作一个分包，若特殊情况同一个渠道需制作多个分包，可使用
                <a href="">自定义渠道功能</a>
                ，此渠道将获得一个新的channelCode，数据也独立统计
              </span>
            </div>
            <div class="channel_search">
              <div class="channel_search_div">
                <a-button type="primary" @click="addChannel"><a-icon type="plus-circle" />添加渠道</a-button>
                <a-button @click="addMeta">自定义Meta参数</a-button>
                <a-button @click="saveGameInfo">游戏参数</a-button>
              </div>
              <div class="channel_search_div">
                <a-select style="width: 120px; margin-right: 10px" :value="queryParams.type" @change="handleChange">
                  <a-select-option value=""> 全部 </a-select-option>
                  <a-select-option value="Android"> Android </a-select-option>
                  <a-select-option value="iOS"> iOS </a-select-option>
                </a-select>
                <a-select style="width: 120px; margin-right: 10px" :value="state" @change="handleStateChange">
                  <a-select-option value=""> 配置状态 </a-select-option>
                  <a-select-option value="1"> 可用 </a-select-option>
                  <a-select-option value="0"> 不可用 </a-select-option>
                </a-select>
                <p>
                  <a-input-group compact>
                    <a-select default-value="name">
                      <a-select-option value="name"> 渠道名称 </a-select-option>
                    </a-select>
                    <a-input-search placeholder="请输入搜索内容" style="width: 200px" @search="onSearch" />
                  </a-input-group>
                </p>
              </div>
            </div>

            <div>
              <a-table :loading="loading" :pagination="false" rowKey="id" :columns="columns" :data-source="data">
                <span slot="name" slot-scope="text, item">
                  <a-icon type="apple" theme="filled" v-if="item.iOS" :style="{ color: '#1890ff' }" />
                  <a-icon theme="filled" type="android" :style="{ color: '#1890ff' }" v-if="item.Android" /> {{ text }}
                </span>
                <span slot="plug" slot-scope="text, item" class="xs" @click="addPlug(item)">
                  <div v-if="item.plugs">
                    <a-badge :count="item.plugs.length">
                      <a-icon theme="filled" :style="{ fontSize: '22px', color: '#1890ff' }" type="plus-circle" />
                    </a-badge>
                  </div>
                  <div v-else>
                    <a-icon theme="filled" :style="{ fontSize: '22px', color: '#1890ff' }" type="plus-circle" />
                  </div>
                </span>
                <span class="xs" slot="is_goods" slot-scope="text, item">
                  <a-icon
                    type="stop"
                    v-if="text === 0"
                    @click="goodsNull"
                    :style="{ fontSize: '22px', color: '#d9d9d9' }"
                  />
                  <a-icon
                    theme="filled"
                    v-else-if="item.goods"
                    @click="showGoods(item)"
                    :style="{ fontSize: '22px', color: '#52c41a' }"
                    type="check-circle"
                  />
                  <a-icon
                    theme="filled"
                    v-else
                    @click="showGoods(item)"
                    :style="{ fontSize: '22px', color: '#ffc53d' }"
                    type="exclamation-circle"
                  />
                </span>
                <span class="xs" slot="icon" @click="uploadIcon(item)" slot-scope="text, item">
                  <a-icon
                    theme="filled"
                    type="exclamation-circle"
                    v-if="!text"
                    :style="{ fontSize: '22px', color: '#ffc53d' }"
                  />
                  <a-icon theme="filled" v-else :style="{ fontSize: '22px', color: '#52c41a' }" type="check-circle" />
                </span>
                <span class="xs" slot="state" slot-scope="text">
                  <a-icon
                    theme="filled"
                    type="check-circle"
                    v-if="text"
                    :style="{ fontSize: '22px', color: '#52c41a' }"
                  />
                  <a-icon
                    theme="filled"
                    v-else
                    :style="{ fontSize: '22px', color: '#ffc53d' }"
                    type="exclamation-circle"
                  />
                </span>
                <span slot="action" slot-scope="text, item">
                  <a-button size="small" @click="channelSetting(item)">配置</a-button>
                  <a-divider type="vertical" />
                  <a-button size="small" @click="delChannel(item)">删除</a-button>
                </span>
              </a-table>
            </div>
          </a-card>
        </div>
      </template>
    </leftMenu>
    <addChannel
      :key="str"
      ref="addChannel"
      :visible="addChannelVisible"
      :confirmLoading="addChannelLoading"
      @ok="addChannelOk"
      @cancel="addChannelCancel"
    >
    </addChannel>
    <channelSetting
      ref="settingChannel"
      :model="md1"
      :tabKey="tabKey"
      :visible="settingChannelVisible"
      :confirmLoading="settingChannelLoading"
      @updateKeys="updateKeys"
      @ok="settingChannelOk"
      @cancel="settingChannelCancel"
    >
    </channelSetting>
    <gameSave
      ref="gameInfo"
      @cancel="gameInfoCancle"
      @ok="gameInfoOk"
      :model="gameMdl"
      :gameType="gameType"
      :visible="gameInfoVisible"
      :confirmLoading="gameInfoConfirmg"
    >
    </gameSave>
    <plugList
      @cancel="plugCancle"
      @ok="plugOk"
      @updatePlug="updatePlug"
      :model="plugMdl"
      :visible="plugVisible"
      :confirmLoading="plugConfirmg"
      ref="plugList"
    >
    </plugList>
    <addMeta
      @cancel="metaCancle"
      @ok="metaOk"
      :visible="metaVisible"
      :confirmLoading="metaConfirmg"
      :model="metaMdl"
      ref="metaList"
    >
    </addMeta>
  </div>
</template>
<script>
import {
  gamesAddChannel,
  gamesChannel,
  gamesHasChannel,
  updateParams,
  gameUpdate,
  deleteGamesChannel,
  metaAdd,
  metaList,
  getPlugs
} from '@/api/games'
import addChannel from './modules/addChannel'
import channelSetting from './modules/channelSetting'
import gameSave from './modules/gameSave'
import leftMenu from '@/components/LeftMenu/LeftMenu'
import plugList from './modules/plugList'
import addMeta from './modules/addMeta'
import { route, gameType } from '@/api/data'

const columns = [
  {
    title: '渠道Code',
    imgBaseUrl: '',
    dataIndex: 'id',
    key: 'id'
  },
  {
    title: '渠道名称',
    dataIndex: 'name',
    key: 'name',
    scopedSlots: { customRender: 'name' }
  },
  {
    title: 'SDK版本',
    dataIndex: 'version',
    key: 'version'
  },
  {
    title: '包名/bundleID',
    dataIndex: 'bundle_id',
    key: 'bundle_id',
    scopedSlots: { customRender: 'bundleID' }
  },
  {
    title: '组件',
    dataIndex: 'plug',
    key: 'plug',
    scopedSlots: { customRender: 'plug' }
  },
  {
    title: '商品',
    dataIndex: 'is_goods',
    key: 'is_goods',
    scopedSlots: { customRender: 'is_goods' }
  },
  {
    title: 'ICON',
    dataIndex: 'icon',
    key: 'icon',
    scopedSlots: { customRender: 'icon' }
  },
  {
    title: '配置状态',
    dataIndex: 'state',
    key: 'state',
    scopedSlots: { customRender: 'state' }
  },
  {
    title: '操作',
    dataIndex: 'action',
    width: '150px',
    scopedSlots: { customRender: 'action' }
  }
]
export default {
  data () {
    return {
      route,
      columns,
      str: '',
      // gameId: 0,
      addChannelVisible: false,
      addChannelLoading: false,
      settingChannelVisible: false,
      settingChannelLoading: false,
      gameInfoVisible: false,
      gameInfoConfirmg: false,
      plugVisible: false,
      plugConfirmg: false,
      metaVisible: false,
      metaConfirmg: false,
      metaMdl: {},
      data: [],
      datas: [],
      state: '',
      gameMdl: {},
      plugMdl: {},
      tabKey: '1',
      loading: false,
      gameType,
      md1: {},
      queryParams: {
        name: '',
        type: ''
      }
    }
  },
  components: {
    leftMenu,
    addChannel,
    gameSave,
    channelSetting,
    plugList,
    addMeta
  },
  computed: {
    gameId () {
      return this.$store.getters.gameController
    }
  },
  watch: {
    gameId: {
      handler (newval) {
        newval !== 0 && this.getList()
      },
      deep: true,
      immediate: true
    }
  },
  methods: {
    addMeta () {
      this.metaVisible = true
      metaList(this.gameId).then((res) => {
        this.metaMdl = { ...res }
      })
    },
    metaCancle () {
      this.metaVisible = false
      this.metaConfirmg = false
    },
    metaOk () {
      const meta = this.$refs.metaList
      this.metaConfirmg = true
      metaAdd(this.gameId, { params: meta.formData }).then((res) => {
        this.metaVisible = false
        this.metaConfirmg = false
      })
    },
    plugCancle () {
      this.plugVisible = false
      this.plugConfirmg = false
    },
    plugOk () {
      this.plugVisible = false
      this.plugConfirmg = false
    },
    updatePlug () {
      this.getList()
    },
    handleChange (e) {
      this.sdata(e, this.state, this.queryParams.name)
      this.queryParams.type = e
    },
    handleStateChange (e) {
      this.sdata(this.queryParams.type, e, this.queryParams.name)
      this.state = e
    },
    onSearch (e) {
      this.sdata(this.queryParams.type, this.state, e)
      this.queryParams.name = e
    },
    // 筛选
    sdata (type, state, val) {
      let arr = []
      if (state.toString() === '0') {
        this.datas.forEach((item) => {
          if (!item.state) {
            arr.push(item)
          }
        })
      } else if (state.toString() === '1') {
        this.datas.forEach((item) => {
          if (item.state) {
            arr.push(item)
          }
        })
      } else {
        arr = Object.values(Object.assign({}, this.datas))
      }
      if (type !== '') {
        arr.forEach((item, index) => {
          if (item.type.indexOf(type) < 0) {
            arr[index] = ''
          }
        })
      }
      if (val !== '') {
        arr.forEach((ref, ind) => {
          if (ref !== '') {
            if (ref.name.indexOf(val) < 0) {
              arr[ind] = ''
            }
          }
        })
      }
      const arr1 = []
      arr.forEach((r) => {
        if (r !== '') {
          arr1.push(r)
        }
      })

      this.data = arr1
    },
    getList () {
      this.loading = true
      gamesChannel(this.gameId).then((res) => {
        res.data.forEach((item) => {
          if (item.type.indexOf('iOS') > -1) {
            item.iOS = true
          }
          if (item.type.indexOf('Android') > -1) {
            item.Android = true
          }
          item.state = true
          if (item.params) {
            for (const key in item.params) {
              for (const keys in item.params[key]) {
                if (!item.params[key][keys]) {
                  item.state = false
                }
              }
            }
          } else {
            item.state = false
          }
        })
        this.loading = false
        this.data = res.data
        this.datas = res.data
      })
    },
    channelSetting (item) {
      this.tabKey = '1'
      this.settingData(item)
    },
    // 上传icon
    uploadIcon (item) {
      this.tabKey = '2'
      this.settingData(item)
    },
    // 编辑goods
    showGoods (item) {
      this.tabKey = '4'
      this.settingData(item)
    },
    // 遍历数据
    settingData (item) {
      this.settingChannelVisible = true
      this.settingChannelLoading = true
      gamesHasChannel(this.gameId, item.id).then((res) => {
        getPlugs({ gameId: this.gameId, channelId: item.id }).then(plugsConfig => {
          const { data } = plugsConfig
          const plugsConfigResult = {}
          data.forEach(item => {
            plugsConfigResult[item.id] = item
          })
          const { plugs } = res
          plugs && plugs.forEach((plug, plugIndex) => {
            plug.params.forEach((param, paramIndex) => {
              plugsConfigResult[plug.id].params.forEach(i => {
                if (i.key === param.key) {
                  plugs[plugIndex].params[paramIndex] = { ...i, ...param }
                }
              })
            })
          })
          this.md1 = { ...res }
          this.settingChannelLoading = false
        })
      })
    },
    addChannel () {
      this.str = Date.parse(new Date())
      this.addChannelVisible = true
    },
    // 删除渠道
    delChannel (item) {
      const that = this
      this.$confirm({
        title: '删除渠道',
        content: '确定要删除渠道？',
        onOk () {
          that.loading = true
          deleteGamesChannel(that.gameId, item.id).then((res) => {
            that.$message.success({
              content: '删除成功！'
            })
            that.getList()
          })
        },
        onCancel () {}
      })
    },
    settingChannelOk () {
      const settingChannel = this.$refs.settingChannel
      const values = Object.assign({}, settingChannel.formData)
      this.settingChannelLoading = true
      for (const key in values.params) {
        for (const keys in values.params[key]) {
          if (values.params[key][keys].required && !values.params[key][keys].value) {
            this.$message.error(values.params[key][keys].key + '必填')
            this.settingChannelLoading = false
            return false
          }
        }
      }
      delete values.plugins
      values.plugs && values.plugs.forEach((plug, plugIndex) => {
        let paramObj = []
        plug.params && plug.params.forEach((param, paramIndex) => {
          paramObj = [...paramObj, {
            key: param.key,
            value: param.value || ''
          }]
        })
        values.plugs[plugIndex].params = paramObj
      })
      updateParams(this.gameId, values.id, values).then((res) => {
        this.settingChannelVisible = false
        this.settingChannelLoading = false
        this.$message.success('保存成功！')
        this.getList()
      })
    },
    settingChannelCancel () {
      this.settingChannelVisible = false
      this.settingChannelLoading = false
    },
    addChannelOk () {
      if (this.$refs.addChannel.value.length === 0) {
        this.$message.warning('请至少选择一个渠道！')
      } else {
        gamesAddChannel(this.gameId, { channel_id: this.$refs.addChannel.value.join(',') }).then((res) => {
          this.$message.success('添加成功！')
          this.addChannelVisible = false
          this.addChannelLoading = false
          this.$refs.addChannel.value = []
          this.getList()
        })
      }
    },
    addChannelCancel () {
      this.addChannelVisible = false
      this.addChannelLoading = false
      this.$refs.addChannel.value = []
    },
    // 更新tabKyes
    updateKeys (id) {
      this.tabKey = id
    },
    gameInfoCancle () {
      this.gameInfoVisible = false
      this.gameInfoConfirmg = false
      const form = this.$refs.gameInfo.form
      this.$refs.gameInfo.imageUrl = ''
      form.resetFields() // 清理表单数据（可不做）
    },
    gameInfoOk () {
      const form = this.$refs.gameInfo.form
      this.gameInfoConfirmg = true

      form.validateFields((errors, values) => {
        if (!errors) {
          values.icon = this.$refs.gameInfo.imageUrl
          gameUpdate(values, values.id).then((res) => {
            this.gameInfoConfirmg = false
            this.gameInfoVisible = false
            this.$message.info('修改成功')
            // 设置vuex games
            this.$store.dispatch('setGame')
          })
        } else {
          this.gameInfoConfirmg = false
        }
      })
    },
    goodsNull () {
      this.$message.warning('暂无渠道商品配置')
    },
    saveGameInfo () {
      this.gameInfoVisible = true
      const games = this.$store.getters.games
      games.forEach((item) => {
        if (item.id.toString() === this.gameId.toString()) {
          this.gameMdl = { ...item }
        }
      })
    },
    addPlug (item) {
      this.plugVisible = true
      this.plugMdl = { ...item }
    }
  }
}
</script>
<style scoped>
.list-tips {
  padding: 14px 20px;
  line-height: 20px;
  color: #666;
  font-size: 12px;
  background: #f6fcff;
  border-radius: 3px;
  border: 1px dashed #90ceff;
  display: flex;
}
.list-tips label {
  margin-right: 15px;
}
.list-tips a {
  color: red;
  text-decoration: underline;
}
.channel_search {
  display: flex;
  margin: 20px 0;
  justify-content: space-between;
}
.channel_search .channel_search_div {
  display: flex;
}
.channel_search button {
  margin-right: 10px;
}
.game_content {
  margin-top: 20px;
}
.xs {
  cursor: pointer;
}
</style>
