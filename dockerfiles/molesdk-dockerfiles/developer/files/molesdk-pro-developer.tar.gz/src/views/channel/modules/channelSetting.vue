<template>
  <div>
    <a-modal
      :title="'配置渠道参数-' + model.cname"
      width="1200px"
      :visible="visible"
      :bodyStyle="{ padding: 0, height: '70vh' }"
      @ok="
        () => {
          $emit('ok')
        }
      "
      @cancel="
        () => {
          $emit('cancel')
        }
      "
    >
      <a-spin :spinning="confirmLoading">
        <a-tabs :activeKey="keys" :tab-position="mode" @change="handleChange">
          <a-tab-pane key="1" stype="width: 99px" tab="基础配置">
            <div class="setting_jb">
              <div class="setting_jb_title">
                <h3>{{ model.cname }}</h3>
              </div>
              <div class="setting_jb_des" v-html="model.abstract"></div>
              <div class="setting_jb_form">
                <a-form :form="form" :label-col="{ span: 5 }" :wrapper-col="{ span: 12 }">
                  <div class="setting_form_title">客户端参数 <span>(修改客户端参数需重新打包,不会影响线上)</span></div>
                  <span v-if="model.params">
                    <a-form-item
                      :required="client.required"
                      v-for="(client, index1) in model.params.client"
                      :help="client.desc"
                      :key="index1"
                      :label="client.key"
                    >
                      <a-input v-model="client.value" />
                    </a-form-item>
                  </span>

                  <div class="setting_form_title">
                    服务端参数 <span>(修改服务器参数会即时影响线上游戏,请谨慎操作)</span>
                  </div>
                  <span v-if="model.params">
                    <a-form-item
                      v-for="(server, index2) in model.params.server"
                      :key="index2"
                      :help="server.desc"
                      :label="server.key"
                    >
                      <a-input v-model="server.value" />
                    </a-form-item>
                  </span>
                  <div v-if="model.params && model.params.other.length > 0" class="setting_form_title">
                    其他参数 <span>(修改其他参数需重新打包)</span>
                  </div>
                  <span v-if="model.params && model.params.other">
                    <a-form-item
                      v-for="(other, index3) in model.params.other"
                      :help="other.desc"
                      :key="index3"
                      :label="other.key"
                    >
                      <a-input v-model="other.value" />
                    </a-form-item>
                  </span>
                  <div
                    v-if="model.params && model.params.meta && model.params.meta.length > 0"
                    class="setting_form_title"
                  >
                    产品自定义参数
                  </div>
                  <span v-if="model.params && model.params.meta">
                    <a-form-item v-for="(meta, index4) in model.params.meta" :key="index4" :label="meta.key">
                      <a-input v-model="meta.value" />
                    </a-form-item>
                  </span>
                </a-form>
              </div>
            </div>
          </a-tab-pane>
          <a-tab-pane key="2" stype="width: 99px" tab="ICON">
            <div class="setting_upload_des">
              <p><span>*</span> 原始图片来源于游戏设置中上传的游戏ICON，如需替换请更改游戏ICON图标</p>
              <p><span>*</span> 最终生成的游戏渠道角标可在渠道列表中ICON预览</p>
            </div>
            <div class="setting_upload_title">上传ICON</div>
            <div class="setting_upload">
              <a-upload
                name="icon"
                list-type="picture-card"
                class="avatar-uploader"
                :show-upload-list="false"
                :action="action"
                :headers="header"
                :before-upload="beforeUpload"
                @change="handleUploadChange"
              >
                <img v-if="formData.icon" width="100%" :src="imgBaseUrl + formData.icon" alt="avatar" />
                <div v-else>
                  <a-icon :type="loading ? 'loading' : 'cloud-upload'" />
                  <div class="ant-upload-text">选择ICON</div>
                </div>
              </a-upload>
              <div class="setting_upload_icon_des">
                <div>
                  <p><span>*</span> 如渠道有特定角标的要求，请上传带有渠道角标的图标，否则使用游戏包的默认图标;</p>
                  <p>
                    <span>*</span> 必须上传PNG格式的图片;建议图片大小：<span>Android：512*51，iOS：1024*1024。</span>
                  </p>
                  <p><span>*</span> iOS游戏建议不要包含透明度。</p>
                </div>
              </div>
            </div>
          </a-tab-pane>
          <a-tab-pane key="3" stype="width: 99px" tab="闪屏">
            <div class="margin30 SpUpload">
              <a-upload
                :action="SpAction"
                list-type="picture-card"
                :fileList="fileLists"
                :headers="header"
                @preview="handlePreview"
                @change="handleSpChange"
              >
                <a-icon :type="SpLoading ? 'loading' : 'cloud-upload'" />
                <div class="ant-upload-text">上传闪屏</div>
              </a-upload>
            </div>
          </a-tab-pane>
          <a-tab-pane key="4" stype="width: 99px" tab="渠道商品ID">
            <div class="setting_goods_table" v-if="formData.is_goods">
              <a-row style="margin-bottom: 20px">
                <a-col :span="3">
                  <a-upload
                    name="file"
                    :multiple="false"
                    :action="UploadCsv"
                    :headers="header"
                    @change="handleCsvChange"
                    :show-upload-list="false"
                  >
                    <a-button type="primary" style="margin-right: 20px"><a-icon type="upload" /> 上传csv</a-button>
                  </a-upload>
                </a-col>
                <a-col :span="4">
                  <a-button type="danger" @click="clearGoods"><a-icon type="delete" /> 一键清除</a-button>
                </a-col>
                <a-col>
                  <a-button type="link" icon="download" @click="downloadTemplate">下载CSV模板</a-button>
                </a-col>
              </a-row>
              <div class="goods_table">
                <table>
                  <tbody>
                    <tr>
                      <td>游戏商品ID</td>
                      <td>渠道商品ID</td>
                      <td>操作</td>
                    </tr>
                    <tr v-for="(item, index) in formData.goods" :key="index">
                      <td>{{ index }}</td>
                      <td>{{ item }}</td>
                      <td><a @click="delGoods(index)" href="javascript:;">删除</a></td>
                    </tr>
                    <tr>
                      <td>
                        <input v-model="goodId" placeholder="请输入游戏商品ID" />
                      </td>
                      <td><input v-model="channelId" placeholder="请输入渠道商品ID" /></td>
                      <td><a @click="addGoods" href="javascript:;">添加</a></td>
                    </tr>
                  </tbody>
                </table>
              </div>

              <div class="setting_goods_des">
                <p>商品ID说明：</p>
                <p>1.游戏商品ID即游戏制定的商品ID，渠道商品ID即在渠道后台配置的商品ID</p>
                <p>2.游戏配置商品ID后，客户端下单时可以直接传入游戏商品ID，Quick会转换成设置的渠道商品ID</p>
                <p>3.游戏若不在此配置商品ID，则游戏客户端下单时设置orderInfo.goodsID时需自行指定渠道商品ID</p>
                <p>4.修改后需要重新打包</p>
              </div>
            </div>
            <div class="setting_goods_else" v-else>该渠道无需配置商品信息</div>
          </a-tab-pane>
          <a-tab-pane key="5" stype="width: 99px" tab="插件参数">
            <div class="margin30 setting_plug" v-if="model.plugs && model.plugs.length > 0">
              <div v-for="plu in model.plugs" :key="plu.id">
                <div class="setting_form_title">{{ plu.name }}参数配置</div>
                <span v-if="plu.params">
                  <a-form-item
                    :label-col="{ span: 5 }"
                    :wrapper-col="{ span: 17 }"
                    :help="params.des"
                    v-for="(params, index4) in plu.params"
                    :key="index4"
                    :label="params.key"
                  >
                    <!-- 推送厂商设置 -->
                    <a-card
                      v-if="params.key === 'manufacturer'"
                    >
                      <a-descriptions v-for="item in Object.keys(params.value || {})" :key="item" :column="2">
                        <template #title>
                          <a-row type="flex" justify="space-between">
                            <a-col>{{ item }}</a-col>
                            <!-- 删除按钮 -->
                            <a-col>
                              <a-button
                                shape="circle"
                                size="small"
                                @click="btnRemoveManufacturerClick(item)">
                                <a-icon type="minus"></a-icon>
                              </a-button>
                            </a-col>
                          </a-row>
                        </template>
                        <a-descriptions-item v-for="ite in Object.keys(params.value[item])" :key="ite" :label="ite">
                          <!-- 上传文件 -->
                          <div v-if="isUpload(params, item)" style="display: flex; align-items: center;">
                            <a-input
                              v-model="params.value[item][ite]"
                              :title="params.value[item][ite]"
                              :ref="`pushInput_${item}_${ite}`"
                              @focus="(e) => { e.target.blur() }"
                              @input="() => {}"
                            ></a-input>
                            <a-button size="small" type="primary" shape="circle" @click="() => { pushInputAfterBtnClick(item, ite) }"><a-icon type="upload"></a-icon></a-button>
                          </div>
                          <!-- 输入框 -->
                          <a-input
                            v-else
                            v-model="params.value[item][ite]"
                            :title="params.value[item][ite]"
                          ></a-input>
                          <!-- 用于修改上传地址 start -->
                          <input
                            type="file"
                            :ref="`pushInputChange_${item}_${ite}`"
                            @change="(e) => {
                              handleFileUploadChange(e, false, (value) =>{ params.value[item][ite] = value })}"
                            accept=".json"
                            hidden/>
                          <!-- 用于修改上传地址 end -->
                        </a-descriptions-item>
                      </a-descriptions>
                      <a-button
                        type="primary"
                        size="small"
                        shape="circle"
                        @click="() => {
                          btnAddManuFacturerClick()
                        }">
                        <a-icon type="plus"></a-icon>
                      </a-button>
                    </a-card>

                    <a-input v-else-if="!params.options" v-model="params.value"/>
                    <a-select style="width: 220px" v-else v-model="params.value">
                      <a-select-option v-for="(opt, optIndex) in params.options" :key="optIndex" :value="opt.value">
                        {{ opt.title }}
                      </a-select-option>
                    </a-select>
                  </a-form-item>
                </span>
              </div>
            </div>
            <div class="setting_goods_else" v-else>该渠道暂无插件配置</div>
          </a-tab-pane>
        </a-tabs>
      </a-spin>
    </a-modal>
    <!-- 添加厂商弹框 -->
    <a-modal
      :visible="addManufacturerVisible"
      @cancel="addManufacturerVisible = false, addManufacturerForm = {}"
      title="添加厂商"
      width="800px"
      @ok="addManufacturer">
      <a-form-model
        :model="addManufacturerForm"
        :label-col="{ span: 6 }"
        :wrapper-col="{ span: 12 }"
        ref="addManufacturerForm"
        :rules="addManufacturerRules"
        layout="horizontal"
      >
        <a-form-model-item label="manufacturer">
          <a-select v-model="addManufacturerForm.name" @change="manufacturerCahgne">
            <a-select-option v-for="item in manufacturerList" :value="item.manufacturer" :key="item.manufacturer">{{ item.manufacturer }}</a-select-option>
          </a-select>
        </a-form-model-item>
        <div v-if="addManufacturerForm.name">
          <div v-if="addManufacturerForm.upload">
            <!-- 上传文件 -->
            <a-form-model-item v-for="(item,index) in manufacturerParams" :key="index" :label="item" :prop="item">
              <a-input v-model="addManufacturerForm[item]" readonly></a-input>
              <a-button type="primary" @click="showUploadDialog(index)">Upload</a-button>
              <input type="file" ref="uploadFile" @change="(e) => handleFileUploadChange(e, item)" accept=".json" hidden/>
            </a-form-model-item>
          </div>
          <div v-else>
            <!-- 输入参数 -->
            <a-form-model-item v-for="(item,index) in manufacturerParams" :key="index" :label="item" :prop="item">
              <a-input v-model="addManufacturerForm[item]" @input="() => {}"></a-input>
            </a-form-model-item>
          </div>
        </div>
      </a-form-model>
    </a-modal>
  </div>
</template>
<script>
import { ACCESS_TOKEN } from '@/store/mutation-types'
import storage from 'store'
export default {
  data () {
    return {
      form: this.$form.createForm(this),
      loading: false,
      mode: 'left',
      formData: [],
      SpLoading: false,
      goodId: '',
      fileLists: [],
      channelId: '',
      keys: '1',
      imgBaseUrl: process.env.VUE_APP_API_BASE_URL,
      action: process.env.VUE_APP_API_BASE_URL + '/api/developer/channels/icon',
      SpAction: process.env.VUE_APP_API_BASE_URL + '/api/developer/upload/splashes',
      UploadCsv: process.env.VUE_APP_API_BASE_URL + '/api/developer/upload/csv',
      header: {
        'Authorization': 'Bearer ' + storage.get(ACCESS_TOKEN)
      },
      addManufacturerVisible: false,
      addManufacturerForm: {},
      addManufacturerRules: {},
      manufacturerList: [],
      manufacturerParams: {}
    }
  },
  props: {
    visible: {
      type: Boolean,
      default: () => false
    },
    confirmLoading: {
      type: Boolean,
      default: () => false
    },
    tabKey: {
      type: String,
      default: ''
    },
    model: {
      type: Object,
      default: null
    }
  },
  created () {
    // 当 model 发生改变时，为表单设置值
    this.$watch('model', () => {
      this.fileLists = []
      if (this.model.splashes) {
        Object.values(this.model.splashes).forEach((item, key) => {
          this.fileLists.push({
            uid: key,
            name: item,
            status: 'done',
            url: this.imgBaseUrl + item
          })
        })
      }
      this.formData = this.model
    })
    this.$watch('tabKey', () => {
      this.keys = this.tabKey
    })
    this.$watch('keys', () => {
      this.$emit('updateKeys', this.keys)
    })
  },
  methods: {
    pushInputAfterBtnClick (item, ite) {
      this.$refs[`pushInputChange_${item}_${ite}`][0].click()
    },
    isUpload (params, manufacturer) {
      let upload = false
      params.options && params.options.forEach((item, index, arr) => {
        if (item.manufacturer === manufacturer && item.upload) {
          upload = true
        }
      })
      return upload
    },
    /**
     * 文件选择结束，上传文件
     *
     * @param file 文件选择框，htmlElement
     * @param item 添加厂商时使用，addManufacturerForm的key
     * @param callback 进行其他处理
     */
    handleFileUploadChange (file, item, callback) {
      if (file.target.files.length === 0) return
      const formData = new FormData()
      formData.append('file', file.target.files[0])
      this.$http.post(process.env.VUE_APP_API_BASE_URL + '/api/developer/upload/manufacturer_json',
           formData,
           {
            contentType: false,
            processData: false,
            headers: {
               'Content-Type': 'application/x-www-form-urlencoded',
               'Authorization': 'Bearer ' + this.$store.getters.userInfo.token
              }
            }
          ).then(res => {
            this.$message.success('上传文件成功！')
            if (item) {
              this.addManufacturerForm[item] = process.env.VUE_APP_API_BASE_URL + res.url
            } else {
              const url = process.env.VUE_APP_API_BASE_URL + res.url
              callback(url)
            }
            // 清空文件选择框的值，避免选择下次选择相同文件不触发change事件
            file.target.value = ''
            this.$forceUpdate()
          }).catch(err => {
            this.$message.success('上传文件失败！')
            console.log(err)
          })
    },
    // 唤起选择文件弹框
    showUploadDialog (index) {
      this.$refs.uploadFile[index].click()
    },
    // 删除厂商配置
    btnRemoveManufacturerClick (manufacturer) {
      console.log(manufacturer)
      this.model.plugs.forEach(item => {
        if (item.alias === 'PUSH') {
          item.params.forEach(ite => {
            if (ite.key === 'manufacturer') {
              const newValue = {}
              Object.keys(ite.value).forEach(i => {
                if (i !== manufacturer) {
                  newValue[i] = { ...ite.value[i] }
                }
              })
              ite.value = newValue
              this.$forceUpdate()
            }
          })
        }
      })
    },
    // 确认添加厂商配置
    addManufacturer () {
      if (Object.keys(this.addManufacturerForm).length === 0) {
        this.addManufacturerVisible = false
        this.addManufacturerForm = {}
        return
      }
      for (const key in this.manufacturerParams) {
        if (this.addManufacturerForm[this.manufacturerParams[key]] === undefined) {
          this.addManufacturerForm[this.manufacturerParams[key]] = ''
        }
      }
      this.$refs.addManufacturerForm.validate(valid => {
        if (valid) {
          console.log(this.model)
          delete this.addManufacturerForm.upload
          this.$forceUpdate()
          this.model.plugs.forEach(item => {
            if (item.alias === 'PUSH') {
              console.log(item)
              item.params.forEach(ite => {
                if (ite.key === 'manufacturer') {
                  console.log(ite)
                  const data = JSON.parse(JSON.stringify(this.addManufacturerForm))
                  delete data.name
                  const result = {}
                  result[this.addManufacturerForm.name] = { ...data }
                  ite.value = { ...ite.value, ...result }
                }
              })
            }
          })
          this.addManufacturerVisible = false
          this.addManufacturerForm = {}
        }
      })
    },
    // 选择厂商更改，添加验证
    manufacturerCahgne (e) {
      this.manufacturerParams = this.manufacturerList.filter(item => item.manufacturer === e)[0].params
      this.manufacturerParams && this.manufacturerParams.forEach(item => {
        // this.addManufacturerRules[item] = { required: true, trigger: 'change' }
      })
      this.manufacturerList.forEach(item => {
        if (item.manufacturer === e && item.upload) {
          this.addManufacturerForm.upload = true
        }
      })
    },
    btnAddManuFacturerClick () {
      this.manufacturerList = this.model.plugs.filter(item => item.alias === 'PUSH')[0].params.filter(item => item.key === 'manufacturer')[0].options
      this.addManufacturerVisible = true
    },
    handleChange (e) {
      this.keys = e.toString()
    },
    handleCsvChange (e) {
      if (e.file.response) {
        const tableData = {}
        e.file.response.data.forEach(item => {
                tableData[item[0]] = item[1]
              })
              this.formData.goods = tableData
      }

      // this.$emit('changeGoods', tableForm)
    },
    handleSpChange (e) {
      if (e.file.response) {
        const formData = Object.assign({}, this.formData)
        if (!formData.splashes || formData.splashes === undefined) {
          this.$set(formData, 'splashes', [])
        }
        formData.splashes.push(e.file.response.url)
        this.formData = formData
      }
      if (e.file.status === 'removed') {
        const data = this.formData.splashes
        var index = data.indexOf(e.file.name)
        if (index > -1) {
          data.splice(index, 1)
          this.$set(this.formData, 'splashes', data)
        }
      }
      this.fileLists = e.fileList
    },
    beforeUpload (file) {
      const isJpgOrPng = file.type === 'image/png'
      if (!isJpgOrPng) {
        this.$message.error('只能上传png格式的图片!')
      }
      const isLt2M = file.size / 1024 / 1024 < 2
      if (!isLt2M) {
        this.$message.error('图片大小不得超过2M')
      }
      return isJpgOrPng && isLt2M
    },
    handlePreview (e) {
    },
    handleUploadChange (response) {
      if (response.file.response) {
        // this.formData.icon = response.file.response.url
        this.$set(this.formData, 'icon', response.file.response.url)
      }
    },
    addGoods () {
      if (this.goodId === '') {
        this.$message.warning('请填写商品ID')
        return false
      }
      if (this.channelId === '') {
        this.$message.warning('请填写渠道ID')
        return false
      }
      const arr = {}
      this.$set(arr, this.goodId, this.channelId)
      if (!this.formData.goods) {
        this.formData.goods = arr
      } else {
        this.$set(this.formData.goods, this.goodId, this.channelId)
      }
      this.goodId = ''
      this.channelId = ''
    },
    delGoods (index) {
      let goods = this.formData.goods
      this.$delete(goods, index)
      if (JSON.stringify(goods) === '{}') {
        goods = null
      }
      this.$set(this.formData, 'goods', goods)
    },
    clearGoods () {
      this.$set(this.formData, 'goods', {})
    },
    downloadTemplate () {
      var a = document.createElement('a')
      a.setAttribute('href', '/template-goods.csv')
      a.setAttribute('download', 'goods.csv')
      document.body.appendChild(a)
      a.click()
    }
  }
}
</script>
<style scoped>
* /deep/ .ant-tabs .ant-tabs-left-bar .ant-tabs-tab {
  width: 110px;
}
* /deep/ .ant-tabs-nav {
  height: 70vh;
}
.setting_jb {
  height: 70vh;
  overflow-y: scroll;
}
.setting_jb_title {
  line-height: 58px;
  font-weight: bold;
  font-size: 18px;
  margin: 0px;
  color: #46566c;
  background: none;
}
.setting_jb_des {
  float: left;
  width: 80%;
  color: #1c2b36;
  line-height: 32px;
  font-size: 12px;
  overflow: hidden;
  white-space: nowrap;
  text-overflow: ellipsis;
  margin-bottom: 20px;
}
.setting_jb_form {
  overflow: hidden;
  width: 100%;
}
.setting_form_title {
  color: #3f4a52;
  font-size: 14px;
  line-height: 46px;
  margin: 0 0 22px 0;
  background-color: #f9f9f9;
  padding-left: 20px;
}
.setting_form_title span {
  font-size: 12px;
  margin-left: 5px;
  color: #ff3300;
}
.setting_upload_des {
  font-family: '微软雅黑';
  padding: 0;
  color: #9fa9b9;
  font-size: 12px;
  margin-top: 30px;
}
.setting_upload_des span {
  color: red;
}
.setting_upload_title {
  height: 30px;
  line-height: 28px;
  font-size: 18px;
  margin-top: 30px;
  font-weight: 500;
  margin-bottom: 30px;
}
* /deep/ .ant-upload.ant-upload-select-picture-card {
  border: 2px dashed #d9dde3;
  width: 180px;
  height: 180px;
  color: #92aab0;
  text-align: center;
  vertical-align: middle;
  margin-bottom: 10px;
  font-size: 200%;
  cursor: default;
  float: left;
}
.setting_upload_icon_des {
  margin-left: 0px;
  line-height: 24px;
  margin-top: 10px;
  color: #9fa9b9;
  font-size: 12px;
}
.setting_upload_icon_des span {
  color: red;
}
.setting_goods_else {
  color: #777;
  font-weight: 400;
  text-align: center;
  font-size: 22px;
  margin-top: 30px;
}
.setting_goods_des {
  padding: 0;
  color: #9fa9b9;
  font-size: 12px;
  margin-top: 30px;
}
.setting_goods_table {
  margin-top: 30px;
  padding: 0 30px;
}
.setting_goods_table table {
  border: 1px solid #ccc;
  width: 100%;
  text-align: center;
}
.setting_goods_table table td {
  border: 1px solid #ccc;
  padding: 10px 0;
}
.setting_goods_table table td input {
  border: none;
  text-align: center;
  outline: none;
}
.setting_plug{
  overflow-y: scroll;
  height: 65vh;
}
</style>
<style>
.SpUpload .ant-upload.ant-upload-select-picture-card {
  width: 176px;
  height: 116px;
}
.SpUpload .ant-upload-list-picture-card-container {
  width: 176px;
  height: 116px;
}
.SpUpload .ant-upload-list-picture-card .ant-upload-list-item {
  width: 176px;
  height: 116px;
  padding: 0;
}
.SpUpload .ant-upload-list-picture-card .ant-upload-list-item-thumbnail,
.ant-upload-list-picture-card .ant-upload-list-item-thumbnail img {
  width: 176px;
  height: 116px;
}
.goods_table{
  overflow-y: scroll;
  max-height: 40vh;
}
</style>
