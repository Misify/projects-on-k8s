<template>
  <div class="content">
    <div class="content_right">
      <div class="right_title">{{ one }}</div>
      <ul>
        <li v-for="(item,index) in route" :key="index" :class="item.path === path ? 'game_active':''"><router-link :to="item.path">{{ item.name }}</router-link></li>
      </ul>
      <span class=""></span>
    </div>
    <div class="content_left">
      <a-breadcrumb>
        <a-breadcrumb-item>{{ one }}</a-breadcrumb-item>
        <a-breadcrumb-item><a href="">{{ two }}</a></a-breadcrumb-item>
      </a-breadcrumb>
      <slot name="leftContent"> </slot>
    </div>
  </div>
</template>
<script>
export default {
  data () {
    return {
      path: '',
      two: ''
    }
  },
  props: {
    one: {
     type: String,
      default: () => ''
    },
    route: {
      type: Array,
      default: null
    }
  },
  created () {
    this.path = this.$route.path
    this.two = this.$route.meta.title
  }
}
</script>
<style scoped>
.content {
  display: flex;
  position: absolute;
  top: 0;
  left: 0;
  bottom: 0;
  right: 0;
}
.content_right {
  width: 156px;
  height: 100%;
  background: #e9ecf1;
}
.content_left {
  flex: 1;
  padding: 20px;
  overflow-y: scroll;
}
.right_title {
  height: 51px;
  margin: 0 0 0 0px;
  font-size: 14px;
  color: #686b72;
  line-height: 50px;
  background-color: #e9ecf1;
  padding-left: 20px;
  border-bottom: 1px solid #dcdfe4;
}
.content_right ul {
  display: block;
  width: 100%;
  padding: 0;
}
.content_right li {
  display: block;
  line-height: 42px;
  border-bottom: 1px solid #dcdfe4;
  display: block;
  color: #1c2b36;
  padding-left: 30px;
  height: 100%;
  position: relative;
}
.content_right li a{
  color: #1c2b36;
  display: block;
  height: 42px;
  line-height: 42px;
  width: 100%;
}
.content_right li:hover {
  background: #dfe2e7;
  cursor: pointer;
}
.game_active {
  background: #dfe2e7;
}
</style>
