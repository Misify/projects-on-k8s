import { games } from '@/api/games'
const game = {
  state: {
    gameController: '',
    games: []
  },

  mutations: {
    SET_GAMECONTROLLER: (state, data) => {
      state.gameController = data
    },
    SET_GAMES: (state, data) => {
      state.games = data
    }
  },

  actions: {
    setGameController ({ commit }, data) {
      return new Promise(resolve => {
        if (data !== 0) {
          localStorage.setItem('gameControllerButton', data)
        }
        commit('SET_GAMECONTROLLER', data)
        resolve()
      })
    },
    setGame ({ commit }) {
      return new Promise(resolve => {
        games([]).then(res => {
          commit('SET_GAMES', res.data)
          resolve(res)
        })
      })
    }
  }
}

export default game
