/*
 * @Author: your name
 * @Date: 2019-12-09 11:19:37
 * @LastEditTime : 2020-01-03 11:53:04
 * @LastEditors  : Please set LastEditors
 * @Description: In User Settings Edit
 * @FilePath: \mole-packs\src\renderer\utils\auth.js
 */
// import Cookies from 'js-cookie'
// import session from 'electron'
import CryptoJS from 'crypto-js'
const _token = '_token'

export function getToken () {
  return localStorage.getItem(_token)
}

export function setToken (token) {
  return localStorage.setItem(_token, token)
}

export function removeToken () {
  return localStorage.removeItem(_token)
}

export function setRemember (email) {
  return setExpire('remember', email, 7 * 24 * 3600 * 1000)
}
export function getRemember () {
  return getExpire('remember')
}
export function setPassword (val) {
  const keyStr = 'mole-pack-pro'
  const encrypted = CryptoJS.AES.encrypt(val, keyStr, { mode: CryptoJS.mode.CBC, padding: CryptoJS.pad.ZeroPadding })
  setExpire('pas', encrypted.toString(), 7 * 24 * 3600 * 1000)
  return encrypted.toString()
}
export function getPassword () {
  const keyStr = 'mole-pack-pro'
  const word = getExpire('pas')
  if (word !== null) {
    var decrypt = CryptoJS.AES.decrypt(word, keyStr, { mode: CryptoJS.mode.CBC, padding: CryptoJS.pad.ZeroPadding })
    return decrypt.toString(CryptoJS.enc.Utf8)
  }
}
export function delPassword (val) {
  localStorage.removeItem(val)
}

function setExpire (key, value, expire) {
  const obj = {
    data: value,
    time: Date.now(),
    expire: expire
  }
  localStorage.setItem(key, JSON.stringify(obj))
}
function getExpire (key) {
  let val = localStorage.getItem(key)
  if (!val) {
    return val
  }
  val = JSON.parse(val)
  if (Date.now() - val.time > val.expire) {
    localStorage.removeItem(key)
    return null
  }
  return val.data
}
