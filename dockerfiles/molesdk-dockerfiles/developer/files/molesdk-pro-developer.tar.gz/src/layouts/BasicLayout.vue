<template>
  <pro-layout
    :menus="menus"
    :collapsed="collapsed"
    :mediaQuery="query"
    :isMobile="isMobile"
    :handleMediaQuery="handleMediaQuery"
    :handleCollapse="handleCollapse"
    :i18nRender="i18nRender"
    v-bind="settings"
  >
    <!-- Ads begin
      广告代码 真实项目中请移除
      production remove this Ads
    -->
    <!-- <ads v-if="isProPreviewSite && !collapsed"/> -->
    <!-- Ads end -->

    <!-- 1.0.0+ 版本 pro-layout 提供 API，
          我们推荐使用这种方式进行 LOGO 和 title 自定义
    -->
    <template v-slot:menuHeaderRender>
      <div>
        <logo-svg />
        <h1>{{ title }}</h1>
      </div>
    </template>
    <!-- <setting-drawer :settings="settings" @change="handleSettingChange" /> -->
    <template v-slot:rightContentRender>
      <div class="left_menu">
        <a-row>
          <a-col :span="12">
            <div class="leftMenuFlex">
              <span @click="href_gamecenter" v-if="gameControllerKey !== 0"> 游戏中心 </span>
              <span
                :class="gameControllerKey === 0 ? 'leftMenuActive' : ''"
                @click="href_controller"
                v-if="gameControllerKey === 0"
              >
                控制台
              </span>
              <span
                :class="gameControllerKey !== 0 ? 'leftMenuActive' : ''"
                @click="gameSelectHidden = !gameSelectHidden"
                v-if="gameControllerKey !== 0"
              >
                {{ gameName }}
              </span>
              <ul class="down_ul" :hidden="gameSelectHidden">
                <a-input @change="inputChange" placeholder="请输入游戏名称" style="width: 200px" />

                <li @click="href_games(item.id)" v-for="(item, index) in gamesFilter" :key="index">
                  {{ item.name }}
                </li>
              </ul>
            </div>
          </a-col>
          <a-col :span="12">
            <right-content :top-menu="settings.layout === 'topmenu'" :is-mobile="isMobile" :theme="settings.theme" />
          </a-col>
        </a-row>
      </div>
    </template>
    <template v-slot:footerRender>
      <div></div>
      <!-- <global-footer /> -->
    </template>
    <router-view />
  </pro-layout>
</template>

<script>
import { SettingDrawer, updateTheme } from '@ant-design-vue/pro-layout'
import { i18nRender } from '@/locales'
import { mapState } from 'vuex'
import { CONTENT_WIDTH_TYPE, SIDEBAR_TYPE, TOGGLE_MOBILE_TYPE } from '@/store/mutation-types'

import defaultSettings from '@/config/defaultSettings'
import RightContent from '@/components/GlobalHeader/RightContent'
import GlobalFooter from '@/components/GlobalFooter'
import Ads from '@/components/Other/CarbonAds'
import LogoSvg from '../assets/logo.svg?inline'

export default {
  name: 'BasicLayout',
  components: {
    SettingDrawer,
    RightContent,
    GlobalFooter,
    LogoSvg,
    Ads
  },
  data () {
    return {
      // preview.pro.antdv.com only use.
      isProPreviewSite: process.env.VUE_APP_PREVIEW === 'true' && process.env.NODE_ENV !== 'development',
      // end

      // base
      menus: [],
      games: [],
      gameName: '',
      gameControllerKey: 0,
      gamesFilter: [],
      // 侧栏收起状态
      collapsed: false,
      gameSelectHidden: true,
      title: defaultSettings.title,
      settings: {
        // 布局类型
        layout: defaultSettings.layout, // 'sidemenu', 'topmenu'
        // CONTENT_WIDTH_TYPE
        contentWidth: defaultSettings.layout === 'sidemenu' ? CONTENT_WIDTH_TYPE.Fluid : defaultSettings.contentWidth,
        // 主题 'dark' | 'light'
        theme: defaultSettings.navTheme,
        // 主色调
        primaryColor: defaultSettings.primaryColor,
        fixedHeader: defaultSettings.fixedHeader,
        fixSiderbar: defaultSettings.fixSiderbar,
        colorWeak: defaultSettings.colorWeak,

        hideHintAlert: false,
        hideCopyButton: false
      },
      // 媒体查询
      query: {},

      // 是否手机模式
      isMobile: false
    }
  },
  computed: {
    gameController () {
      return this.$store.getters.gameController
    },
    watchGames () {
      return this.$store.getters.games
    },
    ...mapState({
      // 动态主路由
      mainMenu: (state) => state.permission.addRouters
    })
  },
  watch: {
    gameController (val) {
      this.gameControllerKey = val
      this.getGameKeyName()
      const routes = this.mainMenu.find((item) => item.path === '/')
      // this.menus = (routes && routes.children) || []
      const menus = routes && routes.children
      this.gameSelectHidden = true
      this.handleMenu(menus)
    },
    watchGames: {
      handler (newName, oldName) {
        this.games = newName
        this.gamesFilter = this.games
        this.getGameKeyName()
      },
      deep: true
    }
  },
  created () {
    const routes = this.mainMenu.find((item) => item.path === '/')
    // this.menus = (routes && routes.children) || []
    const menus = routes && routes.children
    console.log(routes)
    this.games = this.$store.getters.games
    this.gamesFilter = this.games
    this.handleMenu(menus)
    this.gameControllerKey = this.$store.getters.gameController
    // if (!this.$store.getters.gameController) {
    //   this.gameControllerKey = localStorage.getItem('gameControllerButton')
    // }
    // 处理侧栏收起状态
    this.$watch('collapsed', () => {
      this.$store.commit(SIDEBAR_TYPE, this.collapsed)
    })
    this.$watch('isMobile', () => {
      this.$store.commit(TOGGLE_MOBILE_TYPE, this.isMobile)
    })
    this.getGameKeyName()
  },
  mounted () {
    const userAgent = navigator.userAgent
    if (userAgent.indexOf('Edge') > -1) {
      this.$nextTick(() => {
        this.collapsed = !this.collapsed
        setTimeout(() => {
          this.collapsed = !this.collapsed
        }, 16)
      })
    }
    document.addEventListener('click', (event) => {
      let className = ''
      event.path.map((item, index) => {
        className += 'className' in item ? item.className : 'null'
      })
      if (className.includes('leftMenuActive')) {
        return
      }
      if (!className.includes('down_ul')) {
        this.gameSelectHidden = true
      }
    })
    // first update color
    // TIPS: THEME COLOR HANDLER!! PLEASE CHECK THAT!!
    if (process.env.NODE_ENV !== 'production' || process.env.VUE_APP_PREVIEW === 'true') {
      updateTheme(this.settings.primaryColor)
    }
  },
  methods: {
    i18nRender,
    handleMediaQuery (val) {
      this.collapsed = true
      this.query = val
      if (this.isMobile && !val['screen-xs']) {
        this.isMobile = false
        return
      }
      if (!this.isMobile && val['screen-xs']) {
        this.isMobile = true
        this.collapsed = true
        this.settings.contentWidth = CONTENT_WIDTH_TYPE.Fluid
        // this.settings.fixSiderbar = false
      }
    },
    // 获取选中的name
    async getGameKeyName () {
      if (!this.gameControllerKey || this.gameControllerKey === null) {
        await this.$store.dispatch('setGameController', 0)
      } else {
        this.games.forEach((item) => {
          if (item.id.toString() === this.gameControllerKey.toString()) {
            this.gameName = item.name
          }
        })
      }
    },
    handleCollapse (val) {
      this.collapsed = val
    },
    down_menu () {},
    handleMenu (menus) {
      menus.forEach(async (item) => {
        if (this.$store.getters.gameController === '') {
          await this.$store.dispatch('setGameController', 0)
        }
        if (item.meta.gameController.toString() === '0' && this.$store.getters.gameController.toString() === '0') {
          item.hidden = false
        } else if (
          item.meta.gameController.toString() === '1' &&
          this.$store.getters.gameController.toString() !== '0'
        ) {
          item.hidden = false
        } else {
          item.hidden = true
        }
      })
      this.menus = menus
    },
    handleSettingChange ({ type, value }) {
      type && (this.settings[type] = value)
      switch (type) {
        case 'contentWidth':
          this.settings[type] = value
          break
        case 'layout':
          if (value === 'sidemenu') {
            this.settings.contentWidth = CONTENT_WIDTH_TYPE.Fluid
          } else {
            this.settings.fixSiderbar = false
            this.settings.contentWidth = CONTENT_WIDTH_TYPE.Fixed
          }
          break
      }
    },
    href_gamecenter () {
      this.$store.dispatch('setGameController', 0).then((res) => {
        this.$router.push({
          path: '/games/list'
        })
      })
    },
    href_controller () {
      if (this.$store.getters.games.length === 0) {
        this.$message.error('必须创建一个游戏！')
      } else {
        let key = this.$store.getters.games[0].id
        if (localStorage.getItem('gameControllerButton') !== 0) {
          key = localStorage.getItem('gameControllerButton')
        }
        this.$store.dispatch('setGameController', key).then((res) => {
          this.$router.push({
            path: '/dashboard/analysis',
            query: {
              key: Math.random().toString(36).slice(-6)
            }
          })
        })
      }
    },
    href_games (e) {
      this.$store.dispatch('setGameController', e).then((res) => {
        this.$router.push({
          path: '/dashboard/analysis',
          query: {
            key: Math.random().toString(36).slice(-6)
          }
        })
      })
    },
    inputChange (e) {
      const filter = []
      this.games.forEach((res) => {
        if (res.name.indexOf(e.target.value) > -1) {
          filter.push(res)
        }
      })
      this.gamesFilter = filter
    }
  }
}
</script>

<style lang="less">
@import './BasicLayout.less';
.ant-pro-global-header {
  display: flex;
}
.left_menu {
  flex: 1;
}
.ant-layout-header {
  height: 50px;
  line-height: 50px;
}
.ant-pro-global-header {
  height: 50px;
}
.ant-pro-global-header-trigger {
  height: 50px;
  line-height: 50px;
}
.ant-pro-global-header-index-right .ant-pro-account-avatar .antd-pro-global-header-index-avatar {
  margin: calc((50px - 24px) / 2) 0;
  margin-right: 8px;
}
.ant-pro-drop-down {
  line-height: 50px;
}
.ant-layout-footer {
  display: none;
}
</style>
<style scoped>
.leftMenuFlex {
  display: flex;
}
.leftMenuFlex span {
  padding: 0 25px;
  display: inline-block;
  cursor: pointer;
  position: relative;
}
.leftMenuFlex span:hover {
  background-color: #fff;
  color: #1890ff;
}
.leftMenuActive {
  background-color: #fff;
  color: #1890ff;
}
.down_ul {
  position: absolute;
  top: 50px;
  left: 106px;
  background-color: #fff;
  z-index: 0;
  width: 265px;
  padding: 0 20px 20px;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.15);
}
.down_ul li {
  display: block;
  height: 30px;
  line-height: 30px;
  font-size: 14px;
  cursor: pointer;
}
</style>
