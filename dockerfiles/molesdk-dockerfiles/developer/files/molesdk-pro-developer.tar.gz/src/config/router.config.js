// eslint-disable-next-line
import { UserLayout, BasicLayout, BlankLayout } from '@/layouts'
// import { bxAnaalyse } from '@/core/icons'

const RouteView = {
  name: 'RouteView',
  render: (h) => h('router-view')
}

export const asyncRouterMap = [

  {
    path: '/',
    name: 'index',
    component: BasicLayout,
    meta: { title: 'menu.home' },
    redirect: '/games/list',
    children: [
      {
        path: '/games',
        component: RouteView,
        redirect: '/games/list',
        hideChildrenInMenu: true,
        name: 'games',
        meta: { title: '游戏管理', keepAlive: true, icon: 'project', permission: ['dashboard'], gameController: 0 },
        children: [
          {
            path: '/games/list',
            name: 'games.list',
            component: () => import('@/views/games/list'),
            meta: { title: '全部游戏', keepAlive: true }
          },
          {
            path: '/games/restore',
            name: 'games.restore',
            hidden: true,
            component: () => import('@/views/games/restore'),
            meta: { title: '回收站', keepAlive: true }
          },
          {
            path: 'overview',
            name: 'games.overview',
            hidden: true,
            component: () => import('@/views/games/projectGame'),
            meta: { title: '游戏总览', keepAlive: true }
          },
          {
            path: 'channelView',
            name: 'games.channelView',
            hidden: true,
            component: () => import('@/views/games/list'),
            meta: { title: '渠道总览', keepAlive: true }
          },
          {
            path: 'manage',
            name: 'games.manage',
            hidden: true,
            component: () => import('@/views/games/list'),
            meta: { title: '全局报表', keepAlive: true }
          },
          {
            path: 'search',
            name: 'games.search',
            hidden: true,
            component: () => import('@/views/games/list'),
            meta: { title: '全局查询', keepAlive: true }
          }
        ]
      },
      {
        path: '/auth/settings',
        component: RouteView,
        redirect: '/auth/settings/base',
        hideChildrenInMenu: true,
        name: 'auth',
        meta: { title: '账户设置', keepAlive: true, icon: 'user', permission: ['dashboard'], gameController: 0 },
        children: [
          {
            path: '/auth/settings/base',
            name: 'BaseSettings',
            component: () => import('@/views/account/settings/BaseSetting'),
            meta: { title: '基本信息', hidden: true, permission: ['user'] }
          },
          {
            path: '/auth/settings/security',
            name: 'SecuritySettings',
            component: () => import('@/views/account/settings/Security'),
            meta: { title: '安全设置', hidden: true, keepAlive: true, permission: ['user'] }
          },
          {
            path: '/auth/reset/password',
            name: 'resetPassword',
            component: () => import('@/views/account/settings/SavePassword'),
            meta: { title: '修改密码', hidden: true, keepAlive: true, permission: ['user'] }
          }
        ]
      },
      // dashboard
      {
        path: '/dashboard',
        name: 'dashboard',
        hideChildrenInMenu: true,
        redirect: '/dashboard/analysis',
        component: RouteView,
        meta: { title: '控制台', keepAlive: true, icon: 'desktop', permission: ['dashboard'], gameController: 1 },
        children: [
          {
            path: '/dashboard/analysis/:pageNo([1-9]\\d*)?',
            name: 'Analysis',
            component: () => import('@/views/dashboard/Analysis'),
            meta: { title: '控制台', keepAlive: false, permission: ['dashboard'] }
          }
        ]
      },
      {
        path: '/channel',
        name: 'channel',
        hideChildrenInMenu: true,
        redirect: '/channel/list',
        component: RouteView,
        meta: { title: '渠道聚合SDK', keepAlive: true, icon: 'gateway', permission: ['channel.list'], gameController: 1 },
        children: [
          {
            path: '/channel/list',
            name: 'channel.list',
            component: () => import('@/views/channel/gameChannel'),
            meta: { title: '渠道参数配置', keepAlive: false, permission: ['dashboard'] }
          },
          {
            path: '/channel/games',
            name: 'channel.games',
            component: () => import('@/views/channel/games'),
            meta: { title: '游戏参数配置', keepAlive: false, permission: ['dashboard'] }
          },
          {
            path: '/channel/callback',
            name: 'channel.callback',
            component: () => import('@/views/channel/callback'),
            meta: { title: '渠道回调地址', keepAlive: false, permission: ['dashboard'] }
          },
          {
            path: '/channel/testUser',
            name: 'channel.testUser',
            component: () => import('@/views/channel/testUser'),
            meta: { title: '母包测试账号', keepAlive: false, permission: ['dashboard'] }
          },
          {
            path: '/channel/channelAddress',
            name: 'channel.channelAddress',
            component: () => import('@/views/channel/channelAddress'),
            meta: { title: '渠道通讯录', keepAlive: false, permission: ['dashboard'] }
          },
          {
            path: '/channel/channelsList',
            name: 'channel.channelsList',
            component: () => import('@/views/channel/channelsList'),
            meta: { title: '可用渠道管理', keepAlive: false, permission: ['dashboard'] }
          }
        ]
      },
      {
        path: '/baseData',
        component: RouteView,
        redirect: '/baseData/dashboard',
        hideChildrenInMenu: true,
        name: 'baseData',
        meta: { title: '数据运营平台', icon: 'bar-chart', keepAlive: true, permission: ['user'], gameController: 1 },
        children: [
          {
            path: '/baseData/dashboard',
            name: 'baseData.dashboard',
            component: () => import('@/views/baseData/dashboard'),
            meta: { title: '数据概况', hidden: true, permission: ['user'] }
          },
          {
            path: '/baseData/order',
            name: 'baseData.order',
            component: () => import('@/views/baseData/order'),
            meta: { title: '订单明细', hidden: true, permission: ['order'] }
          }
        ]
      }
    ]
  },
  {
    path: '*', redirect: '/404', hidden: true
  }
]

/**
 * 基础路由
 * @type { *[] }
 */
export const constantRouterMap = [
  {
    path: '/user',
    component: UserLayout,
    redirect: '/user/login',
    hidden: true,
    children: [
      {
        path: 'login',
        name: 'login',
        component: () => import(/* webpackChunkName: "user" */ '@/views/user/Login')
      },
      {
        path: 'register',
        name: 'register',
        component: () => import(/* webpackChunkName: "user" */ '@/views/user/Register')
      },
      {
        path: '/developer/password/reset/:token',
        name: 'recover',
        component: () => import(/* webpackChunkName: "user" */ '@/views/user/Recover')
      },
      {
        path: 'forget/password',
        name: 'forget',
        component: () => import(/* webpackChunkName: "user" */ '@/views/user/ForgetPassword')
      },
      {
        path: 'verification',
        name: 'verification',
        component: () => import(/* webpackChunkName: "user" */ '@/views/user/RegisterResult')
      },
      {
        path: '/developer/email/verify/:id',
        name: 'email',
        component: () => import(/* webpackChunkName: "user" */ '@/views/user/VerifyMail')
      }
    ]
  },

  {
    path: '/404',
    component: () => import(/* webpackChunkName: "fail" */ '@/views/exception/404')
  }

]
