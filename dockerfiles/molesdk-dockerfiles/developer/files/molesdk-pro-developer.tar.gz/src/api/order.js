import request from '@/utils/request'
export function order (data) {
  return request({
    url: '/api/developer/order',
    method: 'post',
    data
  })
}
