import request from '@/utils/request'

const userApi = {
  Login: '/api/developer/login',
  Logout: '/api/developer/logout',
  ForgePassword: '/auth/forge-password',
  Register: '/api/developer/register',
  twoStepCode: '/auth/2step-code',
  SendSms: '/account/sms',
  SendSmsErr: '/account/sms_err',
  // get my info
  UserInfo: '/api/developer/user/info',
  UserMenu: '/user/nav'
}

/**
 * login func
 * parameter: {
 *     username: '',
 *     password: '',
 *     remember_me: true,
 *     captcha: '12345'
 * }
 * @param parameter
 * @returns {*}
 */
export function login (parameter) {
  return request({
    url: userApi.Login,
    method: 'post',
    data: parameter
  })
}

export function register (parameter) {
  return request({
    url: userApi.Register,
    method: 'post',
    data: parameter
  })
}

export function getSmsCaptcha (parameter) {
  return request({
    url: userApi.SendSms,
    method: 'post',
    data: parameter
  })
}

export function getInfo () {
  return request({
    url: userApi.UserInfo,
    method: 'post',
    headers: {
      'Content-Type': 'application/json;charset=UTF-8'
    }
  })
}

export function getCurrentUserNav () {
  return request({
    url: userApi.UserMenu,
    method: 'get'
  })
}

export function logout () {
  return request({
    url: userApi.Logout,
    method: 'post',
    headers: {
      'Content-Type': 'application/json;charset=UTF-8'
    }
  })
}

/**
 * get user 2step code open?
 * @param parameter {*}
 */
export function get2step (parameter) {
  return request({
    url: userApi.twoStepCode,
    method: 'post',
    data: parameter
  })
}

/**
 * 发送激活邮件
 */

export function sendMail (data) {
  return request({
    url: '/api/developer/email/resend',
    method: 'get',
    data: data
  })
}

/**
 * 验证邮箱
 */

export function verifyMail (id, data) {
  return request({
    url: '/api/developer/email/verify/' + id,
    method: 'get',
    params: data
  })
}

/**
 * 修改密码
 */
export function resetPassword (data) {
  return request({
    url: '/api/developer/reset/password',
    method: 'post',
    data
  })
}
/**
 * 修改资料
 */

export function saveInfo (data) {
  return request({
    url: '/api/developer/save/info',
    method: 'post',
    data
  })
}

/**
 * 忘记密码
 *
 * @param data
 * @returns
 */

export function forgot (data) {
  return request({
    url: '/api/developer/password/email',
    method: 'post',
    data
  })
}

/**
 * 忘记密码-修改密码
 */
export function verifyEmailCode (data) {
  return request({
    url: '/api/developer/verify_email/code',
    method: 'post',
    data
  })
}
