export const gameType = [
  {
    label: '角色扮演',
    value: '角色扮演'
  },
  {
    label: '卡牌对战',
    value: '卡牌对战'
  },
  {
    label: '战略游戏',
    value: '战略游戏'
  },
  {
    label: '模拟游戏',
    value: '模拟游戏'
  },
  {
    label: '休闲益智',
    value: '休闲益智'
  },
  {
    label: '竞技格斗',
    value: '竞技格斗'
  },
  {
    label: '射击游戏',
    value: '射击游戏'
  },
  {
    label: '动作冒险',
    value: '动作冒险'
  },
  {
    label: '塔防策略',
    value: '塔防策略'
  },
  {
    label: '动作角色扮演',
    value: '动作角色扮演'
  },
  {
    label: '多人角色',
    value: '多人角色'
  },
  {
    label: '竞技体育',
    value: '竞技体育'
  },
  {
    label: '音乐游戏',
    value: '音乐游戏'
  },
  {
    label: '其他',
    value: '其他'
  }
]

export const route = [
  {
    name: '游戏参数配置',
    path: '/channel/games',
    active: false
  },
  {
    name: '渠道参数配置',
    path: '/channel/list',
    active: true
  }, {
    name: '渠道回调地址',
    path: '/channel/callback',
    active: false
  }, {
    name: '母包测试账号',
    path: '/channel/testUser',
    active: false
  }, {
    name: '渠道通讯录',
    path: '/channel/channelAddress',
    active: false
  }, {
    name: '可用渠道管理',
    path: '/channel/channelsList',
    active: false
  }
]

export const gameRoute = [
  {
    name: '全部游戏',
    path: '/games/list',
    active: true
  },
  {
    name: '游戏总览',
    path: '/games/overview',
    active: false
  }
  // {
  //   name: '渠道总览',
  //   path: '/games/channelView',
  //   active: false
  // }, {
  //   name: '全局报表',
  //   path: '/games/manage',
  //   active: false
  // }, {
  //   name: '全局查询',
  //   path: '/games/search',
  //   active: false
  // }
]

export const baseData = [
  {
    name: '数据运营平台',
    path: '/baseData/dashboard',
    active: true
  },
  {
    name: '订单明细',
    path: '/baseData/order',
    active: true
  }
]

export const authData = [
  {
    name: '基本信息',
    path: '/auth/settings/base',
    active: true
  },
  {
    name: '安全设置',
    path: '/auth/settings/security',
    active: true
  },
  {
    name: '修改密码',
    path: '/auth/reset/password',
    active: true
  }
]
