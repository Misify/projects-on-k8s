import request from '@/utils/request'

export function projectGames (data) {
  return request({
    url: '/api/developer/project/games',
    method: 'get',
    params: data
  })
}
