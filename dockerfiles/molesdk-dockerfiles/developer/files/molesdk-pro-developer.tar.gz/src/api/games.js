/*
 * @Author: your name
 * @Date: 2019-11-28 14:21:01
 * @LastEditTime: 2019-12-06 16:47:25
 * @LastEditors: Please set LastEditors
 * @Description: In User Settings Edit
 * @FilePath: \MolePackageVue\src\api\games.js
 */
import request from '@/utils/request'

export function games (data) {
  return request({
    url: '/api/developer/games',
    method: 'get',
    params: data
  })
}

export function gameInfo (id) {
  return request({
    url: '/api/developer/games/' + id,
    method: 'get'
  })
}

export function gameAdd (data) {
  return request({
    url: '/api/developer/games',
    method: 'post',
    data
  })
}

export function gameUpdate (data, id) {
  return request({
    url: '/api/developer/games/' + id,
    method: 'put',
    data
  })
}

export function gameDelete (id) {
  return request({
    url: '/api/developer/games/' + id,
    method: 'DELETE'
  })
}

export function gameTrashed () {
  return request({
    url: '/api/developer/games?trashed=""',
    method: 'get'
  })
}

export function gameRestore (id) {
  return request({
    url: '/api/developer/games/' + id + '/restore',
    method: 'post'
  })
}

export function channel () {
  return request({
    url: '/api/channels',
    method: 'get'
  })
}
// 给游戏添加渠道
export function gamesAddChannel (id, data) {
  return request({
    url: '/api/developer/games/' + id + '/channels',
    method: 'post',
    data
  })
}
// 获取游戏绑定的渠道
export function gamesChannel (id) {
  return request({
    url: '/api/developer/games/' + id + '/channels',
    method: 'get'
  })
}
// 获取渠道配置详情

export function gamesHasChannel (id, channelId) {
  return request({
    url: '/api/developer/games/' + id + '/channels/' + channelId,
    method: 'get'
  })
}
export function deleteGamesChannel (id, channelId) {
  return request({
    url: '/api/developer/games/' + id + '/channels/' + channelId,
    method: 'delete'
  })
}
export function updateParams (id, channelId, data) {
  return request({
    url: '/api/developer/games/' + id + '/channels/' + channelId,
    method: 'PUT',
    data
  })
}

// 游戏测试账号
export function gamesTesters (id) {
  return request({
    url: '/api/developer/games/' + id + '/testers',
    method: 'get'
  })
}

export function addGamesTester (id, data) {
  return request({
    url: '/api/developer/games/' + id + '/testers',
    method: 'post',
    data
  })
}

export function delGamesTester (id, name) {
  return request({
    url: '/api/developer/games/' + id + '/testers/' + name,
    method: 'DELETE'
  })
}

// 插件管理
export function getPlugs (params = {}) {
  return request({
    url: '/api/developer/plugs',
    method: 'get',
    params
  })
}
// 添加插件
export function addChannelPlug (data) {
  return request({
    url: '/api/developer/plugs',
    method: 'post',
    data
  })
}

// 添加插件
export function delChannelPlug (data, id) {
  return request({
    url: '/api/developer/plugs/' + id,
    method: 'DELETE',
    data
  })
}

// 自定义meta 参数
export function metaList (id) {
  return request({
    url: '/api/developer/games/' + id + '/metas',
    method: 'get'
  })
}

export function metaAdd (id, data) {
  return request({
    url: '/api/developer/games/' + id + '/metas',
    method: 'post',
    data
  })
}
