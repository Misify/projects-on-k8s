import router from './router'
import store from './store'
import storage from 'store'
import NProgress from 'nprogress' // progress bar
import '@/components/NProgress/nprogress.less' // progress bar custom style
import { setDocumentTitle, domTitle } from '@/utils/domUtil'
import { ACCESS_TOKEN } from '@/store/mutation-types'
import { i18nRender } from '@/locales'

NProgress.configure({ showSpinner: false }) // NProgress Configuration

const allowList = ['login', 'register', 'recover', 'email', 'forget'] // no redirect allowList
const loginRoutePath = '/user/login'
const defaultRoutePath = '/games/list'
const sendMailPath = '/user/verification'
const verifyMailPath = '/email/verify'
const whileGameFix = ['games', 'auth']

router.beforeEach(async (to, from, next) => {
  if (to.query._token) {
    store.dispatch('SetToken', to.query._token)
    next({ path: '/' })
  }
  NProgress.start() // start progress bar
  to.meta && (typeof to.meta.title !== 'undefined' && setDocumentTitle(`${i18nRender(to.meta.title)} - ${domTitle}`))
  /* has token */
  if (storage.get(ACCESS_TOKEN)) {
    if (to.path === loginRoutePath) {
      next({ path: defaultRoutePath })
      NProgress.done()
    } else {
      // check login user.roles is null
      if (store.getters.roles.length === 0) {
        // request login userInfo
        store
          .dispatch('GetInfo')
          .then(async res => {
            const roles = res.result && res.result.role
            // generate dynamic router
            store.dispatch('GenerateRoutes', { roles, to }).then(() => {
              // 根据roles权限生成可访问的路由表
              // 动态添加可访问路由表
              router.addRoutes(store.getters.addRouters)
              // 请求带有 redirect 重定向时，登录自动重定向到该地址
              const redirect = decodeURIComponent(from.query.redirect || to.path)
              if (to.path === redirect) {
                // set the replace: true so the navigation will not leave a history record
                next({ ...to, replace: true })
              } else {
                // 跳转到目的路由
                next({ path: redirect })
              }
            })
            if (to.path.indexOf(verifyMailPath) > -1) {
              next()
            } else if (to.path === sendMailPath) {
              next()
            } else {
              // 检查获取games
              const { data } = await store.dispatch('setGame')
              const routerArr = to.path.split('/')
              if (whileGameFix.indexOf(routerArr[1]) < 0 && (store.getters.gameController.toString() === '0' || store.getters.gameController.toString() === '' || store.getters.gameController.toString() === 'null')) { // 检测是否为游戏中心路由， 若不是 则赋值默认的gameid
                if (data.length === 0) {
                  next({ path: defaultRoutePath })
                } else {
                  await store.dispatch('setGameController', data[0].id)
                }
              } else if (whileGameFix.indexOf(routerArr[1]) < 0) {

              } else {
                await store.dispatch('setGameController', 0)
              }
            }
          })
      } else {
        next()
      }
    }
  } else {
    if (allowList.includes(to.name)) {
      // 在免登录名单，直接进入
      next()
    } else {
      next({ path: loginRoutePath, query: { redirect: to.fullPath } })
      NProgress.done() // if current page is login will not trigger afterEach hook, so manually handle it
    }
  }
})

router.afterEach(() => {
  NProgress.done() // finish progress bar
})
