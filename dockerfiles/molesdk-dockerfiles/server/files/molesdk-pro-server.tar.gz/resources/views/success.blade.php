
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <div>您好，您的账号已激活成功！请耐心等待MOLESDK管理员审核...</div>
</body>
</html>
