<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<style>
    .nav {
        width: 100%;
        background: #F2F6FC;
        text-align: center
    }

    .nav a {
        padding: 5px 10px;
        background-color: #409EFF;
        color: #fff;
    }

    .title {
        font-size: 18px;
        color: #909399;
        text-align: center;
        margin: 20px 0;
    }
</style>

<body>
    <div class="nav">
        <div class="title">{{$user['name']}}您好，欢迎使用MOLESDK聚合开发者系统</div>
        <div>验证码为 <span style="color: #409EFF"> {{$token}} </span> 请在十分钟内验证，感谢您的使用！</div>
    </div>
</body>

</html>
