<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Game Id
    |--------------------------------------------------------------------------
    |
    | This value is the id of your game application. 
    |
    */

    'id' => env('GAME_ID', 0),

    /*
    |--------------------------------------------------------------------------
    | Game serect
    |--------------------------------------------------------------------------
    |
    | This value is the secret of your game application. This value is used when the
    | framework needs to validate an signature.
    |
    */

    'secret' => env('GAME_SECRET'),
    
    /*
    |--------------------------------------------------------------------------
    | Game pri_key
    |--------------------------------------------------------------------------
    |
    | This value is the private key of your game application. This value is used when the
    | framework needs to make an signature for payment.
    |
    */

    'pri_key' => env('GAME_PRI_KEY'),
    
    /*
    |--------------------------------------------------------------------------
    | Game pay_callback
    |--------------------------------------------------------------------------
    |
    | This value is the callback address of your game application. This value is used when the
    | framework needs to call back to your game.
    |
    */

    'pay_callback' => env('GAME_PAY_CALLBACK'),
];
