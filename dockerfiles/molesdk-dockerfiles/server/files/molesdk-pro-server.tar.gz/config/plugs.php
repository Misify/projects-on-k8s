<?php

return [
    [
        'id' => '1',
        'name' => '安卓推送',
        'alias' => 'PUSH',
        'osType' => 'Windows_NT',
        'des' => '用于推送',
        'img' => '/img/default_img.png',
        'type' => ['推送'],
        'version' => '1.0.0.0',
        'params' => [
            [
                'key' => 'serverCluster',
                'des' => '选择渠道',
                'options' => [
                    [
                        'title' => '默认',
                        'value' => null
                    ],
                    [
                        'title' => '香港集群',
                        'value' => 'PUSH_CONFIGHOSTHK'
                    ],
                    [
                        'title' => '新加坡集群',
                        'value' => 'PUSH_CONFIGHOSTSGP'
                    ],
                    [
                        'title' => '上海集群',
                        'value' => 'PUSH_CONFIGHOSTSH'
                    ],
                ]
            ],
            ['key' => 'access_id', 'des' => 'AccessID'],
            ['key' => 'access_key', 'des' => 'AccessKey'],
            [
                'key' => 'manufacturer',
                'des' => 'Manufacturer',
                'options' => [
                    [
                        'manufacturer' => 'XIAOMI',
                        'params' => [
                            'XIAOMI_APPID', 'XIAOMI_APPKEY'
                        ]
                    ],
                    [
                        'manufacturer' => 'VIVO',
                        'params' => [
                            'VIVO_APPID', 'VIVO_APPKEY'
                        ]
                    ],
                    [
                        'manufacturer' => 'MEIZU',
                        'params' => [
                            'MEIZU_APPID', 'MEIZU_APPKEY'
                        ]
                    ],
                    [
                        'manufacturer' => 'OPPO',
                        'params' => [
                            'OPPO_APPID', 'OPPO_APPKEY'
                        ]
                    ],
                    [
                        'manufacturer' => 'HUAWEI',
                        'upload' => true,
                        'params' => [
                            'COMFIGURE_URL'
                        ]
                    ],
                    [
                        'manufacturer' => 'FCM',
                        'upload' => true,
                        'params' => [
                            'COMFIGURE_URL'
                        ]
                    ],
                ]
            ],
        ]
    ],
    [
        'id' => '2',
        'name' => 'iOS推送',
        'alias' => 'PUSH',
        'osType' => 'Darwin',
        'des' => '用于推送',
        'img' => '/img/default_img.png',
        'type' => ['推送'],
        'version' => '1.0.0.0',
        'params' => [
            [
                'key' => 'serverCluster',
                'des' => '选择渠道',
                'options' => [
                    [
                        'title' => '默认',
                        'value' => null
                    ],
                    [
                        'title' => '香港集群',
                        'value' => 'PUSH_CONFIGHOSTHK'
                    ],
                    [
                        'title' => '新加坡集群',
                        'value' => 'PUSH_CONFIGHOSTSGP'
                    ],
                    [
                        'title' => '上海集群',
                        'value' => 'PUSH_CONFIGHOSTSH'
                    ],
                ]
            ],
            ['key' => 'access_id', 'des' => 'AccessID'],
            ['key' => 'access_key', 'des' => 'AccessKey']
        ]
    ],
    [
        'id' => '3',
        'name' => 'iOS分享',
        'alias' => 'SHARE',
        'osType' => 'Darwin',
        'des' => 'iOS分享插件',
        'img' => '/img/default_img.png',
        'type' => ['分享'],
        'version' => '1.0.0.0',
        'params' => [
            ['key' => 'app_key', 'des' => 'app_key'],
            ['key' => 'app_secret', 'des' => 'app_secret'],
            ['key' => 'privacyRights', 'des' => 'privacyRights'],
            ['key' => 'QQ_appId', 'des' => 'QQ_appId'],
            ['key' => 'QQ_appkey', 'des' => 'QQ_appkey'],
            ['key' => 'QQ_universallink', 'des' => 'QQ_universallink'],
            ['key' => 'WeChat_appId', 'des' => 'WeChat_appId'],
            ['key' => 'WeChat_appSecret', 'des' => 'WeChat_appSecret'],
            ['key' => 'WeChat_universalLink', 'des' => 'WeChat_universalLink'],
            ['key' => 'SinaWeibo_appKey', 'des' => 'SinaWeibo_appKey'],
            ['key' => 'SinaWeibo_appSecret', 'des' => 'SinaWeibo_appSecret'],
            ['key' => 'SinaWeibo_redirectUrl', 'des' => 'SinaWeibo_redirectUrl'],
            ['key' => 'Facebook_appKey', 'des' => 'Facebook_appKey'],
            ['key' => 'Facebook_appSecret', 'des' => 'Facebook_appSecret'],
            ['key' => 'Facebook_displayName', 'des' => 'Facebook_displayName'],
            ['key' => 'Twitter_key', 'des' => 'Twitter_key'],
            ['key' => 'Twitter_secret', 'des' => 'Twitter_secret'],
            ['key' => 'Twitter_redirectUrl', 'des' => 'Twitter_redirectUrl'],
            ['key' => 'Instagram_clientId', 'des' => 'Instagram_clientId'],
            ['key' => 'Instagram_clientSecret', 'des' => 'Instagram_clientSecret'],
            ['key' => 'Instagram_redirectUrl', 'des' => 'Instagram_redirectUrl']
        ]
    ],
    [
        'id' => '4',
        'name' => '安卓分享',
        'alias' => 'SHARE',
        'osType' => 'Windows_NT',
        'des' => '安卓分享插件',
        'img' => '/img/default_img.png',
        'type' => ['分享'],
        'version' => '1.0.0.0',
        'params' => [
            ['key' => 'app_key', 'des' => 'app_key'],
            ['key' => 'app_secret', 'des' => 'app_secret'],
            ['key' => 'loopShare', 'des' => 'privacyRights'],
            ['key' => 'QQ_appId', 'des' => 'QQ_appId'],
            ['key' => 'QQ_appkey', 'des' => 'QQ_appkey'],
            ['key' => 'WeChat_appId', 'des' => 'WeChat_appId'],
            ['key' => 'WeChat_appSecret', 'des' => 'WeChat_appSecret'],
            ['key' => 'Wechat_userName', 'des' => 'Wechat_userName'],
            ['key' => 'Wechat_path', 'des' => 'Wechat_path'],
            ['key' => 'Wechat_withShareTicket', 'des' => 'Wechat_withShareTicket'],
            ['key' => 'Wechat_miniprogramType', 'des' => 'Wechat_miniprogramType'],
            ['key' => 'SinaWeibo_appKey', 'des' => 'SinaWeibo_appKey'],
            ['key' => 'SinaWeibo_appSecret', 'des' => 'SinaWeibo_appSecret'],
            ['key' => 'SinaWeibo_callbackUri', 'des' => 'SinaWeibo_callbackUri'],
            ['key' => 'Facebook_appKey', 'des' => 'Facebook_appKey'],
            ['key' => 'Facebook_appSecret', 'des' => 'Facebook_appSecret'],
            ['key' => 'Facebook_callbackUri', 'des' => 'Facebook_callbackUri'],
            ['key' => 'Facebook_shareByAppClient', 'des' => 'Facebook_shareByAppClient'],
            ['key' => 'Twitter_appKey', 'des' => 'Twitter_appKey'],
            ['key' => 'Twitter_appSecret', 'des' => 'Twitter_appSecret'],
            ['key' => 'Twitter_callbackUri', 'des' => 'Twitter_callbackUri'],
            ['key' => 'Twitter_shareByAppClient', 'des' => 'Twitter_shareByAppClient'],
            ['key' => 'Instagram_clientId', 'des' => 'Instagram_clientId'],
            ['key' => 'Instagram_clientSecret', 'des' => 'Instagram_clientSecret'],
            ['key' => 'Instagram_callbackUri', 'des' => 'Instagram_callbackUri'],
            ['key' => 'Instagram_shareByAppClient', 'des' => 'Instagram_shareByAppClient']
        ]
    ],
    [
        'id' => '5',
        'name' => '安卓统计',
        'alias' => 'STATISTICS',
        'des' => '安卓统计插件',
        'img' => '/img/default_img.png',
        'type' => ['统计'],
        'version' => '1.0.0.0',
        'params' => [
            ['key' => 'TA_APP_ID', 'des' => 'TA_APP_ID'],
            ['key' => 'TA_SERVER_URL', 'des' => 'TA_SERVER_URL']
        ]
    ]
];
