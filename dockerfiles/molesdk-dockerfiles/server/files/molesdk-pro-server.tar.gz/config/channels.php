<?php

return [
    [
        'id' => 0,
        'driver' => 'sandbox',
        'alias' => 'sandbox',
        'type' => ['Android', 'iOS'],
        'packing_types' => 'apk',
        'is_goods' => 0,
        "url" => 'http://pro.sdk.longame.cn/developer',
        'verify_url' => 'http://pro.sdk.longame.cn/api/user/verify',
        'name' => '聚合沙箱渠道',
        'version' => '1.0.0.0',
        'desc' => '聚合沙箱渠道',
        'abstract' => '1.正确填入每个渠道的每项参数后，方可打包测试此渠道流程<br />2. 自定义参数可以用来动态的向打出的渠道包写入参数，适用场景如推送<br />3.有时因为渠道更新新加入参数，致原本出包状态成功的渠道可能在打包工具上无法出包',
        "params" => [
            "client" => [
            ],
            "server" => [
            ],
            "other" => []
        ],
        'updated_at' => '2019-09-19'
    ],
    [
        'id' => 1,
        'driver' => 'mole',
        'alias' => 'mole',
        'type' => ['Android', 'iOS'],
        'packing_types' => 'apk',
        'is_goods' => 1,
        "url" => 'http://sdk.longame.cn/developer',
        'verify_url' => 'http://sdk.longame.cn/api/user/verify',
        'name' => '鼹鼠游戏',
        'version' => '1.0.0.0',
        'abstract' => '1.正确填入每个渠道的每项参数后，方可打包测试此渠道流程<br />2. 自定义参数可以用来动态的向打出的渠道包写入参数，适用场景如推送<br />3.有时因为渠道更新新加入参数，致原本出包状态成功的渠道可能在打包工具上无法出包',
        'desc' => '联运单机游戏合作<br />华东 李智 邮箱： lz98684@alibaba-inc.com<br />华南 唐蕾 邮箱： tl99646@alibaba-inc.com<br />华北+西南 许晋 邮箱： xj102360@alibaba-inc.com<br /><br />联运单机游戏合作<br />华北+西南 许晋 邮箱： xj102360@alibaba-inc.com<br />华东+华南 唐蕾 邮箱： tl99646@alibaba-inc.com<br /><br />IP合作申请IP<br />幕娆 邮箱： shandan@alibaba-inc.com',
        "params" => [
            "client" => [
                ["key" => "app_id", "desc" => "应用标识"],
                ["key" => "app_key", "desc" => "应用客户端密钥"]
            ],
            "server" => [
                ["key" => "app_id", "value" => 1, "desc" => "应用标识"],
                ["key" => "app_secret", "value" => 'pLPx6croP0YQq2RUETdo0BwJCG5xvXXP', "desc" => "应用服务端密钥"],
                ["key" => "pay_public_key", "value" => 'MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQC1zb/mFdRb5FYAJED8yoVlWaRiiyvfrTnj8bcDhCVJk7yF9Hel2pY2YUagd2LS4PvR4RvLYeM2ZKktw+MBembshEyjIbtZ7rDmC4MFqPVb4geMWDAxzdpEvv5h3KS2CHJ4AhRDM8Mq2Ysd0bYchzYC2TpGzcsGAhEdtYkKGZ2H4QIDAQAB', "desc" => "应用支付密钥"]
            ],
            "other" => [
                ["key" => "bundle_id", "desc" => "包名"]
            ]
        ],
        'updated_at' => '2019-09-19'
    ],
    [
        'id' => 2,
        'driver' => 'mengyou',
        'alias' => 'mengyou',
        'type' => ['Android', 'iOS'],
        'packing_types' => 'apk',
        'is_goods' => 1,
        "url" => 'http://www.himengyou.com/',
        'verify_url' => 'http://cs-api.himengyou.com/user/check/',
        'name' => '萌友',
        'version' => '3.0.0',
        'abstract' => '1.正确填入每个渠道的每项参数后，方可打包测试此渠道流程<br />2. 自定义参数可以用来动态的向打出的渠道包写入参数，适用场景如推送<br />3.有时因为渠道更新新加入参数，致原本出包状态成功的渠道可能在打包工具上无法出包',
        'desc' => '广州萌友网络科技有限公司（以下简称“萌友游戏”）成立于2017年，专注于游戏发行和运营。创始团队曾任职于三七互娱、网易等互联网公司，萌友游戏目前已成功发行多款精品游戏，深受玩家喜爱和市场好评。',
        "params" => [
            "client" => [
                ["key" => "refer", "desc" => "refer"]
            ],
            "server" => [
                ["key" => "app_key", "desc" => "app_secret"]
            ],
            "other" => [
                ["key" => "bundle_id", "desc" => "包名"]
            ]
        ],
        'updated_at' => '2020-07-16'
    ],
    [
        'id' => 3,
        'driver' => 'daqian',
        'alias' => 'daqian',
        'type' => ['Android'],
        'packing_types' => 'apk',
        'is_goods' => 1,
        "url" => '',
        'verify_url' => '',
        'name' => '大千',
        'version' => '1.0.0',
        'abstract' => '1.正确填入每个渠道的每项参数后，方可打包测试此渠道流程<br />2. 自定义参数可以用来动态的向打出的渠道包写入参数，适用场景如推送<br />3.有时因为渠道更新新加入参数，致原本出包状态成功的渠道可能在打包工具上无法出包',
        'desc' => '暂无介绍',
        "params" => [
            "client" => [
                // ["key" => "naf_game_name", "desc" => "naf_game_name"],
                // ["key" => "naf_game_id", "desc" => "naf_game_id"],
                // ["key" => "naf_pf_gameid", "desc" => "naf_pf_gameid"],
                // ["key" => "naf_package_id", "desc" => "naf_package_id"],
                // ["key" => "naf_app_key", "desc" => "naf_app_key"],
                // ["key" => "applicationId", "desc" => "applicationId"]
                ["key" => "bx_pf_gameid", "desc" => "bx_pf_gameid"],
                ["key" => "bx_app_key", "desc" => "bx_app_key"],
                ["key" => "bx_game_id", "desc" => "bx_game_id"],
                ["key" => "bx_game_name", "desc" => "bx_game_name"],
                ["key" => "bx_package_id", "desc" => "bx_package_id"]
            ],
            "server" => [
                ["key" => "Secret", "desc" => "Secret"]
            ],
            "other" => [
                ["key" => "bundle_id", "desc" => "包名"]
            ]
        ],
        'updated_at' => '2021-11-02'
    ]
];
