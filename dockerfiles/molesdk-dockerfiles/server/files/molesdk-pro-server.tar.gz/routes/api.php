<?php

use Illuminate\Http\Request;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

$api = app('Dingo\Api\Routing\Router');
$api->version('v1', function ($api) {
    // 渠道列表
    $api->resource('channels', 'App\Http\Controllers\ChannelController', ['only' => ['index', 'show']]);

    // 管理员
    $api->group(["prefix" => "administrator"], function ($api) {
        // 登录
        $api->post('login', 'App\Http\Controllers\Administrator\LoginController@login');
        // 密码重设
        $api->post('password/email', 'App\Http\Controllers\Administrator\Auth\ForgotPasswordController@sendResetLinkEmail')->name('administrator.password.email');
        $api->get('password/reset/{token}', 'App\Http\Controllers\Administrator\Auth\ResetPasswordController@showResetForm')->name('administrator.password.reset');
        $api->post('password/reset', 'App\Http\Controllers\Administrator\Auth\ResetPasswordController@reset')->name('administrator.password.update');

        $api->group(['middleware' => ['auth:administrator']], function ($api) {
            // 邮箱验证
            $api->get('email/resend', 'App\Http\Controllers\Auth\VerificationController@resend')->name('administrator.verification.resend');
            $api->get('email/verify/{id}', 'App\Http\Controllers\Auth\VerificationController@verify')->name('administrator.verification.verify');

            // 刷新token
            $api->post('refresh_token', 'App\Http\Controllers\Administrator\LoginController@refreshToken');
            // 登出
            $api->post('logout', 'App\Http\Controllers\Administrator\LoginController@logout');
            //用户信息
            $api->post('user/info', 'App\Http\Controllers\Administrator\AdministratorController@userInfo');
            // 修改密码
            $api->post('change_password', 'App\Http\Controllers\Administrator\AdministratorController@changePassword');

            $api->resource('users', 'App\Http\Controllers\Administrator\AdministratorController');
            $api->get('show_permission/{id}', 'App\Http\Controllers\Administrator\AdministratorController@showPermission');
            // 开发者列表
            $api->resource('developers', 'App\Http\Controllers\Administrator\DeveloperController', ['only' => ['index', 'show', 'update']]);
            // 游戏列表
            $api->resource('games', 'App\Http\Controllers\Administrator\GameController', ['only' => ['index', 'show', 'update']]);
            $api->post('secret', 'App\Http\Controllers\Administrator\GameController@secret');
            $api->resource('games.channels', 'App\Http\Controllers\Administrator\Game\ChannelController');
            // 权限列表
            $api->resource('permission', 'App\Http\Controllers\Administrator\PermissionController');
            // 角色列表
            $api->resource('roles', 'App\Http\Controllers\Administrator\RoleController');
            // 账号审核
            $api->post('verifys', 'App\Http\Controllers\Administrator\VerifyController@verify');
            // 获取渠道json数据
            $api->post('channel_json', 'App\Http\Controllers\Administrator\Game\ChannelController@downloadChannelsConfig');
            //查询订单
            $api->post('order', 'App\Http\Controllers\Administrator\OrderController@index');
            //补单
            $api->post('supplement', 'App\Http\Controllers\Administrator\OrderController@supplement');
            //搜索游戏名称
            $api->get('search/game', 'App\Http\Controllers\Administrator\OrderController@getGames');
            //上传头像
            $api->post('upload/avatar', 'App\Http\Controllers\Administrator\AdministratorController@uploadAvatar');
        });
    });
    // 开发者
    $api->group(["prefix" => "developer"], function ($api) {
        // 注册
        $api->post('register', 'App\Http\Controllers\Developer\RegisterController@register');
        // 登录
        $api->post('login', 'App\Http\Controllers\Developer\LoginController@login');
        // 密码重设
        $api->post('password/email', 'App\Http\Controllers\Developer\Auth\ForgotPasswordController@sendResetLinkEmail')->name('developer.password.email');
        $api->get('password/reset/{token}', 'App\Http\Controllers\Developer\Auth\ResetPasswordController@showResetForm')->name('developer.password.reset');
        $api->post('password/reset', 'App\Http\Controllers\Developer\Auth\ResetPasswordController@reset')->name('developer.password.update');

        $api->group(['middleware' => ['auth:developer']], function ($api) {
            // 邮箱验证
            $api->get('email/resend', 'App\Http\Controllers\Auth\VerificationController@resend')->name('developer.verification.resend');
            $api->get('email/verify/{id}', 'App\Http\Controllers\Auth\VerificationController@verify')->name('developer.verification.verify');
            // 刷新token
            $api->post('refresh_token', 'App\Http\Controllers\Developer\LoginController@refreshToken');
            // 登出
            $api->post('logout', 'App\Http\Controllers\Developer\LoginController@logout');
            //用户信息
            $api->post('user/info', 'App\Http\Controllers\Developer\DeveloperController@userInfo');
            // 修改密码
            $api->post('reset/password', 'App\Http\Controllers\Developer\DeveloperController@modifyPassword');
        });
        $api->group(['middleware' => ['auth:developer', 'verified']], function ($api) {
            //上传头像
            $api->post('upload/avatar', 'App\Http\Controllers\Developer\DeveloperController@uploadAvatar');
            //修改资料
            $api->post('save/info', 'App\Http\Controllers\Developer\DeveloperController@updateInfo');
            // 玩家列表
            $api->resource('players', 'App\Http\Controllers\Developer\PlayerController', ['only' => ['index', 'show', 'update']]);
            // 游戏列表
            $api->post('games/{game}/restore', 'App\Http\Controllers\Developer\GameController@restore');
            $api->resource('games', 'App\Http\Controllers\Developer\GameController');
            //游戏icon上传
            $api->post('game/icon', 'App\Http\Controllers\Developer\GameController@uploadIcon');
            //游戏测试账号列表
            $api->resource('games.testers', 'App\Http\Controllers\Developer\Game\TesterController', ['only' => ['index', 'store', 'destroy']]);
            // 游戏渠道列表
            $api->resource('games.channels', 'App\Http\Controllers\Developer\Game\ChannelController');
            //游戏元素据列表
            $api->resource('games.metas', 'App\Http\Controllers\Developer\Game\MetaController', ['only' => ['index', 'store']]);
            //渠道icon上传
            $api->post('channels/icon', 'App\Http\Controllers\Developer\Game\ChannelController@uploadIcon');
            //闪屏上传
            $api->post('upload/splashes', 'App\Http\Controllers\Developer\Game\ChannelController@uploadSplashes');
            //商品id
            $api->post('channel/goods', 'App\Http\Controllers\Developer\Game\ChannelController@goods');
            //上传csv文件
            $api->post('upload/csv', 'App\Http\Controllers\Developer\Game\ChannelController@uploadCsv');
            //上传推送厂商json
            $api->post('upload/manufacturer_json', 'App\Http\Controllers\Developer\Game\ChannelController@uploadJson');
            //获取插件列表
            $api->resource('plugs', 'App\Http\Controllers\Developer\Game\PlugController');
            //游戏总览
            $api->get('project/games', 'App\Http\Controllers\Developer\ProjectController@games');
            //订单列表
            $api->post('order', 'App\Http\Controllers\Developer\OrderController@index');
            //补单
            $api->post('supplement', 'App\Http\Controllers\Developer\OrderController@supplement');
        });
    });
    // 玩家
    $api->group(['middleware' => 'signed.client'], function ($api) {
        // 初始化
        $api->post('initialize', 'App\Http\Controllers\Player\GameController@initialize');
        // 登录
        $api->post('login', 'App\Http\Controllers\Player\LoginController@login');

        $api->group(['middleware' => ['auth:player']], function ($api) {
            // 登出
            $api->post('logout', 'App\Http\Controllers\Player\LoginController@logout');
            // 刷新token
            $api->post('refresh_token', 'App\Http\Controllers\Player\LoginController@refreshToken');
            // 创建订单
            $api->post('order/create', 'App\Http\Controllers\Player\OrderController@create');
            // 支付订单（沙箱）
            $api->post('order/pay', 'App\Http\Controllers\SdkController@pay');
        });
    });
    // 游戏服
    $api->group(['middleware' => ['signed.server']], function ($api) {
        $api->post('user/verify', 'App\Http\Controllers\SdkController@verify');
    });

    // 渠道支付回调
    $api->any('pay_callback/{channel}/{game}', 'App\Http\Controllers\SdkController@payCallback');
});
