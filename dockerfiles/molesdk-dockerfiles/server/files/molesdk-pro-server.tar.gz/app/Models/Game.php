<?php
/*
 * @Author: your name
 * @Date: 2019-12-03 14:30:46
 * @LastEditTime : 2019-12-27 14:14:42
 * @LastEditors  : Please set LastEditors
 * @Description: In User Settings Edit
 * @FilePath: \molesdk-pro\app\Models\Game.php
 */

namespace App\Models;

use App\Developer;
use App\Models\Game\GameMeta;
use App\Player;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\SoftDeletes;

use Cache;

class Game extends Model
{
    use SoftDeletes;
    /**
     * The time of cache expired.
     *
     * @var integer
     */
    const CACHE_TIMEOUT = 7*24*60*60;
    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'pri_key',
    ];

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'id',
        'type',
        'name',
        'icon',
        'key',
        'secret',
        'pub_key',
        'pri_key',
        'pay_callback',
        'pay_callback_debug',
        'status'
    ];

    /**
     * A game may be given many developers.
     */
    public function developers(): BelongsToMany
    {
        return $this->belongsToMany(Developer::class, 'developer_has_games', 'game_id', 'developer_id');
    }

    /**
     * A game may has many channels.
     */
    public function channels(): HasMany
    {
        return $this->hasMany(Game\Channel::class);
    }

    public function players(): HasMany
    {
        return $this->hasMany(Player::class);
    }

    public function metas()
    {
        return json_decode(base64_decode($this->metas), true) ?? [];
    }
    
    /**
     * Find a model by its primary key or throw an exception (use cache).
     *
     * @param  mixed  $id
     * @param  array  $columns
     * @return Game
     *
     */
    public static function findOrFailWithCache($id, $columns = ['*'])
    {
        return Cache::remember('app:'.$id, now()->addSeconds(Game::CACHE_TIMEOUT), function () use ($id, $columns) {
            return Game::findOrFail($id, $columns);
        });
    }

    /**
     * Remove an item from the cache.
     *
     * @param  string  $id
     * @return void
     */
    public static function forgetCache($id)
    {
        Cache::forget('app:'.$id);
    }
}
