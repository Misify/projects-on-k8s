<?php
/*
 * @Author: your name
 * @Date: 2019-12-03 14:30:46
 * @LastEditTime : 2019-12-27 14:18:08
 * @LastEditors  : Please set LastEditors
 * @Description: In User Settings Edit
 * @FilePath: \molesdk-pro\app\Models\Game\Channel.php
 */

namespace App\Models\Game;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Arr;

class Channel extends Model
{
    /**
     * The sand box channel id.
     *
     * @var integer
     */
    const SANDBOX = 0;

    /**
     * Indicates if the IDs are auto-incrementing.
     *
     * @var bool
     */
    public $incrementing = false;

    /**
     * The table associated with the model.
     *
     * @var string
     */
    protected $table = 'game_channels';

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'game_id',
        'channel_id',
        'bundle_id',
        'icon',
        'splashes',
        'goods',
        'params'
    ];

    /**
     * Get the game that owns the config.
     */
    public function game()
    {
        return $this->belongsTo(App\Models\Game::class);
    }

    /**
     * Get the base info of channel.
     */
    public function base()
    {
        return collect(config('channels'))->where("id", $this->channel_id)->first();
    }

    /**
     * Get the driver.
     */
    public function driver()
    {
        return $this->base()['driver'];
    }

    /**
     * Get the url to verify.
     */
    public function verifyUrl()
    {
        return $this->base()['verify_url'];
    }

    /**
     * Get the params of channel.
     */
    public function params($group)
    {
        return json_decode(base64_decode($this->params), true)[$group];
    }
}
