<?php

namespace App\Models\Game;

use Illuminate\Database\Eloquent\Model;

class Plug extends Model
{
    //
    public function base(){

    }
}
