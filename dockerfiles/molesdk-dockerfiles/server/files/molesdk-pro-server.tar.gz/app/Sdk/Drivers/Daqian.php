<?php

namespace App\Sdk\Drivers;

use App\Models\Game\Channel;
use App\Models\Order;
use App\Sdk\SdkDriver;
use Illuminate\Http\Request;
use Symfony\Component\HttpKernel\Exception\UnauthorizedHttpException;
use Illuminate\Routing\Exceptions\InvalidSignatureException;
use App\Exceptions\OrderPayException;
use App\Facades\Sdk;
use Closure;

class Daqian implements SdkDriver
{
    /**
     * To theck if the token is valid.
     *
     * @param Channel $channel
     * @param  string  $token
     * @return string
     */
    public function verify(Request $request, Channel $channel, $token)
    {
        $params = $request->all();
        $input = json_decode($token['token'], true);
        $time = substr($input['timestamp'], 0, 10);
        $params = $channel->params('server');
        $result = md5(md5($input['guid'] . $input['cp_ext'] . $time.$input['userId'] . $params['Secret']));
        if (!$result) {
            throw new UnauthorizedHttpException('Sdk', 'Unable to verify with invalid token.');
        }
        return $input['userId'];
    }
    /**
     * Set order paid after notice from channel.
     *
     * @param Channel $channel
     * @param Request $request
     * @param Closure $next
     */
    public function pay(Request $request, Channel $channel, Closure $next)
    {
        $request->validate([
            'amount' => 'required|string',
            // 'callback_info' => 'required',
            'order_id' => 'required|string',
            'role_id' => 'required|string',
            'server_id' => 'required|string',
            'status' => 'required|int',
            'timestamp' => 'required|int',
            'type' => 'int',
            'user_id' => 'required|string',
            'extends' => 'string',
            'giftconsume' => 'int',
            'sign' => 'required|string',
        ]);
        $params = $request->all();
        $secret = $channel->params('server')['Secret'];
        $sig_arr = [
            'amount' => $params['amount'],
            'callback_info' => $params['callback_info'],
            'order_id' => $params['order_id'],
            'role_id' => $params['role_id'],
            'server_id' => $params['server_id'],
            'status' => $params['status'],
            'timestamp' => $params['timestamp'],
            'type' => $params['type'],
            'user_id' => $params['user_id'],
            'Secret' => $secret,
        ];
        $sign_str = implode("#",$sig_arr);
        $sig = md5($sign_str);
        if ($sig != $params['sign']) {
            throw new OrderPayException("支付订单[$request->callback_info]失败，验签失败");
        }
        $order = Sdk::payOrder($request->order_id, $request->callback_info, $request->amount);
        return $next($order) ? 'success' : null;
    }
}
