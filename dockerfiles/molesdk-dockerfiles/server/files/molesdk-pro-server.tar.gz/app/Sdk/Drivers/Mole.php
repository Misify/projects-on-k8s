<?php

namespace App\Sdk\Drivers;

use App\Facades\Sdk;
use App\Sdk\SdkDriver;
use App\Models\Game\Channel;
use App\Models\Order;
use App\Utils\OpenSSL;
use GuzzleHttp\Client;
use Illuminate\Http\Request;
use Symfony\Component\HttpKernel\Exception\UnauthorizedHttpException;
use Illuminate\Routing\Exceptions\InvalidSignatureException;
use App\Exceptions\OrderPayException;

use Exception;
use Closure;

class Mole implements SdkDriver
{
    /**
     * To theck if the token is valid.
     *
     * @param Channel $channel
     * @param  string  $token
     * @return string
     */
    public function verify(Request $request, Channel $channel, $token)
    {
        // $input = json_decode($token, true);
        $params = $channel->params('server');

        $form_params = [
            'app_id' => $params['app_id']
        ];
        // 签名
        $form_params['signature'] = hash_hmac('sha256', collect($form_params)->sortKeys()->implode('&'), $params['app_secret']);

        $client = new Client();
        $res = $client->request('POST', $channel->verifyUrl(), [
            'timeout' => 10,
            'headers' => [
                'Accept' => 'application/json',
                'Authorization' => 'Bearer ' . $token['token']
            ],
            'form_params' => $form_params
        ]);
        if ($res->getStatusCode() != 200) {
            throw new UnauthorizedHttpException('Sdk', 'Unable to verify with invalid token.');
        }
        $data = json_decode($res->getBody(), true);

        return $data['openid'];
    }

    /**
     * Set order paid after notice from channel.
     *
     * @param Channel $channel
     * @param Request $request
     * @param Closure $next
     */
    public function pay(Request $request, Channel $channel, Closure $next)
    {
        $request->validate([
            'order_id' => 'required|string|max:255',
            'cp_order_id' => 'required|string|max:255',
            'amount' => 'required|string|max:255',
            'signature' => 'required|string|max:255'
        ]);
        $original = collect($request->except(['signature', 'token']))->sortKeys()->implode('&');
        $params = $channel->params('server');

        // if (OpenSSL::verify($original, base64_decode($request->signature), $params['pay_public_key']) != 1) {
        //     throw new OrderPayException("支付订单[$request->order_id]失败，验签失败");
        // }
        $order = Sdk::payOrder($request->order_id, $request->cp_order_id, $request->amount);

        return $next($order) ? 'SUCCESS' : 'FAILED';
    }
}
