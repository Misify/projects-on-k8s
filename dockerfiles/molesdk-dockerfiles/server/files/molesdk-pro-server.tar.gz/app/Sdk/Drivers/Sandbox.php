<?php

namespace App\Sdk\Drivers;

use App\Facades\Sdk;
use App\Models\Game\Channel;
use App\Models\Order;
use App\Sdk\SdkDriver;
use App\Utils\OpenSSL;
use Illuminate\Http\Request;
use Symfony\Component\HttpKernel\Exception\UnauthorizedHttpException;
use Illuminate\Routing\Exceptions\InvalidSignatureException;
use App\Exceptions\OrderPayException;

use Hash;
use Closure;

class Sandbox implements SdkDriver
{

    /**
     * To theck if the token is valid.
     *
     * @param Channel $channel
     * @param  string  $token
     * @return string
     */

    public function verify(Request $request, Channel $channel, $token)
    {
        $testers = json_decode(base64_decode($request->app->testers), true) ?? [];

        $index = array_search($token['account'], array_column($testers, 'name'));
        if ($index === false) {
            throw new UnauthorizedHttpException('Sdk', 'Unable to authenticate with invalid account in sandbox.');
        }
        $tester = $testers[$index];
        if (!Hash::check($token['password'], $tester['password'])) {
            throw new UnauthorizedHttpException('Sdk', 'Unable to authenticate with invalid credentials in sandbox.');
        }

        return $tester['name'];
    }

    /**
     * Set order paid after notice from channel.
     *
     * @param Channel $channel
     * @param Request $request
     * @param Closure $next
     */

    public function pay(Request $request, Channel $channel, Closure $next)
    {
        $request->validate([
            'order_id' => 'required|string|max:255',
            'amount' => 'required|string|max:255'
        ]);
        $order = Sdk::payOrder('', $request->order_id, $request->amount);

        return $next($order) ? response()->json([
            'message' => trans('success'),
            'status_code' => 200
        ], 200) : null;
    }

}
