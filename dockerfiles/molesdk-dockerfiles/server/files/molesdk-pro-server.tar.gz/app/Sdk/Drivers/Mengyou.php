<?php

namespace App\Sdk\Drivers;

use App\Models\Game\Channel;
use App\Models\Order;
use App\Sdk\SdkDriver;
use GuzzleHttp\Client;
use Illuminate\Http\Request;
use Symfony\Component\HttpKernel\Exception\UnauthorizedHttpException;
use Illuminate\Routing\Exceptions\InvalidSignatureException;
use App\Exceptions\OrderPayException;
use App\Facades\Sdk;
use Closure;

class Mengyou implements SdkDriver
{
    /**
     * To theck if the token is valid.
     *
     * @param Channel $channel
     * @param  string  $token
     * @return string
     */
    public function verify(Request $request, Channel $channel, $token)
    {
        $form_params = [
            'token' => $token['token']
        ];
        // $sign_str = sprintf(
        //     'app_id=%s&mem_id=%s&user_token=%s&app_key=%s',
        //     $form_params['app_id'],
        //     $form_params['mem_id'],
        //     $form_params['user_token'],
        //     $params['server']['app_key']
        // );
        // $sign = md5($sign_str);
        // $form_params['sign'] = $sign;
        $client = new Client();
        $res = $client->request('POST', $channel->verifyUrl(), [
            'timeout' => 10,
            'headers' => [
                'Accept' => 'application/json',
                'Authorization' => 'Bearer ' . $token['token']
            ],
            'form_params' => $form_params
        ]);
        $data = json_decode($res->getBody()->getContents(), true);
        if ($data['code'] != 1) {
            throw new UnauthorizedHttpException('Sdk', 'Unable to verify with invalid token.');
        }
        return $data['data']['uid'];
    }
    /**
     * Set order paid after notice from channel.
     *
     * @param Channel $channel
     * @param Request $request
     * @param Closure $next
     */
    public function pay(Request $request, Channel $channel, Closure $next)
    {
        $request->validate([
            'osn' => 'required|string|max:255',
            'dsn' => 'required|string|max:255',
            'money' => 'required|string|max:255',
            'sign' => 'required|string|max:255'
        ]);
        $params = $request->all();
        $base = json_decode(base64_decode($channel->params), true);
        $key = $base['server']['app_key'];
        $dext = '';
        if (isset($params['dext'])) {
            $dext = $params['dext'];
        }
        $sign_str = strtolower($params['appid'] . $params['dsn'] . $dext . $params['osn'] . $params['uid'] . $params['money'] . $params['time'] . $key);
        $original = strtolower(md5($sign_str));
        $orderIdArr = \explode('_', $request->dsn);
        // 验签
        if ($original != $params['sign']) {
            throw new OrderPayException("支付订单[orderIdArr]失败，验签失败");
        }

        $order = Sdk::payOrder($request->osn, $orderIdArr[2], $request->money, 100.0);

        return $next($order) ? response()->json([
            'code' => 1,
            'data' => [],
            'msg' => 'SUCCESS'
        ]) : null;
    }
}
