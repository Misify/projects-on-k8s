<?php

namespace App\Sdk;

use Illuminate\Http\Request;
use App\Models\Game\Channel;

use Closure;

interface SdkDriver
{
    /**
     * To theck if the token is valid.
     *
     * @param Request $request
     * @param Channel $channel
     * @param  string  $token
     * @return string
     */
    public function verify(Request $request, Channel $channel, string $token);

    /**
     * Validate callback of pay.
     *
     * @param Request $request
     * @param Channel $channel
     * @param Closure $next
     */
    public function pay(Request $request, Channel $channel, Closure $next);
}
