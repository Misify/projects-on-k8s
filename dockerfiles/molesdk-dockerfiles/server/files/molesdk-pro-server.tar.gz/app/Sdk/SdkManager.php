<?php

namespace App\Sdk;

use Illuminate\Http\Request;
use Illuminate\Support\Manager;
use App\Models\Game\Channel;
use App\Models\Game;
use App\Models\Order;
use App\Utils\OpenSSL;
use App\Exceptions\OrderPayException;
use GuzzleHttp\Client;
use Illuminate\Support\Str;

use Log;
use Closure;

class SdkManager extends Manager
{
    /**
     * Get the default driver name.
     *
     * @return string
     */

    public function getDefaultDriver() { }

    /**
     * Create a new driver instance.
     *
     * @param  string  $driver
     * @return mixed
     *
     */
    protected function createDriver($driver)
    {
        if (isset($this->customCreators[$driver])) {
            return $this->callCustomCreator($driver);
        } else {
            $method = 'create'.Str::studly($driver).'Driver';

            if (method_exists($this, $method)) {
                return $this->$method();
            }
        }
        $driverClass = "App\\Sdk\\Drivers\\".Str::studly($driver);
        return new $driverClass();
    }

    /**
     * To theck if the token is valid.
     *
     * @param Request $request
     * @param  Channel  $channel
     * @param  $token
     * @return string
     */
    public function verify(Request $request, Channel $channel, $token)
    {
        $driver = $channel->driver();
        
        return $this->driver($driver)->verify($request, $channel, $token);
    }

    /**
     * Pay and complete order.
     *
     * @param Request $request
     * @param Channel  $channel
     * @param Closure $next
     */
    public function pay(Request $request, Channel $channel, Closure $next)
    {
        $driver = $channel->driver();

        return $this->driver($driver)->pay($request, $channel, $next);
    }

    /**
     * Pay order.
     *
     * @param $order_id
     * @param $cp_order_id
     * @param $amount
     * @param $ratio
     */
    public function payOrder($order_id, $cp_order_id, $amount, $ratio = 1.0) 
    {
        if (config('app.mode') == 'standalone') {
            $order = new Order([
                'id' => $order_id, 
                'cp_order_id' => $cp_order_id, 
                'amount' => $amount / $ratio
            ]);
        } else {
            $order = Order::findOrFail($cp_order_id);
            // 未支付
            if ($order->state != Order::STATE_PAYING) {
                throw new OrderPayException("支付订单[$order->id]失败，订单不在状态：支付中.");
            }
            // 金额匹配
            if (abs($order->amount * $ratio - $amount) > 0.00001) {
                throw new OrderPayException("支付订单[$order->id]失败，订单金额不匹配，订单金额:{$order->amount}，支付金额:{$amount}.");
            }
            // 交易号
            $order->transaction_id = $order_id;
            // 已支付
            $order->state = Order::STATE_PAID;
            $order->save();
        }
        Log::info("订单[$order->id]支付成功");
        return $order;
    }
    
    /**
     * Complete order.
     *
     * @param $order
     */
    public function completeOrder($order)
    {
        $app = Game::findOrFailWithCache($order->game_id);
        $form_params = [
            'app_id' => $app->id,
            'order_id' => $order->id,
            'cp_order_id' => $order->cp_order_id,
            'amount' => $order->amount,
            'callback_info' => $order->callback_info ?? ''
        ];
        $form_params['signature'] = base64_encode(OpenSSL::sign(collect($form_params)->sortKeys()->implode('&'), $app->pri_key));
        $client = new Client();
        $callback_url = $order->callback_url ?? $app->pay_callback;
        try {
            $res = $client->request('POST', $callback_url, [
                'timeout' => 10,
                'form_params' => $form_params
            ]);
        } catch (\Exception $exception) {
            throw new OrderPayException("完成订单[$order->id]失败，通知应用服务器[{$callback_url}]失败");
        }
        if ($res->getStatusCode() != 200 || $res->getBody() != 'SUCCESS') {
            throw new OrderPayException("完成订单[$order->id]失败，从应用服务器获取错误响应，状态码:{$res->getStatusCode()}，响应内容:{$res->getBody()}");
        }

        if (config('app.mode') != 'standalone') {
            // 已完成
            $order->state = Order::STATE_COMPLETE;
            $order->save();
        }
        Log::info("订单[$order->id]完成");
        return true;
    }
}
