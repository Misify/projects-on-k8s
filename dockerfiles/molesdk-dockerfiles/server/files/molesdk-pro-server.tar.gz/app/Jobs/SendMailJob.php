<?php

namespace App\Jobs;

use Illuminate\Bus\Queueable;
use Illuminate\Queue\SerializesModels;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Support\Facades\Mail;

class SendMailJob implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    /**
     * Create a new job instance.
     *
     * @return void
     */
    protected $name = '';
    protected $subject = '';
    protected $view = '';
    protected $user = '';
    protected $exp = '';
    public function __construct($name, $subject, $view, $user, $exp)
    {
        //
        $this->name = $name;
        $this->subject = $subject;
        $this->view = $view;
        $this->user = $user;
        $this->exp = $exp;
    }

    /**
     * Execute the job.
     *
     * @return void
     */
    public function handle()
    {
        //  发送邮件
        $user = $this->user;
        $subject = $this->subject;
        \Redis::setex($user['key'], $this->exp, $user['token']);
        $res = Mail::send($this->view, ['token' => $user['token'], 'user' => $user], function ($message) use ($user, $subject) {
            $message->to($user['email'])->subject($subject);
        });
        return $res;
    }

    /**
     * 任务未能处理
     *
     * @param  \Throwable  $exception
     * @return void
     */
    // public function failed(Throwable $exception)
    // {
    //     \Log::debug($exception);
    // }
}
