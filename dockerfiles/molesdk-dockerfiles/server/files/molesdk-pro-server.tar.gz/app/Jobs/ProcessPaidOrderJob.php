<?php

namespace App\Jobs;

use App\Models\Game;
use App\Models\Order;
use App\Utils\OpenSSL;
use GuzzleHttp\Client;
use Illuminate\Bus\Queueable;
use Illuminate\Queue\SerializesModels;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;

use Log;
use Sdk;

class ProcessPaidOrderJob implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    /**
     * The number of seconds to wait before retrying the job.
     *
     * @var int
     */
    public $retryAfter = [
        [0, 20],
        [3, 200],
        [20, 3 * 60 * 60]
    ];
    /**
     * The number of times the job may be attempted.
     *
     * @var int
     */
    public $tries = 35;
    /**
     * Delete the job if its models no longer exist.
     *
     * @var bool
     */
    public $deleteWhenMissingModels = true;

    /**
     * The Order model.
     *
     * @var \App\Models\Order
     */
    private $order;

    /**
     * Create a new job instance.
     *
     * @return void
     */
    public function __construct(Order $order)
    {
        $this->order = $order;
    }

    /**
     * Execute the job.
     *
     * @return void
     */
    public function handle()
    {
        // 已完成
        if ($this->order->state == Order::STATE_COMPLETE) {
            Log::info(sprintf("订单[%s]状态已完成", $this->order->id));
            $this->delete();
            return;
        }
        Log::debug(sprintf("订单[%s]第[%d]次尝试通知应用服务器", $this->order->id, $this->attempts()));
        try {
            Sdk::completeOrder($this->order);
        } catch (\Exception $exception) {
            Log::debug($exception->getMessage());
        }
        // Retry after some seconds
        $this->retryAfter();
    }

    /**
     * Process the job after failed.
     *
     * @return void
     */
    public function failed()
    {
        $this->order->state = Order::STATE_FAILED;
        $this->order->save();
        Log::info(sprintf("已支付订单[%s]处理失败", $this->order->id));
    }

    /**
     * Wait some seconds to before retrying the job.
     *
     * @var int
     */
    protected function retryAfter()
    {
        $wait = 0;
        $attempts = $this->attempts();

        foreach ($this->retryAfter as $retry) {
            if ($attempts <= $retry[0]) {
                break;
            }
            $wait = $retry[1];
        }
        $this->release($wait);
    }
}
