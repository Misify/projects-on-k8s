<?php

namespace App\Exceptions;

use Dingo\Api\Exception\Handler as DingoHandler;
use Illuminate\Auth\AuthenticationException;
use Symfony\Component\HttpKernel\Exception\UnauthorizedHttpException;

use Log;
use Exception;

class ApiHandler extends DingoHandler
{
    //
    public function handle(\Exception $exception)
    {
        if ($exception instanceof AuthenticationException) {
            $exception = new UnauthorizedHttpException('ApiAuth', $exception->getMessage(), $exception);
        }
        return parent::handle($exception);
    }
}
