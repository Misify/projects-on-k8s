<?php

namespace App\Utils;

use Illuminate\Support\Facades\Storage;
use InvalidArgumentException;

/**
 * Provides utilities to generate difference ids.
 */
class UploadUtils
{
    /**
     *upload.
     *
     * @param int $id
     * @return \Illuminate\Http\Response
     */
    public static function upload($file, $diskName, $extensions = [])
    {
        $fileExtension = $file->getClientOriginalExtension();
        if (!in_array($fileExtension, $extensions)) {
            throw new InvalidArgumentException('File extension is not matched.');
        }

        $fileName = date('Y_m_d') . '/' . md5(time()) . mt_rand(0, 9999) . '.' . $fileExtension;
        $disk = Storage::disk($diskName);
        if (!$disk->put($fileName, file_get_contents($file->getRealPath()))) {
            throw new \RuntimeException('Failed to store file.');
        }

        return $disk->url($fileName);
    }
}
