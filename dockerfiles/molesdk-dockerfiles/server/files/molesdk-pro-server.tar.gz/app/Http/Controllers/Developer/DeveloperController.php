<?php

namespace App\Http\Controllers\Developer;

use Illuminate\Support\Str;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Auth;
use Illuminate\Http\Request;
use Illuminate\Auth\Events\PasswordReset;
use Illuminate\Auth\Access\AuthorizationException;
use App\Http\Controllers\Controller;
use App\Utils\UploadUtils;
use App\Developer;

class DeveloperController extends Controller
{
    /**
     * Get the guard to be used during authentication.
     *
     * @return \Illuminate\Contracts\Auth\StatefulGuard
     */
    protected function guard()
    {
        return Auth::guard('developer');
    }

    /**
     * 获取用户信息
     */
    public function userInfo(Request $request)
    {
        $user = $request->user();
        $user->avatar = $user->avatar ? $user->avatar : '/img/avatar2.jpg';

        return response()->json([
            'data' => $user
        ]);
    }

    /**
     * 修改密码
     *
     * @param \Illuminate\Http\Request $request
     * @return json response
     */
    public function modifyPassword(Request $request)
    {
        $request->validate([
            'oldPassword' => 'required',
            'password' => 'required|min:8'
        ]);
        $user = $request->user();

        if (!$this->guard()->validate([
            $user->getAuthIdentifierName() => $user->getAuthIdentifier(), 
            'password' => $request->oldPassword
        ])) {
            throw new AuthorizationException;
        }
        $user->password = Hash::make($request->password);
        $user->save();

        event(new PasswordReset($user));

        $this->guard()->login($user);

        return response()->json([
            'message' => trans('success')
        ]);
    }
    

    /**
     * 上传头像
     *
     * @param \Illuminate\Http\Request $request
     * @return json response
     */
    public function uploadAvatar(Request $request)
    {
        $url = UploadUtils::upload($request->file, 'avatar', ['png', 'jpg']);
        $user = $request->user();

        $user->avatar = $url;
        $user->save();

        return response()->json([
            'message' => trans('Upload avatar successful.'),
            'url' => env('APP_URL') . $url
        ]);
    }

    /**
     * 修改资料
     *
     * @param \Illuminate\Http\Request $request
     * @return json response
     */
    public function updateInfo(Request $request)
    {
        $user = $request->user();

        $user->name = $request->name;
        $user->save();

        return response()->json([
            'message' => trans('success')
        ]);
    }
}
