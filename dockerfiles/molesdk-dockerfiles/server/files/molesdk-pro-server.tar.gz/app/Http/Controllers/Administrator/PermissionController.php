<?php

namespace App\Http\Controllers\Administrator;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Spatie\Permission\Models\Permission;

class PermissionController extends Controller
{
    /**
     * Get the guard to be used during authentication.
     *
     * @return \Illuminate\Contracts\Auth\StatefulGuard
     */
    protected function guard()
    {
        return Auth::guard('administrator');
    }

    /**
     * Display a listing of the resource.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        return Permission::all();
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $developer = $request->user();
        $params = $request->all();

        $request->validate([
            'name' => 'required|string|max:255'
        ]);

        $game = Permission::create([
            'name' => $params['name'],
            'title' => $params['title'],
            'guard_name' => 'administrator',
            'hidden' => $params['hidden'],
            'fname' => $this->get_fname($params['name'])
        ]);

        return response()->json([
            'message' => trans('success'),
            'status_code' => 200
        ], 200);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $permission = Permission::findOrFail($id);
        return $permission;
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $request->validate([
            'name' => 'string|max:255',
        ]);

        $permission = Permission::findOrFail($id);

        if ($request->filled('hidden')) {
            $permission->hidden = $request->hidden;
        }
        if ($request->filled('name')) {
            $permission->name = $request->name;
        }
        if ($request->filled('title')) {
            $permission->title = $request->title;
        }
        $permission->fname = $this->get_fname($permission->name);
        $permission->save();

        return response()->json([
            'message' => trans('success'),
            'status_code' => 200
        ], 200);
    }
    public function get_fname($name){
        return \explode('_',$name)[0];
    }
    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $permission = Permission::findOrFail($id);
        $permission->delete();

        return response()->json([
            'message' => trans('success'),
            'status_code' => 200
        ], 200);
    }

    /**
     * Restore a soft-deleted resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    // public function restore($id)
    // {
    //     $game = $this->guard()->user()->games()->onlyTrashed()->findOrFail($id);
    //     $game->restore();

    //     return response()->json([
    //         'message' => trans('success'),
    //         'status_code' => 200
    //     ], 200);
    // }
}
