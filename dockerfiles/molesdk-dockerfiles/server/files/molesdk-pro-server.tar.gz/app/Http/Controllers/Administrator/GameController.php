<?php

namespace App\Http\Controllers\Administrator;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Models\Game;
use App\Developer;
use App\Administrator;
use Illuminate\Support\Arr;
use App\Http\Resources\Game\ChannelResource;

class GameController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        $params = $request->all();
        if($params['userId']){
            $games = Game::leftJoin('developer_has_games', 'developer_has_games.game_id', '=', 'games.id')->where(function ($query) use ($params) {
                if($params['name']){
                    $query->where('name', 'like', '%' . $params['name'] . '%');
                }
            })->where('developer_has_games.developer_id',$params['userId'])->paginate($params['pageSize'], ['*'], 'page', $params['current']);
        }else{
            $games = Game::where(function ($query) use ($params) {
                if($params['name']){
                    $query->where('name', 'like', '%' . $params['name'] . '%');
                }
            })->paginate($params['pageSize'], ['*'], 'page', $params['current']);
        }
        return response()->json($games, 200);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        return Game::findOrFailWithCache($id);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $request->validate([
            'status' => 'integer'
        ]);
        
        $game = Game::findOrFailWithCache($id);
        // TODO：会不会导致其它旧数据覆盖
        $game->status = $request->status;
        $game->save();
        Game::forgetCache($id);

        return response()->json([
            'message' => trans('success'),
            'status_code' => 200
        ], 200);
    }

    public function secret(Request $request)
    {
        $user = $request->user();
        if (\Hash::check(\Request::input('password'), $user->password)) {
            $game = Game::findOrFailWithCache($request->id);
            return response()->json([
                'data'  => $game->secret,
                'message' => trans('success'),
                'status_code' => 200
            ], 200);
        }
        return response()->json([
            'message' => 'psssword error!',
            'status_code' => 500
        ], 500);
    }

    public function channels(Request $request, $game_id)
    {
        $request->validate([
            'name' => 'string|max:255'
        ]);
        $game = Game::findOrFailWithCache($game_id);
        $channels = $game->channels();

        // Filter by params
        if ($request->filled('name')) {
            $name = $request->name;
            $channels_matched = Arr::where(config('channels'), function ($value) use ($name) {
                dd($value);
                return strstr($value, $name) !== false ? true : false;
            });
            $channels = $channels->whereIn('channel_id', Arr::pluk($channels_matched, 'id'));
        }

        return ChannelResource::collection($channels->get());
    }
}
