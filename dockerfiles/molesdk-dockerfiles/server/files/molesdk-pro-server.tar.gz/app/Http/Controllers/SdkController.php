<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Player;
use App\Models\Order;
use App\Models\Game;
use App\Models\Game\Channel;
use App\Exceptions\OrderPayException;
use Symfony\Component\HttpKernel\Exception\BadRequestHttpException;
use Symfony\Component\HttpKernel\Exception\UnauthorizedHttpException;
use Illuminate\Auth\AuthenticationException;
use App\Jobs\ProcessPaidOrderJob;

use Log;
use Exception;
use Sdk;
class SdkController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        if (config('app.mode') != 'standalone') {
            $this->middleware('auth:player')->only('verify');
        }
    }
    
    /**
     * Handle a verify request to the application.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\JsonResponse
     *
     * @throws \Illuminate\Validation\ValidationException
     */
    public function verify(Request $request)
    {
        if (config('app.mode') == 'standalone') {
            try {
                $channel = $request->app->channels()->where('channel_id', $request->channel_id)->first();
                $token = json_decode(base64_decode($request->token, true), true);
                $channel_user_id = Sdk::verify($request, $channel, $token);

                $player = new Player(['openid' => $channel_user_id]);
            } catch (Exception $exception) {
                throw new UnauthorizedHttpException('sdk-auth', $exception->getMessage(), $exception);
            }
        } else {
            $player = $request->user();

            if ($player->game_id != $request->app_id) {
                throw new UnauthorizedHttpException('sdk-auth', 'Unable to authenticate with invalid app.');
            }
        }
        return response()->json([
            'openid' => $player->openid
        ], 200);
    }

    /**
     * Handle a pay request to the application.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\JsonResponse
     *
     * @throws \Illuminate\Validation\ValidationException
     */
    public function pay(Request $request)
    {
        $request->validate([
            'order_id' => 'required|string|max:255',
            'amount' => 'required|string|max:255',
        ]);
        $player = $request->user();
        // 沙箱渠道
        if ($player->channel_id != Channel::SANDBOX) {
            return;
        }
        $testers = json_decode(base64_decode($request->app->testers), true) ?? [];
        // 沙箱账号
        if (array_search($player->channel_user_id, array_column($testers, 'name')) === false) {
            return;
        }
        $order = Order::findOrFail($request->input('order_id'));
        // 订单匹配
        if ($order->channel_id != $player->channel_id || $order->player_id != $player->id) {
            return;
        }
        Log::debug(sprintf("玩家[%s]支付订单[%s]（沙盒）", $player->id, $order));
        return $this->payCallback($request, $player->channel_id, $request->input('app_id'));
    }

    /**
     * Handle a pay callback request to the application.
     *
     * @param Request $request
     * @param $channel_id
     * @param $game_id
     * 
     * @throws \Symfony\Component\HttpKernel\Exception\BadRequestHttpException
     * 
     * @return \Illuminate\Http\Response
     */
    public function payCallback(Request $request, $channel_id, $game_id)
    {
        if ($channel_id == Channel::SANDBOX) {
            $channel = new Channel([
                'channel_id' => $channel_id,
                'game_id' => $game_id
            ]);
            $channel->params = $channel->base()["params"];
        } else {
            $channel = Channel::where([
                ['channel_id', $channel_id],
                ['game_id', $game_id],
            ])->first();
        }
        try {
            return Sdk::pay($request, $channel, function ($order) use ($game_id){
                if (config('app.mode') != 'standalone') {
                    ProcessPaidOrderJob::dispatch($order);
                    return true;
                } else {
                    $order->game_id = $game_id;
                    return Sdk::completeOrder($order);
                }
            });
        }
        catch (OrderPayException $exception) {
            Log::debug(sprintf("支付回调处理异常，应用ID: %s，渠道ID: %s，异常信息：{%s}", $game_id, $channel_id, $exception->getMessage()));
            throw new BadRequestHttpException;
        }
    }
}
