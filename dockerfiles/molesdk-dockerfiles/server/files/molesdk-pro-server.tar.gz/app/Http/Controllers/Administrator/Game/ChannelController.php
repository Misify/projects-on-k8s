<?php

namespace App\Http\Controllers\Administrator\Game;

use App\Http\Controllers\Controller;
use App\Http\Resources\Game\ChannelResource;
use App\Models\Game;
use App\Models\Game\Channel;
use App\Utils\UploadUtils;
use Illuminate\Http\Request;
use Illuminate\Support\Arr;
use Illuminate\Support\Facades\Auth;

class ChannelController extends Controller
{
    /**
     * Get the guard to be used during authentication.
     *
     * @return \Illuminate\Contracts\Auth\StatefulGuard
     */
    protected function guard()
    {
        return Auth::guard('administrator');
    }

    /**
     * Display a listing of the resource.
     *
     * @param  $game_id
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request, $game_id)
    {
        $request->validate([
            'name' => 'string|max:255'
        ]);
        $game = Game::findOrFailWithCache($game_id);
        $channels = $game->channels();

        // Filter by params
        if ($request->filled('name')) {
            $name = $request->name;
            $channels_matched = Arr::where(config('channels'), function ($value) use ($name) {
                return strstr($value, $name) !== false ? true : false;
            });
            $channels = $channels->whereIn('channel_id', Arr::pluk($channels_matched, 'id'));
        }

        return ChannelResource::collection($channels->get());
    }

    /**
     *
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  $game_id
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request, $game_id)
    {
        $request->validate([
            'channel_id' => 'required|integer'
        ]);
        $game = Game::findOrFailWithCache($game_id);

        $channel = $game->channels()->create([
            'game_id' => $game->id,
            'channel_id' => $request->channel_id
        ]);

        return ChannelResource::make($channel);
    }

    /**
     * Display the specified resource.
     *
     * @param  $game_id
     * @param  $channel_id
     * @return \Illuminate\Http\Response
     */
    public function show($game_id, $channel_id)
    {
        $game = Game::findOrFailWithCache($game_id);
        $channel = $game->channels()->where('channel_id', $channel_id)->first();
        $base = $channel->base();

        // Transform params for client
        $paramsOrigin = json_decode(base64_decode($channel->params), true);
        $paramsTransform = [];

        foreach ($base['params'] as $key => $group) {
            $paramsTransform[$key] = [];
            $paramsOriginByGroup = $paramsOrigin[$key] ?? [];
            foreach ($group as $paramConfig) {
                array_push($paramsTransform[$key], [
                    'key' => $paramConfig['key'],
                    'value' => $paramsOriginByGroup[$paramConfig['key']] ?? null,
                    'desc' => $paramConfig['desc']
                ]);
            }
        }

        $metas = $game->metas();
        if (count($metas) > 0) {
            $paramsTransform['meta'] = [];
            if (isset($paramsOrigin['meta'])) {
                $paMe = [];
                foreach ($paramsOrigin['meta'] as $colKey => $colItem) {
                    array_push($paMe, $colKey);
                }
                //匹配数据  先取交集 后取差集
                $j = array_intersect($paMe, $metas);
                //剔除以删除meta
                foreach ($paramsOrigin['meta'] as $pcKey => $parCof) {
                    if (in_array($pcKey, $j)) {
                        array_push($paramsTransform['meta'], [
                            'key' => $pcKey,
                            'value' => $parCof ?? null,
                            'desc' => $pcKey
                        ]);
                    }
                }
                //匹配新添加得meta
                $c = array_diff($metas, $j);
                if (count($c) > 0) {
                    foreach ($c as $cItem) {
                        array_push($paramsTransform['meta'], [
                            'key' => $cItem,
                            'value' => '',
                            'desc' => $cItem
                        ]);
                    }
                }
            } else {
                foreach ($metas as $me) {
                    array_push($paramsTransform['meta'], [
                        'key' => $me,
                        'value' => '',
                        'desc' => $me
                    ]);
                }
            }
        }

        $data = [
            'id' => $channel->channel_id,
            'name' => $base['alias'],
            'cname' => $base['name'],
            'description' => $base['desc'],
            'abstract' => $base['abstract'],
            'is_goods' => $base['is_goods'],
            'version' => $base['version'],
            'bundle_id' => $channel->bundle_id,
            'params' => $paramsTransform
        ];
        array_push($data['params']['client'], [
            'key' => 'mole_channel_id',
            'value' => $channel->channel_id,
            'desc' => 'mole_channel_id',
            'hidden' => true
        ]);
        array_push($data['params']['client'], [
            'key' => 'mole_app_id',
            'value' => $game->id,
            'desc' => 'mole_app_id',
            'hidden' => true
        ]);
        array_push($data['params']['client'], [
            'key' => 'mole_app_key',
            'value' => $game->key,
            'desc' => 'mole_app_key',
            'hidden' => true
        ]);
        if ($channel->icon) {
            $data['icon'] = $channel->icon;
        }
        if ($channel->splashes) {
            $data['splashes'] = json_decode(base64_decode($channel->splashes), true);
        }
        // if ($channel->goods) {
        $data['goods'] = json_decode(base64_decode($channel->goods), true);
        $data['plugs'] = json_decode(base64_decode($channel->plugs), true);
        // 处理plug
        if ($data['plugs']) {
            $list = config('plugs');
            foreach ($data['plugs'] as $key => $item) {
                foreach ($list as $lis) {
                    if ($item['id'] == $lis['id']) {
                        $lis['params'] = $item['params'];
                        $data['plugs'][$key] = $lis;
                    }
                }
            }
        }
        $data['plugunit'] = [];
        if ($data['plugs'] && \count($data['plugs']) > 0) {
            $plugunit = [];
            $plugunitData = [];
            foreach ($data['plugs'] as $item) {
                array_push($plugunit, $item['alias']);
                $par = [];
                foreach ($item['params'] as $param) {
                    $par[$param['key']] = $param['value'] ?? '';
                }
                $key = ucwords(strtolower($item['alias'])) . 'Data';
                $plugunitData[$key] = $par;
            }
            $data['plugunit']['plugunits'] = $plugunit;
            $data['plugunit']['plugunitData'] = $plugunitData;
        }
        // }
        return $data;
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  $game_id
     * @param  $channel_id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $game_id, $channel_id)
    {
        $request->validate([
            'icon' => 'string|max:255',
            'splashes' => 'array',
            'goods' => 'array',
            'params' => 'array',
        ]);

        $game = Game::findOrFailWithCache($game_id);
        
        $attributes = [];
        if ($request->has('icon')) {
            $attributes['icon'] = $request->icon;
        }
        if ($request->has('packing_types')) {
            $attributes['packing_types'] = json_encode($request->packing_types);
        }
        if ($request->has('splashes')) {
            $attributes['splashes'] = count($request->splashes) > 0 ? base64_encode(json_encode($request->splashes)) : null;
        }
        if ($request->has('goods')) {
            $attributes['goods'] = count($request->goods) > 0 ? base64_encode(json_encode($request->goods)) : null;
        }
        if ($request->has('params')) {
            foreach ($request->params as $item) {
                foreach ($item as $k => $i) {
                    if ($k == 'bundle_id') {
                        $attributes['bundle_id'] = $i;
                        break;
                    }
                }
            }
            $attributes['params'] = base64_encode(json_encode($request->params));
        }
        $game->channels()->where('channel_id', $channel_id)->update($attributes);

        return response()->json([
            'message' => trans('success'),
            'status_code' => 200
        ], 200);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  $game_id
     * @param  $channel_id
     * @return \Illuminate\Http\Response
     */
    public function destroy($game_id, $channel_id)
    {
        $game = Game::findOrFailWithCache($game_id);
        $game->channels()->where('channel_id', $channel_id)->delete();

        return response()->json([
            'message' => trans('success'),
            'status_code' => 200
        ], 200);
    }
    /**
     *upload icon.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function uploadIcon(Request $request)
    {
        $url = UploadUtils::upload($request->icon, 'channels-icon', ['png']);
        if ($url) {
            return response()->json([
                'url' => $url,
                'message' => trans('success'),
                'status_code' => 200
            ], 200);
        }
        return response()->json([
            'message' => 'error',
            'status_code' => 500
        ], 500);
    }
    /**
     *upload splashes.
     *
     * @param  $request
     * @return \Illuminate\Http\Response
     */
    public function uploadSplashes(Request $request)
    {
        $url = UploadUtils::upload($request->file, 'splashes', ['png']);
        if ($url) {
            return response()->json([
                'url' => $url,
                'message' => trans('success'),
                'status_code' => 200
            ], 200);
        }
        return response()->json([
            'message' => 'error',
            'status_code' => 500
        ], 500);
    }
    /**
     * 获取json文件
     */
    public function downloadChannelsConfig(Request $request)
    {
        $channels = config('channels');
        return response()->json([
            'data' => $channels
        ]);
    }
}
