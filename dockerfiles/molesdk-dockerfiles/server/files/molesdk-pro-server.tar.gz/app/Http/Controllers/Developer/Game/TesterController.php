<?php

namespace App\Http\Controllers\Developer\Game;

use Illuminate\Http\Request;
use App\Models\Game;
use App\Http\Controllers\Controller;
use Carbon\Carbon;

use Arr;
use Hash;

class TesterController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @param  $game_id
     * 
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request, $game_id)
    {
        $game = $request->user()->games()->findOrFail($game_id);
        $testers = json_decode(base64_decode($game->testers), true) ?? [];

        $testers = array_map(function ($item) {
            return Arr::only($item, ['name', 'password', 'created_at']);
        }, $testers);
        return response()->json([
            'data' => $testers
        ]);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  $game_id
     * 
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request, $game_id)
    {
        $request->validate([
            'name' => 'required|string|max:255',
            'password' => 'required|string|max:255',
        ]);
        $game = $request->user()->games()->findOrFail($game_id);
        $testers = json_decode(base64_decode($game->testers), true) ?? [];
        // Unique name check
        if (array_search($request->input('name'), array_column($testers, 'name')) !== false) {
            return response()->json([
                'message' => trans('The name already exists.'),
            ], 500);
        }

        array_push($testers, [
            'name' => $request->input('name'),
            'password' => Hash::make($request->input('password')),
            'created_at' => Carbon::now(),
        ]);
        $game->testers = base64_encode(json_encode($testers));
        $game->save();
        Game::forgetCache($game_id);
        
        return response()->json([
            'message' => 'success'
        ]);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  $game_id
     * @param  string  $name
     * 
     * @return \Illuminate\Http\Response
     */
    public function destroy(Request $request, $game_id, $name)
    {
        $game = $request->user()->games()->findOrFail($game_id);
        $testers = json_decode(base64_decode($game->testers), true) ?? [];

        $index = array_search($name, array_column($testers, 'name'));
        if ($index === false) {
            return response()->json([
                'message' => 'Resource not exists.'
            ]);
        }
        unset($testers[$index]);
        $game->testers = base64_encode(json_encode($testers));
        $game->save();
        Game::forgetCache($game_id);
        
        return response()->json([
            'message' => 'success'
        ]);
    }
}
