<?php

namespace App\Http\Controllers\Administrator;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Spatie\Permission\Models\Permission;
use App\Administrator;
use Spatie\Permission\Models\Role;
use App\Utils\UploadUtils;

use Hash;
class AdministratorController extends Controller
{

    protected function guard()
    {
        return Auth::guard('administrator');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $user = Administrator::findOrFail($id);
        $roles = $user->getRoleNames();
        return [
            'name' => $user->name,
            'email' => $user->email,
            'roles' => $roles[0],
            'id' => $user->id
        ];
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $developer = $request->user();
        $params = $request->all();

        $request->validate([
            'name' => 'required|string|max:255',
            'password' => 'required|string|max:255',
            'email' => 'required|string|max:255',
        ]);
        $Administrator = Administrator::create([
            'name' => $params['name'],
            'password' => bcrypt($params['password']),
            'email' => $params['email'],
        ]);
        $Administrator->assignRole($params['roles']);
        return response()->json([
            'message' => trans('success'),
            'status_code' => 200
        ], 200);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $request->validate([
            'name' => 'required|string|max:255',
            'email' => 'required|string|max:255',
        ]);

        $Administrator = Administrator::findOrFail($id);

        if ($request->filled('name')) {
            $Administrator->name = $request->name;
        }
        if ($request->filled('email')) {
            $Administrator->email = $request->email;
        }
        $Administrator->save();

        $Administrator->syncRoles([$request->roles]);
        return response()->json([
            'message' => trans('success'),
            'status_code' => 200
        ], 200);
    }

    public function userInfo(Request $request)
    {
        $user = $request->user();
        if ($user->id == 1) {
            $permission =  Permission::all()->toArray();
        } else {
            $permission = $user->getPermissionsViaRoles()->toArray();
        }
        $roles = $user->getRoleNames();
        $user->role = $roles;
        $user->permissions = $permission;
        return $this->sendUserInfoResponse($user);
    }

    public function index(Request $request)
    {
        return Administrator::with('roles')->get();
    }


    public function sendUserInfoResponse($user)
    {
        return response()->json([
            'data' => $user,
            'message' => trans('success'),
            'status_code' => 200
        ], 200);
    }

    public function changePassword(Request $request)
    {
        $user = $request->user();
        $isCheck = Hash::check($request->input('old'), $user->password);
        if ($isCheck) {
            $user->password = Hash::make($request->input('newPas'));
            $user->save();
            return response()->json([
                'message' => trans('success'),
                'status_code' => 200
            ], 200);
        } else {
            return response()->json([
                'message' => trans('old password error'),
                'status_code' => 422
            ], 422);
        }
    }

    public function showPermission($id)
    {
        $user = Administrator::findOrFail($id);
        $roles = $user->getRoleNames();
        if ($roles[0] === 'administrators') {
            $permission = Permission::all();
        } else {
            $permission = $user->getAllPermissions();
        }
        return response()->json([
            'data' => $permission,
            'message' => trans('success'),
            'status_code' => 200
        ], 200);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $permission = Administrator::findOrFail($id);
        $permission->delete();

        return response()->json([
            'message' => trans('success'),
            'status_code' => 200
        ], 200);
    }

    /**
     * 上传头像
     *
     * @param \Illuminate\Http\Request $request
     * @return json response
     */
    public function uploadAvatar(Request $request)
    {
        $url = UploadUtils::upload($request->file, 'avatar', ['png', 'jpg']);
        $user = $request->user();

        $user->avatar = $url;
        $user->save();
        return response()->json([
            'message' => trans('Upload avatar successful.'),
            'url' => env('APP_URL') . $url
        ]);
    }
}
