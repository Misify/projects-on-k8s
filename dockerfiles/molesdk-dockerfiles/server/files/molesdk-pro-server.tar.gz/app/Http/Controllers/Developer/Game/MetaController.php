<?php

namespace App\Http\Controllers\Developer\Game;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Models\Game;
use App\Models\Game\GameMeta;
use Illuminate\Support\Facades\Auth;

class MetaController extends Controller
{
    /**
     * Get the guard to be used during authentication.
     *
     * @return \Illuminate\Contracts\Auth\StatefulGuard
     */
    protected function guard()
    {
        return Auth::guard('developer');
    }


    /**
     * Display a listing of the resource.
     *
     * @param  $game_id
     * 
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request, $game_id)
    {
        $game = $request->user()->games()->findOrFail($game_id);
        $metas = $game->metas();

        return response()->json([
            'params' => $metas
        ]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  $game_id
     * 
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request, $game_id)
    {
        $request->validate([
            'params' => 'present|array'
        ]);
        $game = $request->user()->games()->findOrFail($game_id);
        $game->metas = base64_encode(json_encode(array_unique($request->params)));
        $game->save();
        Game::forgetCache($game_id);

        return response()->json([
            'data' => 'success'
        ]);
    }
}
