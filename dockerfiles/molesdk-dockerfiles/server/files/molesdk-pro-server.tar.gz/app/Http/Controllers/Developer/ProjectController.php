<?php

namespace App\Http\Controllers\Developer;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Models\Game;
use Illuminate\Support\Facades\Auth;

class ProjectController extends Controller
{
    /**
     * Get the guard to be used during authentication.
     *
     * @return \Illuminate\Contracts\Auth\StatefulGuard
     */
    protected function guard()
    {
        return Auth::guard('developer');
    }

    /**
     * 游戏总览
     */

    public function games(Request $request)
    {
        $games = $this->guard()->user()->games()->get();
        foreach ($games as $key => $item) {
            $channels = $item->channels()->get();
            $player = $item->players()->get();
            $games[$key]['channels'] = count($channels);
            $games[$key]['players'] = count($player);
            $num = 0;
            foreach ($player as $pl) {
                $orders = $pl->orders()->where('orders.state', 1)->get();
                $orders = json_decode(json_encode($orders));
                $amount = array_column($orders, 'amount');
                $num = $num + array_sum($amount);
            }
            $games[$key]['orders'] = $num;
        }
        return response()->json($games);
    }
}
