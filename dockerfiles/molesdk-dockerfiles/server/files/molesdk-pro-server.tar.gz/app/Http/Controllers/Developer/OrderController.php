<?php

namespace App\Http\Controllers\Developer;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Models\Order;
use Carbon\Carbon;
use App\Jobs\ProcessPaidOrderJob;
use App\Developer;
use Illuminate\Auth\Access\AuthorizationException;

class OrderController extends Controller
{
    /**
     * Select order
     * @param Illuminate\Http\Request $request
     * @return response
     */
    public function index(Request $request)
    {
        $order = Order::where(function ($query) use ($request) {
            if ($request->time != null) {
                $time = $request->time;
                $query->whereBetween('created_at', [Carbon::parse($time[0])->toDateTimeLocalString(), Carbon::parse($time[1])->toDateTimeLocalString()]);
            }
            if ($request->state != null) {
                $query->where('state', $request->state);
            }
            if ($request->chennelId != null) {
                $query->where('channel_id', $request->chennelId);
            }
            if ($request->val != null) {
                $query->where($request->type, '=', $request->val);
            }
        })->where('game_id', $request->game_id)
            ->with(['players'])
            ->orderBy('updated_at', 'desc')
            ->paginate($request->pageSize, ['*'], 'page', $request->current);
        // 循环获取channel信息
        $order->each(function ($item, $key) {
            $channel = \config('channels');
            foreach ($channel as $ch) {
                if ($ch['id'] == $item->channel_id) {
                    $item['channel'] = $ch;
                }
            }
        });
        return response()->json([
            'message' => trans('success'),
            'data' => $order
        ]);
    }

    /**
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function supplement(Request $request) {
        $request->validate([
            'id' => 'required|string|max:255'
        ]);
        $order = Order::findOrFail($request->id);
        // 获取订单关联的游戏信息
        $result = $request->user()->games()->where('game_id', '=', $order['game_id'])->get();
        // 没有操作订单关联游戏的权限
        if (count($result) == 0) {
            return response()->json([
                'message' => trans('The current user does not have this permission!'),
                'code' => 406
            ], 406);
        }
        $order->state = Order::STATE_PAID;
        $order->save();
        ProcessPaidOrderJob::dispatch($order);

        return response()->json([
            'message' => trans('success'),
            'code' => 200
        ], 200);
    }
}
