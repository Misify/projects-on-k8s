<?php

namespace App\Http\Controllers\Administrator;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Developer;

class DeveloperController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        $params = $request->all();
        $page = $params['current'];
        $pageSize = $params['pageSize'];
        $start = ((int) $page - 1);
        $data = Developer::offset($start)
            ->where(function ($query) use ($params) {
                if (isset($params['name'])) {
                    $query->where('name', 'like', '%' . $params['name'] . '%')->orWhere('email', 'like', '%' . $params['name'] . '%');
                }
            })
            ->limit($pageSize)
            ->get();
        $count = Developer::count();
        // $count = count($data);
        return response()->json([
            'data' => $data,
            'count' => $count
        ]);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $developer = Developer::findOrFail($id);
        return $developer;
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $request->validate([
            'status' => 'integer'
        ]);
        $developer = Developer::findOrFail($id);
        $developer->status = $request->status;
        $developer->save();

        return response()->json([
            'message' => trans('success'),
            'status_code' => 200
        ], 200);
    }
}
