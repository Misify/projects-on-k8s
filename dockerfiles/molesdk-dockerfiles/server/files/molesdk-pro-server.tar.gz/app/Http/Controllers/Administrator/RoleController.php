<?php

namespace App\Http\Controllers\Administrator;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Spatie\Permission\Models\Role;

class RoleController extends Controller
{
    /**
     * Get the guard to be used during authentication.
     *
     * @return \Illuminate\Contracts\Auth\StatefulGuard
     */
    protected function guard()
    {
        return Auth::guard('administrator');
    }

    /**
     * Display a listing of the resource.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        return Role::with('permissions')->get();
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $developer = $request->user();
        $params = $request->all();

        $request->validate([
            'name' => 'required|string|max:255',
            'title' => 'required|string|max:255'
        ]);
        $role = Role::create([
            'name' => $params['name'],
            'guard_name' => 'administrator',
            'title' => $params['title'],
        ]);

        // $permissions = explode(',',$params['permissions']);
        $role->givePermissionTo($params['permissions']);

        return response()->json([
          'message' => trans('success'),
          'status_code' => 200
        ], 200);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $role = Role::with('permissions')->findOrFail($id);
        return $role;
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $request->validate([
            'type' => 'integer',
            'name' => 'string|max:255',
            'title' => 'string|max:255',
        ]);

        $role = Role::findOrFail($id);

        if ($request->filled('type')) {
            $role->type = $request->type;
        }
        if ($request->filled('name')) {
            $role->name = $request->name;
        }
        $role->save();
        $role->syncPermissions($request->permissions);
        return response()->json([
            'message' => trans('success'),
            'status_code' => 200
        ], 200);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $permission = Role::findOrFail($id);
        $permission->delete();

        return response()->json([
            'message' => trans('success'),
            'status_code' => 200
        ], 200);
    }

    /**
     * Restore a soft-deleted resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    // public function restore($id)
    // {
    //     $game = $this->guard()->user()->games()->onlyTrashed()->findOrFail($id);
    //     $game->restore();

    //     return response()->json([
    //         'message' => trans('success'),
    //         'status_code' => 200
    //     ], 200);
    // }
}
