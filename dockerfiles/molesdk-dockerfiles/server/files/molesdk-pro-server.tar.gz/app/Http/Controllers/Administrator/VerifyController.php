<?php

namespace App\Http\Controllers\Administrator;

use App\Developer;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class VerifyController extends Controller
{
    /**
     * Get the guard to be used during authentication.
     *
     * @return \Illuminate\Contracts\Auth\StatefulGuard
     */
    protected function guard()
    {
        return Auth::guard('administrator');
    }
    //
    public function verify(Request $request){
        $developer = Developer::findOrFail($request->id);
        $developer->status = 1;
        $developer->save();
        return response()->json([
            'message' => 'success',
            'statue_code' => 200
        ]);
    }
}
