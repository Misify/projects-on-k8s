<?php

namespace App\Http\Controllers\Developer\Game;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;

class PlugController extends Controller
{
    /**
     * Get the guard to be used during authentication.
     *
     * @return \Illuminate\Contracts\Auth\StatefulGuard
     */
    protected function guard()
    {
        return Auth::guard('developer');
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        //
        if (isset($request->gameId) && isset($request->channelId)) {
            $game = $this->guard()->user()->games()->findOrFail($request->gameId);
            $channel = $game->channels()->where('channel_id', $request->channelId)->first();
            $plugs = json_decode(base64_decode($channel->plugs), true) ?? [];
            $list = config('plugs');
            $result = [];
            foreach ($plugs as $key => $value) {
                foreach ($list as $key_ => $value_) {
                    if ($value['id'] == $value_['id']) {
                        array_push($result, $value_);
                    }
                }
            }
            return response()->json([
                'data' => $result
            ]);
        }
        $list = config('plugs');
        return response()->json([
            'data' => $list
        ]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $game = $this->guard()->user()->games()->findOrFail($request->gameId);
        $plugId = $request->plugId;
        $list = config('plugs');
        $base = $game->channels()->where('channel_id', $request->channelId)->first();
        $plugs = json_decode(base64_decode($base->plugs), true);
        if (!$plugs) {
            $plugs = [];
        }
        foreach ($list as $item) {
            if ($item['id'] == $plugId) {
                array_push($plugs, [
                    'id' => $item['id'],
                    'params' => $item['params']
                ]);
                break;
            }
        }
        $attributes['plugs'] = \base64_encode(\json_encode($plugs));
        $game->channels()->where('channel_id', $request->channelId)->update($attributes);
        return response()->json([
            'message' => 'success'
        ]);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    { }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(Request $request, $id)
    {
        //
        $game = $this->guard()->user()->games()->findOrFail($request->gameId);
        $base = $game->channels()->where('channel_id', $request->channelId)->first();
        $plugs = json_decode(base64_decode($base->plugs), true);
        foreach ($plugs as $key => $item) {
            if ($item['id'] == $id) {
                array_splice($plugs, $key, 1);
                break;
            }
        }
        $attributes['plugs'] = \base64_encode(\json_encode($plugs));
        $game->channels()->where('channel_id', $request->channelId)->update($attributes);

        return response()->json([
            'message' => trans('success'),
            'status_code' => 200
        ], 200);
    }
}
