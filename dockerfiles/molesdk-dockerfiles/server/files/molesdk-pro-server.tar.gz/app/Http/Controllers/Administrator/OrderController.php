<?php

namespace App\Http\Controllers\Administrator;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Models\Game;
use App\Models\Order;
use App\Jobs\ProcessPaidOrderJob;
use Carbon\Carbon;

class OrderController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        $order = Order::where(function ($query) use ($request) {
            if ($request->time != null) {
                $time = $request->time;
                $query->whereBetween('created_at', [Carbon::parse($time[0])->toDateTimeLocalString(), Carbon::parse($time[1])->toDateTimeLocalString()]);
            }
            if ($request->state != null) {
                $query->where('state', $request->state);
            }
            if ($request->channelId != null) {
                $query->where('channel_id', $request->channelId);
            }
            if (\in_array($request->type, ['username'])) {
                $player = Player::where(function ($qu) use ($request) {
                    $qu->where('name', $request->username);
                })->first();
                if ($player) {
                    $query->where('player_id', $player->id);
                } else {
                    $query->where('player_id', 0);
                }
            } else {
                if ($request->val != null) {
                    $query->where($request->type, $request->val);
                }
            }
            if ($request->gameId != null) {
                $query->whereIn('game_id', $request->gameId);
            }
        })->with(['players', 'games'])
            ->orderBy('orders.created_at')
            ->paginate($request->pageSize, ['*'], 'page', $request->current);
        $order->each(function ($item, $key) {
            $channel = \config('channels');
            foreach ($channel as $ch) {
                if ($ch['id'] == $item->channel_id) {
                    $item['channel'] = $ch;
                }
            }
        });
        return response()->json([
            'message' => 'success',
            'data' => $order
        ]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }

    /**
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function getGames(Request $request)
    {
        $name = $request->name;
        $games = Game::where('name', 'like', "%" . $name . "%")->get();
        return response()->json([
            'data' => $games
        ]);
    }

    /**
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function supplement(Request $request) {
        $request->validate([
            'id' => 'required|string|max:255'
        ]);
        $order = Order::findOrFail($request->id);
        $order->state = Order::STATE_PAID;
        $order->save();
        ProcessPaidOrderJob::dispatch($order);

        return response()->json([
            'message' => trans('success'),
            'code' => 200
        ], 200);
    }
}
