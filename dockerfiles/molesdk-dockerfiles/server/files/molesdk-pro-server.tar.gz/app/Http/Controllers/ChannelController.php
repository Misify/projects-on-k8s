<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Arr;
use Illuminate\Support\Facades\Storage;

class ChannelController extends Controller
{
    const ITEM_PER_PAGE = 10;

    /**
     * Display a listing of the resource.
     *
     * @param Request $request
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        $page = $request->get('page', 1);
        $limit = $request->get('limit', self::ITEM_PER_PAGE);

        $channels = config('channels');
        unset($channels[0]);
        $channels = array_values($channels);

        $items = array_slice($channels, $page - 1, $limit);
        for ($i = 0; $i < count($items); ++$i) {
            $items[$i] = Arr::only($items[$i], ['id', 'name', 'url', 'version', 'desc','type']);
        }
        $total = count($channels);

        return [
            'items' => $items,
            'total' => $total
        ];
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $channels = config('channels');
        $channel = null;

        foreach ($channels as $value) {
            if ($value['id'] != $id) {
                continue;
            }
            $channel = $value;
            break;
        }
        return $channel;
    }
}
