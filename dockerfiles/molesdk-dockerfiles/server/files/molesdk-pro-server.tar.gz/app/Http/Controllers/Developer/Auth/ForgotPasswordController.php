<?php

namespace App\Http\Controllers\Developer\Auth;

use App\Http\Controllers\Auth\ForgotPasswordController as ForgotPassword;
use Illuminate\Support\Facades\Password;

class ForgotPasswordController extends ForgotPassword
{
    /**
     * Get the broker to be used during password reset.
     *
     * @return \Illuminate\Contracts\Auth\PasswordBroker
     */
    public function broker()
    {
        return Password::broker("developers");
    }
}
