<?php

namespace App\Http\Controllers\Developer\Game;

use App\Http\Controllers\Controller;
use App\Http\Resources\Game\ChannelResource;
use App\Imports\GoodsImport;
use App\Utils\UploadUtils;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Arr;
use Illuminate\Support\Facades\Auth;

class ChannelController extends Controller
{
    /**
     * Get the guard to be used during authentication.
     *
     * @return \Illuminate\Contracts\Auth\StatefulGuard
     */
    protected function guard()
    {
        return Auth::guard('developer');
    }

    /**
     * Display a listing of the resource.
     *
     * @param  $game_id
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request, $game_id)
    {
        $request->validate([
            'name' => 'string|max:255'
        ]);
        $game = $request->user()->games()->findOrFail($game_id);
        $channels = $game->channels();
        // Filter by params
        if ($request->filled('name')) {
            $name = $request->name;
            $channels_matched = Arr::where(config('channels'), function ($value) use ($name) {
                return strstr($value, $name) !== false ? true : false;
            });
            $channels = $channels->whereIn('channel_id', Arr::pluk($channels_matched, 'id'));
        }
        $channel = ChannelResource::collection($channels->where('channel_id', '!=', 0)->get());
        $channel = json_decode(json_encode($channel), true);
        if (!$channel) {
            $channel = [];
        }
        foreach ($channel as $key => $item) {
            $channel[$key]['goods'] = json_decode($item['goods'], true);
        }
        return response()->json([
            'data' => $channel
        ]);
    }

    /**
     *
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  $game_id
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request, $game_id)
    {
        $request->validate([
            'channel_id' => 'required'
        ]);
        $channelID = \explode(',', $request->channel_id);
        $game = $request->user()->games()->findOrFail($game_id);
        $data = [];
        $item = [];
        foreach ($channelID as $channel) {
            $item = [
                'game_id' => $game->id,
                'channel_id' => $channel,
                'created_at' => Carbon::now(),
                'updated_at' => Carbon::now(),
            ];
            array_push($data, $item);
        }
        $channel = $game->channels()->insert($data);

        return response()->json([
            'message' => 'success'
        ]);
    }

    /**
     * Display the specified resource.
     *
     * @param  $game_id
     * @param  $channel_id
     * @return \Illuminate\Http\Response
     */
    public function show(Request $request, $game_id, $channel_id)
    {
        $game = $this->guard()->user()->games()->findOrFail($game_id);
        $channel = $game->channels()->where('channel_id', $channel_id)->first();
        $base = $channel->base();

        // Transform params for client
        $paramsOrigin = json_decode(base64_decode($channel->params), true);
        $paramsTransform = [];

        foreach ($base['params'] as $key => $group) {
            $paramsTransform[$key] = [];
            $paramsOriginByGroup = $paramsOrigin[$key] ?? [];
            foreach ($group as $paramConfig) {
                array_push($paramsTransform[$key], [
                    'key' => $paramConfig['key'],
                    'value' => $paramsOriginByGroup[$paramConfig['key']] ?? null,
                    'desc' => $paramConfig['desc'],
                    'required' => $paramConfig['required'] ?? false
                ]);
            }
        }

        $metas = $game->metas();
        if (count($metas) > 0) {
            $paramsTransform['meta'] = [];
            if (isset($paramsOrigin['meta'])) {
                $paMe = [];
                foreach ($paramsOrigin['meta'] as $colKey => $colItem) {
                    array_push($paMe, $colKey);
                }
                //匹配数据  先取交集 后取差集
                $j = array_intersect($paMe, $metas);
                //剔除以删除meta
                foreach ($paramsOrigin['meta'] as $pcKey => $parCof) {
                    if (in_array($pcKey, $j)) {
                        array_push($paramsTransform['meta'], [
                            'key' => $pcKey,
                            'value' => $parCof ?? null,
                            'desc' => $pcKey
                        ]);
                    }
                }
                //匹配新添加得meta
                $c = array_diff($metas, $j);
                if (count($c) > 0) {
                    foreach ($c as $cItem) {
                        array_push($paramsTransform['meta'], [
                            'key' => $cItem,
                            'value' => '',
                            'desc' => $cItem
                        ]);
                    }
                }
            } else {
                foreach ($metas as $me) {
                    array_push($paramsTransform['meta'], [
                        'key' => $me,
                        'value' => '',
                        'desc' => $me
                    ]);
                }
            }
        }

        $data = [
            'id' => $channel->channel_id,
            'name' => $base['alias'],
            'cname' => $base['name'],
            'mode' => config('app.mode') == 'standalone' ? 1 : 0,
            'description' => $base['desc'],
            'abstract' => $base['abstract'],
            'is_goods' => $base['is_goods'],
            // 'version' => $base['version'],
            'bundle_id' => $channel->bundle_id,
            'params' => $paramsTransform
        ];
        $data['channel_id'] = $channel->channel_id;
        $data['app_id'] = $game->id;
        $data['app_key'] = $game->key;
        if ($channel->icon) {
            $data['icon'] = $channel->icon;
        }
        if ($channel->splashes) {
            $data['splashes'] = json_decode(base64_decode($channel->splashes), true);
        }
        // if ($channel->goods) {
        $data['goods'] = json_decode(base64_decode($channel->goods), true);
        $data['plugs'] = json_decode(base64_decode($channel->plugs), true);
        // 处理plug
        if ($data['plugs']) {
            $list = config('plugs');
            foreach ($data['plugs'] as $key => $item) {
                foreach ($list as $lis) {
                    if ($item['id'] == $lis['id']) {
                        $lis['params'] = $item['params'];
                        $data['plugs'][$key] = $lis;
                    }
                }
            }
        }
        $data['plugins'] = [];
        if ($data['plugs'] && \count($data['plugs']) > 0) {
            $plugunit = [];
            $plugunitData = [];
            $plugs = config('plugs');
            $plugsList = [];
            foreach ($plugs as $key => $value) {
                $plugsList[$value['id']] = $value;
            }
            // foreach ($data['plugs'] as $key => $item) {
            //     foreach ($item['params'] as $key_1 => $value) {
            //         foreach ($plugsList[$item['id']]['params'] as $key_2 => $val) {
            //             if ($val['key'] == $value['key']) {
            //                 $data['plugs'][$key]['params'][$key_1] = array_merge($val, $data['plugs'][$key]['params'][$key_1]);
            //             }
            //         }
            //     }
            // }
            foreach ($data['plugs'] as $key => $item) {
                $par = [];
                foreach ($item['params'] as $param) {
                    $par[$param['key']] = $param['value'] ?? '';
                }
                $key = ucwords(strtolower($item['alias'])) . 'Data';
                if ($item['alias'] === 'SHARE') {
                    if ($item['osType'] === $request['osType']) {
                        $plugunitData[$key] = $par;
                        array_push($plugunit, $item['alias']);
                    }
                } else if ($item['alias'] === 'PUSH') {
                    if ($item['osType'] === $request['osType']) {
                        $plugunitData[$key] = $par;
                        array_push($plugunit, $item['alias']);
                    }
                } else {
                    $plugunitData[$key] = $par;
                    array_push($plugunit, $item['alias']);
                }
            }
            $data['plugins']['plugins'] = $plugunit;
            $data['plugins']['pluginData'] = $plugunitData;
        }
        // }
        return $data;
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  $game_id
     * @param  $channel_id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $game_id, $channel_id)
    {
        $request->validate([
            'splashes' => 'array',
            'params' => 'array',
        ]);

        $game = $this->guard()->user()->games()->findOrFail($game_id);

        $attributes = [];
        if ($request->has('icon')) {
            $attributes['icon'] = $request->icon;
        }
        if ($request->has('packing_types')) {
            $attributes['packing_types'] = json_encode($request->packing_types);
        }
        if ($request->has('splashes')) {
            $attributes['splashes'] = count($request->splashes) > 0 ? base64_encode(json_encode($request->splashes)) : null;
        }
        if ($request->has('goods') && $request->goods) {
            $attributes['goods'] = count($request->goods) > 0 ? base64_encode(json_encode($request->goods)) : null;
        }

        if ($request->has('params')) {
            $params = $request->params;
            foreach ($params as $key => $item) {
                $arr = [];
                foreach ($item as $i) {
                    $arr[$i['key']] = $i['value'];
                    if ($i['key'] == 'bundle_id') {
                        $attributes['bundle_id'] = $i['value'];
                    }
                }
                $params[$key] = $arr;
            }
            $attributes['params'] = base64_encode(json_encode($params));
        }
        if ($request->has('plugs')) {
            $plugs = $request->plugs;
            $attributes['plugs'] = base64_encode(json_encode($plugs));
        }
        $game->channels()->where('channel_id', $channel_id)->update($attributes);

        return response()->json([
            'message' => trans('success'),
            'status_code' => 200
        ], 200);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  $game_id
     * @param  $channel_id
     * @return \Illuminate\Http\Response
     */
    public function destroy($game_id, $channel_id)
    {
        $game = $this->guard()->user()->games()->findOrFail($game_id);
        $game->channels()->where('channel_id', $channel_id)->delete();

        return response()->json([
            'message' => trans('success'),
            'status_code' => 200
        ], 200);
    }
    /**
     *upload icon.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function uploadIcon(Request $request)
    {
        $url = UploadUtils::upload($request->icon, 'channels-icon', ['png']);
        if ($url) {
            return response()->json([
                'url' => $url,
                'message' => trans('success'),
                'status_code' => 200
            ], 200);
        }
        return response()->json([
            'message' => 'error',
            'status_code' => 500
        ], 500);
    }
    /**
     *upload splashes.
     *
     * @param  $request
     * @return \Illuminate\Http\Response
     */
    public function uploadSplashes(Request $request)
    {
        $url = UploadUtils::upload($request->file, 'splashes', ['png']);
        if ($url) {
            return response()->json([
                'url' => $url,
                'message' => trans('success'),
                'status_code' => 200
            ], 200);
        }
        return response()->json([
            'message' => 'error',
            'status_code' => 500
        ], 500);
    }

    /**
     * upload csv.
     *
     * @param  $request
     * @return \Illuminate\Http\Response
     */
    public function uploadCsv(Request $request)
    {
        $url = UploadUtils::upload($request->file, 'goods-csv', ['csv']);
        if ($url) {
            // $data = \Excel::import($url, function ($reader) { }, 'GBK')->get();
            $data = \Excel::toArray(new GoodsImport, $url);
            $data = $data[0];
            unset($data[0]);
            return response()->json([
                'data' => array_values($data),
                'message' => trans('success'),
                'status_code' => 200
            ], 200);
        }
        return response()->json([
            'message' => 'error',
            'status_code' => 500
        ], 500);
    }

    /**
     * upload json.
     *
     * @param  $request
     * @return \Illuminate\Http\Response
     */
    public function uploadJson(Request $request)
    {
        $url = UploadUtils::upload($request->file, 'channels-manufacturer-json', ['json']);
        if ($url) {
            return response()->json([
                'url' => $url,
                'message' => trans('success'),
                'status_code' => 200
            ], 200);
        }
        return response()->json([
            'message' => 'error',
            'status_code' => 500
        ], 500);
    }
}
