<?php
/*
 * @Author: your name
 * @Date: 2019-12-03 14:30:46
 * @LastEditTime : 2020-01-03 11:30:39
 * @LastEditors  : Please set LastEditors
 * @Description: In User Settings Edit
 * @FilePath: \molesdk-pro\app\Http\Resources\Game\ChannelResource.php
 */

namespace App\Http\Resources\Game;

use Illuminate\Http\Resources\Json\JsonResource;

class ChannelResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function toArray($request)
    {
        $base = $this->base();
        $splashes = json_decode(base64_decode($this->splashes));
        $arr = [];
        $num = count((array)$splashes);
        for($i = 0; $i< $num; $i++){
            $arr[$i] = \env('APP_URL').$splashes[$i];
        }
        return [
            'id' => $this->channel_id,
            'name' => $base['name'],
            'alias' => $base['alias'],
            'version' => $base['version'],
            'type' => $base['type'],
            'goods' => base64_decode($this->goods),
            'splashes' => $arr,
            'params' => \json_decode(base64_decode($this->params)),
            'plugs' => \json_decode(base64_decode($this->plugs)),
            'abstract' => $base['abstract'],
            'icon' => $this->icon,
            'is_goods' => $base['is_goods'],
            'bundle_id' => $this->bundle_id,
            'packing_types' => $base['packing_types'],
            'created_at' => $this->created_at,
            'updated_at' => $this->updated_at,
        ];
    }
}
