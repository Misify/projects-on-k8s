##############################################
# CentOS 7
##############################################
# 源
$ rpm -Uvh https://dl.fedoraproject.org/pub/epel/epel-release-latest-7.noarch.rpm

##############################################
# Nginx
##############################################
# 安装
$ yum -y install nginx
# 启动
$ systemctl start nginx
# 设置开机启动
$ systemctl enable nginx

##############################################
# Mariadb
##############################################
# 安装
$ yum -y install mariadb-server
# 启动
$ systemctl start mariadb
# 设置开机启动
$ systemctl enable mariadb
# 初始密码
$ mysqladmin -u root password '123456'

##############################################
# PHP 7.2
##############################################
# 源
$ yum install epel-release
$ yum install http://rpms.remirepo.net/enterprise/remi-release-7.rpm
# 安装
$ yum -y install php74-php php74-php-fpm php74-php-devel 
# 安装扩展
$ yum -y install php74-php-pdo php74-php-mbstring php74-php-xml php74-php-ctype php74-php-bcmath php74-php-gd php74-php-mysql php74-php-zip php74-php-pecl-redis
# 启动
$ systemctl start php74-php-fpm
# 设置开机启动
$ systemctl enable php74-php-fpm
# 链接PHP
$ ln -s /opt/remi/php74/root/usr/bin/php /usr/bin/php

##############################################
# Composer
##############################################
# 安装
$ curl -sS https://getcomposer.org/installer | php
$ mv composer.phar /usr/local/bin/composer
# 使用国内镜像
$ composer config -g repo.packagist composer https://packagist.phpcomposer.com

##############################################
# 部署
##############################################
# 安装依赖
$ composer install
# 拷贝.env.example到.env并配置
$ cp .env.example .env
# 生成KEY
$ php artisan key:generate
# 生成JWT_SECRET
$ php artisan jwt:secret
# 配置修改：
# 时区（默认为PRC中国时区）
# 模式（默认为集群模式，单机模式时需要配置游戏参数）
# 创建数据库
$ MySql> CREATE DATABASE IF NOT EXISTS molesdkpro default charset utf8mb4 COLLATE utf8mb4_unicode_ci;
# 数据库安装
$ php artisan migrate
$ php artisan db:seed
# 目录权限（确保supervisor运行queue的用户、目录用户与php-fpm一致）
$ chown nginx storage -R
# 链接存储目录
$ php artisan storage:link
# supervisorctl 守护进程开启服务 （注意！ 队列应用nginx对应的用户组启动！）
$ supervisorctl start queue

# 优化
$ composer install --optimize-autoloader --no-dev
$ php artisan config:cache
$ php artisan api:cache
# 配置站点
$ cp nginx.conf /etc/nginx/conf.d/molesdk-pro.conf
# 重启NGINX
$ systemctl restart nginx

# 发布环境
# CACHE_DRIVER=redis

# 管理员
用户名：admin@admin.com，密码：123456

##############################################
# 开发环境
# https://laravel.com/docs/5.7/homestead/
##############################################
$ composer install
$ vendor\\bin\\homestead make
$ vagrant up
# 设置php版本（homestead环境）
$ update-alternatives --config  php
